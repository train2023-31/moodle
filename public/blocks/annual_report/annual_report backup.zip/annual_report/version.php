<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_annual_report';
$plugin->version = 2025071302;
$plugin->requires = 2022041900; // Moodle 4.0+
