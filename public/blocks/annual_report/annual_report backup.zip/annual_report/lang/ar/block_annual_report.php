<?php
$string['pluginname'] = 'التقرير السنوي للدائرة الحادية والثلاثون';
$string['internalcourses'] = 'الدورات المنفذة للمنتسبين';
$string['externalcourses'] = 'الدورات المنفذة للجهات الخارجية';
$string['financial'] = ' المصاريف المالية';
$string['coursetype'] = 'نوع الدورة';
$string['count'] = 'العدد';
$string['beneficiaries'] = 'المستفيدين';
$string['clauseType'] = 'رقم البند';
$string['clause802'] = '802';
$string['clause811'] = '811';
$string['approvedAmount'] = 'المبلغ المعتمد لعام ';
$string['spentAmount'] = 'المبلغ المصروف';
$string['remainingAmount'] = 'المبلغ المتبقي';

// Capability strings
$string['annual_report:addinstance'] = 'إضافة كتلة تقرير سنوي جديدة';
$string['annual_report:myaddinstance'] = 'إضافة كتلة تقرير سنوي جديدة إلى صفحة المودل الخاصة بي';