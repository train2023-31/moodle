<?php

defined('MOODLE_INTERNAL') || die();

class block_annual_report extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_annual_report');
    }

    public function get_content() {
        global $DB;

        if ($this->content !== null) {
            return $this->content;
        }

// Get current year timestamp
$yearStart = strtotime(date('Y-01-01 00:00:00'));
$yearEnd = strtotime(date('Y-12-31 23:59:59')); 

// Define category IDs
// $internal_level_ids = [1, 2, 3, 4, 5];  
// $external_level_ids = [6, 7]; 
// Get internal and external level IDs dynamically from database
$internal_levels = $DB->get_records('local_annual_plan_course_level', ['is_internal' => 1], '', 'id');
$external_levels = $DB->get_records('local_annual_plan_course_level', ['is_internal' => 0], '', 'id');

$internal_level_ids = array_keys($internal_levels);
$external_level_ids = array_keys($external_levels);

// Fallback to empty arrays if no levels found
if (empty($internal_level_ids)) {
    $internal_level_ids = [0]; // Use 0 to prevent SQL errors
}
if (empty($external_level_ids)) {
    $external_level_ids = [0]; // Use 0 to prevent SQL errors
} 

// Get teacher role IDs
$teacher_roles = $DB->get_records_list('role', 'shortname', ['editingteacher', 'teacher']);
$teacher_role_ids = array_map(function($r) { return $r->id; }, $teacher_roles);
$teacher_placeholders = implode(',', array_fill(0, count($teacher_role_ids), '?'));

//HTML Code
$this->content = new stdClass();
$this->content->text = '';  // Initialize the text property
$this->content->text .= "<div class='wrapper'>";

/////////Internal Courses Section/////////

$internal_placeholders = implode(',', array_fill(0, count($internal_level_ids), '?'));
     
$total_internal_courses_this_year_sql = 
"SELECT COUNT(courselevelid) AS total_internal_courses_this_year 
FROM {local_annual_plan_course} 
WHERE courselevelid IN ($internal_placeholders)
AND approve = 1
AND coursedate BETWEEN ? AND ?";

$iCourseparams = array_merge($internal_level_ids, [$yearStart, $yearEnd]);
$iCourseResult = $DB->get_record_sql($total_internal_courses_this_year_sql, $iCourseparams);
$total_internal_courses_this_year = $iCourseResult ? $iCourseResult->total_internal_courses_this_year : 0;


// Query to Get Total internal Trainees only exclude teachers
/*contextlevel = 50 restricts your join to course contexts
You're only interested in role assignments at the course level, so you filter with contextlevel = 50.
This ensures you join the context table only for course-related assignments:**/
$total_internal_trainees_sql = 
    "SELECT COUNT(DISTINCT ue.userid) AS total_internal_trainees
    FROM {course} c
    JOIN {enrol} e ON e.courseid = c.id
    JOIN {user_enrolments} ue ON ue.enrolid = e.id
    LEFT JOIN {context} ctx ON ctx.contextlevel = 50 AND ctx.instanceid = c.id
    LEFT JOIN {role_assignments} ra ON ra.contextid = ctx.id AND ra.userid = ue.userid
    WHERE c.category IN ($internal_placeholders)
      AND c.startdate BETWEEN ? AND ?
      -- AND (ra.roleid IS NULL OR ra.roleid NOT IN ($teacher_placeholders))
      ";

      $iTraineesParams = array_merge($internal_level_ids, [$yearStart, $yearEnd], $teacher_role_ids);
      $iTrainesssResult = $DB->get_record_sql($total_internal_trainees_sql, $iTraineesParams);
      $total_internal_trainees = $iTrainesssResult ? $iTrainesssResult->total_internal_trainees : 0;


$internal_levels_sql = 
"SELECT 
    cl.id,
    CASE 
        WHEN ? = 'ar' THEN COALESCE(cl.description_ar, cl.description_en, cl.name)
        ELSE COALESCE(cl.description_en, cl.description_ar, cl.name)
    END AS i_level_name, 
    COUNT(ac.id) AS total_internal_courses_for_this_level
    FROM {local_annual_plan_course_level} cl
    JOIN {local_annual_plan_course} ac 
        ON ac.courselevelid = cl.id 
        AND ac.coursedate BETWEEN ? AND ? 
        AND ac.courselevelid IN ($internal_placeholders)
    WHERE ac.courselevelid IN ($internal_placeholders)
    AND ac.approve = 1
    GROUP BY cl.id ";

$iLevelsParams = array_merge([current_language(), $yearStart, $yearEnd], $internal_level_ids, $internal_level_ids);
$internal_Levels = $DB->get_records_sql($internal_levels_sql, $iLevelsParams);


$internal_trainees_in_each_level_sql = 
"SELECT courselevelid AS i_level, 
        SUM(numberofbeneficiaries) AS total_internal_trainees_for_this_level
    FROM {local_annual_plan_course} 
       WHERE coursedate BETWEEN ? AND ?
       AND courselevelid IN ($internal_placeholders) 
       -- OR courselevelid IS NULL)
          -- AND ac.courselevelid IN ($internal_placeholders)
       AND approve = 1
    GROUP BY courselevelid;";

$itraineesParams = array_merge([$yearStart, $yearEnd], $internal_level_ids, $internal_level_ids);
$internal_trainees_records = $DB->get_records_sql($internal_trainees_in_each_level_sql , $itraineesParams);

$this->content->text .= "<div>
    <h3 class='title'>" . get_string('internalcourses', 'block_annual_report') . "</h3>
    <div class='count-row'>
        <div class='box'>
            <span>" . get_string('count', 'block_annual_report') . " : <strong>$total_internal_courses_this_year</strong></span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <span>" . get_string('beneficiaries', 'block_annual_report') . " : <strong>$total_internal_trainees</strong></span>
        </div>
    </div>
    <table class='stat-table'>
        <thead>
            <tr style='font-size: 18px;'>
                <th>" . get_string('coursetype', 'block_annual_report') . "</th>
                <th>" . get_string('count', 'block_annual_report') . "</th>
                <th>" . get_string('beneficiaries', 'block_annual_report') . "</th>
            </tr>
        </thead>
        <tbody>";

//loop for internal beneficiaries 
$internal_beneficiaries_map = [];
foreach ($internal_trainees_records as $record) {
    $internal_beneficiaries_map[$record->i_level] = $record->total_internal_trainees_for_this_level;
}
// Loop for Internal Courses level
$total_courses_all_levels = 0;
$total_beneficiaries_all_levels = 0;

foreach ($internal_Levels as $lvl) {
    $level_id = $lvl->id;
    $level_name = format_string($lvl->i_level_name);
    $course_count = $lvl->total_internal_courses_for_this_level;
    $itrainee_count = isset($internal_beneficiaries_map[$level_id]) ? $internal_beneficiaries_map[$level_id] : 0;

    $total_courses_all_levels += $course_count;
    $total_beneficiaries_all_levels += $itrainee_count;

    $this->content->text .= '<tr>';
    $this->content->text .= "<td>$level_name</td>";
    $this->content->text .= "<td>$course_count</td>";
    $this->content->text .= "<td>$itrainee_count</td>";
    $this->content->text .= '</tr>';
}
$this->content->text .= '</tbody></table></div>';
$this->content->text .= "<hr class='line'>";

//End Of Internal Courses

///////External Section///////

$external_placeholders = implode(',', array_fill(0, count($external_level_ids), '?'));

// Query for Total external Courses Created This Year
$total_external_courses_this_year_sql = 
"SELECT COUNT(courselevelid) AS total_external_courses_this_year
FROM {local_annual_plan_course} 
WHERE courselevelid IN ($external_placeholders)
/*AND approve = 1*/
AND coursedate BETWEEN ? AND ?";

$eCourseParams = array_merge($external_level_ids, [$yearStart, $yearEnd]);
$eCourseResult = $DB->get_record_sql($total_external_courses_this_year_sql, $eCourseParams);
$total_external_courses_this_year = $eCourseResult ? $eCourseResult->total_external_courses_this_year : 0;

// External Courses Query
$external_categories_sql = 
"SELECT 
    cl.id,
    CASE 
        WHEN ? = 'ar' THEN COALESCE(cl.description_ar, cl.description_en, cl.name)
        ELSE COALESCE(cl.description_en, cl.description_ar, cl.name)
    END AS e_level_name, 
    COUNT(ac.id) AS total_external_courses_for_this_level
    FROM {local_annual_plan_course_level} cl
    RIGHT JOIN {local_annual_plan_course} ac 
        ON ac.courselevelid = cl.id 
        AND ac.coursedate BETWEEN ? AND ?
        AND cl.id IN ($external_placeholders)
    WHERE cl.id IN ($external_placeholders)
    /*AND ac.approve = 1*/
    GROUP BY cl.id ";

$eLevelParams = array_merge([current_language(), $yearStart, $yearEnd], $external_level_ids, $external_level_ids);
$external_levels = $DB->get_records_sql($external_categories_sql, $eLevelParams);

// Query to Get Total external Trainees
$total_external_trainees_sql = "
    SELECT COUNT(DISTINCT ue.userid) AS total_external_trainees
    FROM {course} c
    JOIN {enrol} e ON e.courseid = c.id
    JOIN {user_enrolments} ue ON ue.enrolid = e.id
    LEFT JOIN {context} ctx ON ctx.contextlevel = 50 AND ctx.instanceid = c.id
    LEFT JOIN {role_assignments} ra ON ra.contextid = ctx.id AND ra.userid = ue.userid
    WHERE c.category IN ($external_placeholders)
      AND c.startdate BETWEEN ? AND ?
      AND (ra.roleid IS NULL OR ra.roleid NOT IN ($teacher_placeholders))";

$eTraineesParams = array_merge($external_level_ids, [$yearStart, $yearEnd], $teacher_role_ids);
$eTraineesResult = $DB->get_record_sql($total_external_trainees_sql, $eTraineesParams);
$total_external_trainees = $eTraineesResult ? $eTraineesResult->total_external_trainees : 0;

// Query for external trainees in each level
$external_trainees_in_each_level_sql = 
"SELECT courselevelid AS e_level, 
        SUM(numberofbeneficiaries) AS total_external_trainees_for_this_level
    FROM {local_annual_plan_course} 
       WHERE coursedate BETWEEN ? AND ?
       AND courselevelid IN ($external_placeholders) 
       /*AND approve = 1*/
    GROUP BY courselevelid;";

$etraineesParams = array_merge([$yearStart, $yearEnd], $external_level_ids);
$external_trainees_records = $DB->get_records_sql($external_trainees_in_each_level_sql, $etraineesParams);

// Create external beneficiaries map
$external_beneficiaries_map = [];
foreach ($external_trainees_records as $record) {
    $external_beneficiaries_map[$record->e_level] = $record->total_external_trainees_for_this_level;
}

$this->content->text .= "<div>
    <h3 class='title'>" . get_string('externalcourses', 'block_annual_report') . "</h3>
    <div class='count-row'>
        <div class='box'>
            <span>" . get_string('count', 'block_annual_report') . " : <strong>$total_external_courses_this_year</strong></span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <span>" . get_string('beneficiaries', 'block_annual_report') . " : <strong>$total_external_trainees</strong></span>
        </div>
    </div>
    <table class='stat-table'>
        <thead>
            <tr style='font-size: 18px;'>
                <th>" . get_string('coursetype', 'block_annual_report') . "</th>
                <th>" . get_string('count', 'block_annual_report') . "</th>
                <th>" . get_string('beneficiaries', 'block_annual_report') . "</th>
            </tr>
        </thead>
        <tbody>";

// Loop for External Courses
foreach ($external_levels as $lvl) {
    $external_trainee_count = isset($external_beneficiaries_map[$lvl->id]) ? $external_beneficiaries_map[$lvl->id] : 0;
    $this->content->text .= '<tr>';
    $this->content->text .= '<td>' . format_string($lvl->e_level_name) . '</td>';
    $this->content->text .= '<td>' . $lvl->total_external_courses_for_this_level . '</td>';
    $this->content->text .= '<td>' . $external_trainee_count . '</td>';
    $this->content->text .= '</tr>';
}

$this->content->text .= '</tbody></table></div>';
$this->content->text .= "<hr class='line'>";

//Finance Details

$total_approved802 = $DB->get_field('local_financeservices_clause', 'amount', ['id' => 1]);

$total_approved811 = $DB->get_field('local_financeservices_clause', 'amount', ['id' => 2]);

//calculate spent and remaining amount
$amountsql = "
    SELECT 
        SUM(price_requested) AS total_spent
    FROM {local_financeservices}
    WHERE clause_id = :clauseid ";

$data802 = $DB->get_record_sql($amountsql, ['clauseid' => 1]);
$data811 = $DB->get_record_sql($amountsql, ['clauseid' => 2]);

// Compute remaining budget
$remaining802 = $total_approved802 - $data802->total_spent;
$remaining811 = $total_approved811 - $data811->total_spent;

// Format all values
$approved802 = number_format((float)$total_approved802, 2) . ' OMR';
$spent802    = number_format((float)$data802->total_spent, 2) . ' OMR';
$remain802   = number_format((float)$remaining802, 2) . ' OMR';

$approved811 = number_format((float)$total_approved811, 2) . ' OMR';
$spent811    = number_format((float)$data811->total_spent, 2) . ' OMR';
$remain811   = number_format((float)$remaining811, 2) . ' OMR';

$this->content->text .="<div>
<h3 class='title'> ". get_string('financial', 'block_annual_report') . "  - " . date('Y') . "</h3>
<table class='stat-table'>
       <tr>
          <th>". get_string('clauseType', 'block_annual_report') . " </th>
           <th>". get_string('clause802', 'block_annual_report') . " </th>
           <th>". get_string('clause811', 'block_annual_report') . " </th>
       </tr>
       <tr>
           <td>". get_string('approvedAmount', 'block_annual_report') . " " . date('Y') ." م</td>
           <td>$approved802</td>
            <td>$approved811</td>
       </tr>
       <tr>
           <td>". get_string('spentAmount', 'block_annual_report') . "</td>
           <td>$spent802</td>
            <td>$spent811</td>
       </tr>
       <tr>
           <td>". get_string('remainingAmount', 'block_annual_report') . "</td>
           <td>$remain802</td>
            <td>$remain811</td>
       </tr>
   </table>
   </div>";

$this->content->text .= "</div>"; // Close wrapper

$this->content->footer = '';

return $this->content;
}
}
