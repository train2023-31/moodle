<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_financeservices';
$plugin->version   = 2025082400;   // Fix clause name uniqueness bug (trim whitespace)
$plugin->requires  = 2020110300;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.10.1 (Build: 2025082400) - Fix clause name uniqueness bug';
