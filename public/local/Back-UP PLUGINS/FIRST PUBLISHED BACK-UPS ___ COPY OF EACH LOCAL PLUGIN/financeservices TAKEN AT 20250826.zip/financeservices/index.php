<?php
// =============================================================
//  Finance Services - Main Page Controller
// =============================================================

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->dirroot . '/local/financeservices/classes/form/add_form.php');
require_once($CFG->dirroot . '/local/financeservices/classes/form/filter_form.php');
require_once($CFG->dirroot . '/local/financeservices/classes/simple_workflow_manager.php');

use local_financeservices\simple_workflow_manager;

global $DB, $OUTPUT, $PAGE, $USER;

// ─────────────────────────────────────────────────────────────
// Setup page context
// ─────────────────────────────────────────────────────────────
$context = context_system::instance();
$PAGE->set_url(new moodle_url('/local/financeservices/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('financeservices', 'local_financeservices'));
$PAGE->set_heading(get_string('financeservices', 'local_financeservices'));

// Load JS
$PAGE->requires->js(new moodle_url('/theme/stream/js/custom_dialog.js'));
$PAGE->requires->js(new moodle_url('/theme/stream/js/export_csv.js'));

// ─────────────────────────────────────────────────────────────
// Global tab: add | list | manage
// ─────────────────────────────────────────────────────────────
$maintabs = [
    new tabobject('add', new moodle_url('/local/financeservices/index.php', ['tab' => 'add']),
        get_string('add', 'local_financeservices')),
    new tabobject('list', new moodle_url('/local/financeservices/index.php', ['tab' => 'list']),
        get_string('list', 'local_financeservices')),
    new tabobject('manage', new moodle_url('/local/financeservices/index.php', ['tab' => 'manage']),
        get_string('manageservices', 'local_financeservices')),
];

$currenttab = optional_param('tab', 'add', PARAM_ALPHA);

// ─────────────────────────────────────────────────────────────
// Header + tab bar
// ─────────────────────────────────────────────────────────────
echo $OUTPUT->header();
echo $OUTPUT->tabtree($maintabs, $currenttab);

// ─────────────────────────────────────────────────────────────
// Handle each tab's content
// ─────────────────────────────────────────────────────────────
if ($currenttab === 'add') {

    $mform = new \local_financeservices\form\add_form();

    if ($mform->is_cancelled()) {
        redirect(new moodle_url('/local/financeservices/index.php'));

    } else if ($data = $mform->get_data()) {
        $record = new stdClass();
        $record->course_id           = $data->courseid;
        $record->funding_type_id     = $data->funding_type_id;
        $record->price_requested     = $data->price_requested;
        $record->notes               = $data->notes;
        $record->user_id             = $USER->id;
        $record->date_time_requested = time();
        $record->date_type_required  = $data->date_type_required ?? null;
        $record->status_id           = simple_workflow_manager::get_initial_status_id();
        $record->clause_id           = $data->clause_id ?? null;

        // Insert the record and get its ID
        $requestid = $DB->insert_record('local_financeservices', $record);

        // Trigger request created event
        $event = \local_financeservices\event\request_created::create([
            'context' => \context_system::instance(),
            'objectid' => $requestid,
            'other' => [
                'course_id' => $record->course_id,
                'funding_type_id' => $record->funding_type_id,
                'price_requested' => $record->price_requested,
                'notes' => $record->notes,
                'clause_id' => $record->clause_id
            ]
        ]);
        $event->trigger();

        redirect(new moodle_url('/local/financeservices/index.php', ['tab' => 'list']));
    } else {
        $mform->display();
    }

} else if ($currenttab === 'list') {

    $filterform = new \local_financeservices\form\filter_form(
        new moodle_url('/local/financeservices/index.php', ['tab' => 'list']),
        [], 'post', '', ['class' => 'custom-filter-form']
    );
    $filterform->display();

    // Build dynamic WHERE conditions
    $where = [];
    $params = [];

    if ($data = $filterform->get_data()) {
        if (!empty($data->course_id)) {
            $where[] = 'fs.course_id = :course_id';
            $params['course_id'] = $data->course_id;
        }
        if (!empty($data->funding_type_id)) {
            $where[] = 'fs.funding_type_id = :funding_type_id';
            $params['funding_type_id'] = $data->funding_type_id;
        }
        if (!empty($data->statusid)) {
            $where[] = 'fs.status_id = :statusid';
            $params['statusid'] = $data->statusid;
        }
        if (!empty($data->clause_id)) {
            $where[] = 'fs.clause_id = :clause_id';
            $params['clause_id'] = $data->clause_id;
        }
    }

    $wheresql = '';
    if (!empty($where)) {
        $wheresql = 'WHERE ' . implode(' AND ', $where);
    }

    // Query requests
    $sql = "
        SELECT fs.*,
               c.fullname AS course,
               " . (current_language() === 'ar' ? "f.funding_type_ar" : "f.funding_type_en") . " AS funding_type,
               ls.display_name_en,
               ls.display_name_ar,
               cl." . (current_language() === 'ar' ? "clause_name_ar" : "clause_name_en") . " AS clause_name
          FROM {local_financeservices} fs
          JOIN {course} c ON fs.course_id = c.id
          JOIN {local_financeservices_funding_type} f ON fs.funding_type_id = f.id
          JOIN {local_status} ls ON fs.status_id = ls.id
     LEFT JOIN {local_financeservices_clause} cl ON fs.clause_id = cl.id
        $wheresql
     ORDER BY fs.date_time_requested DESC
    ";

    $records = $DB->get_records_sql($sql, $params);
    $renderable = new \local_financeservices\output\tab_list($records);
    echo $OUTPUT->render_from_template('local_financeservices/list', $renderable->export_for_template($OUTPUT));

} else if ($currenttab === 'manage') {
    // Load the dashboard, which includes its own subtabs
    require_once($CFG->dirroot . '/local/financeservices/pages/manage.php');
}

echo $OUTPUT->footer();
