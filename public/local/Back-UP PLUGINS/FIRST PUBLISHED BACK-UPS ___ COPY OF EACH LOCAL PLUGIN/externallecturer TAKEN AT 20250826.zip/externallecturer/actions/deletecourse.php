<?php
require_once('../../../config.php');
require_login();

// Require AJAX request for security
if (!defined('AJAX_SCRIPT')) {
    define('AJAX_SCRIPT', true);
}

$context = context_system::instance();
require_capability('local/externallecturer:manage', $context);

// Set JSON content type
header('Content-Type: application/json');

try {
    // Get the data from POST request
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (!$data || !isset($data['courseId']) || !isset($data['lecturerId'])) {
        // Try to get from regular POST data as fallback
        $courseId = optional_param('courseId', 0, PARAM_INT);
        $lecturerId = optional_param('lecturerId', 0, PARAM_INT);
        if (!$courseId || !$lecturerId) {
            throw new Exception('Invalid course or lecturer ID');
        }
    } else {
        $courseId = intval($data['courseId']);
        $lecturerId = intval($data['lecturerId']);
    }
    
    if ($courseId <= 0 || $lecturerId <= 0) {
        throw new Exception('Invalid course or lecturer ID');
    }
    
    // Check if the enrollment exists
    $enrollment = $DB->get_record('externallecturer_courses', [
        'id' => $courseId,
        'lecturerid' => $lecturerId
    ]);
    
    if (!$enrollment) {
        throw new Exception('Course enrollment not found');
    }
    
    // Delete the course enrollment
    $result = $DB->delete_records('externallecturer_courses', [
        'id' => $courseId,
        'lecturerid' => $lecturerId
    ]);
    
    if ($result) {
        // Update the courses_count in externallecturer table
        $lecturer = $DB->get_record('externallecturer', ['id' => $lecturerId], 'courses_count');
        if ($lecturer && $lecturer->courses_count > 0) {
            $new_count = $lecturer->courses_count - 1;
            $DB->set_field('externallecturer', 'courses_count', $new_count, ['id' => $lecturerId]);
        }
        
        echo json_encode([
            'success' => true, 
            'message' => get_string('coursedeletedsuccess', 'local_externallecturer')
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'error' => get_string('coursedeletederror', 'local_externallecturer')
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => $e->getMessage()
    ]);
}