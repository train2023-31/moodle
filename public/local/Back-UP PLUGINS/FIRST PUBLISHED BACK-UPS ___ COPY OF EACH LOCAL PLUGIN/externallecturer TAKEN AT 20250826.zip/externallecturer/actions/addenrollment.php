<?php
require_once('../../../config.php');
require_login();

$context = context_system::instance();
require_capability('local/externallecturer:manage', $context);

// Get POST data
$lecturerid = required_param('lecturerid', PARAM_INT);
$course = required_param('course', PARAM_INT);
$cost = required_param('cost', PARAM_FLOAT);

// Check if this lecturer-course combination already exists
$existing = $DB->get_record('externallecturer_courses', [
    'lecturerid' => $lecturerid,
    'courseid' => $course
]);

if ($existing) {
    \core\notification::error(get_string('enrollmentaddederror', 'local_externallecturer'));
    redirect(new moodle_url('/local/externallecturer/index.php'));
}

// Create enrollment object
$enrollment = new stdClass();
$enrollment->lecturerid = $lecturerid;
$enrollment->courseid = $course;
$enrollment->cost = $cost;

// Insert into database
try {
    $id = $DB->insert_record('externallecturer_courses', $enrollment);
    
    if ($id) {
        // Update the courses_count in externallecturer table
        $lecturer = $DB->get_record('externallecturer', ['id' => $lecturerid], 'courses_count');
        if ($lecturer) {
            $new_count = $lecturer->courses_count + 1;
            $DB->set_field('externallecturer', 'courses_count', $new_count, ['id' => $lecturerid]);
        }
        
        \core\notification::success(get_string('enrollmentaddedsuccess', 'local_externallecturer'));
    } else {
        \core\notification::error(get_string('enrollmentaddederror', 'local_externallecturer'));
    }
} catch (Exception $e) {
    \core\notification::error(get_string('enrollmentaddederror', 'local_externallecturer'));
}

// Redirect back to the main page
redirect(new moodle_url('/local/externallecturer/index.php'));
