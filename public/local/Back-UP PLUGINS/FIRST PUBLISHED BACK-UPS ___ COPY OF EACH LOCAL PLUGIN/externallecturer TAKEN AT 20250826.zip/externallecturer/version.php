<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_externallecturer';
$plugin->version = 2025081400;
$plugin->requires = 2021051700; // Moodle 3.11+
$plugin->release   = '1.6.1 (Add lecturer_type and nationality fields)';
