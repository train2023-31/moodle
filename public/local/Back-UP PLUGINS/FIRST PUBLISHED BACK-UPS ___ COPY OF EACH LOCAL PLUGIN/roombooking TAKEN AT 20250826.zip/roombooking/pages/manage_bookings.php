<?php
// File: local/roombooking/pages/manage_bookings.php
// Handles the managebookings tab functionality

defined('MOODLE_INTERNAL') || die();

/**
 * Renders the managebookings tab content
 * 
 * @param array $params Required parameters
 * @return string HTML content
 */
function local_roombooking_render_manage_bookings_tab($params) {
    global $DB, $OUTPUT, $PAGE;
    
    $output = '';
    
    // Extract parameters
    $records = $params['records'];
    $sortby = $params['sortby'];
    $direction = $params['direction'];
    $filter_courseid = $params['filter_courseid'];
    $filter_roomid = $params['filter_roomid'];
    $filterForm = $params['filterForm'];
    $pagination = $params['pagination'];
    
    // Display filter form in the header
    $output .= html_writer::start_div('filter-header');
    ob_start();
    $filterForm->display();
    $output .= ob_get_clean();
    $output .= html_writer::end_div();

    // Render the data using the custom renderer
    $renderer = $PAGE->get_renderer('local_roombooking');

    if ($filter_courseid || $filter_roomid) {
        $output .= html_writer::tag('h3', get_string('filteredresults', 'local_roombooking'));
    } else {
        $output .= html_writer::tag('h3', get_string('allclassrooms', 'local_roombooking'));
    }

    // Pass sorting and filter parameters to the renderer
    $output .= $renderer->render_classroom_table($records, $sortby, $direction, [
        'courseid' => $filter_courseid,
        'roomid' => $filter_roomid
    ]);

    // Display pagination by rendering the paging_bar object
    $output .= $OUTPUT->render($pagination);
    
    return $output;
} 