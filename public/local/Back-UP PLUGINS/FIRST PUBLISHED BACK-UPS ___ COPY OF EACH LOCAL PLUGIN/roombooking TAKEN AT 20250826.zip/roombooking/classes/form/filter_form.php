<?php

namespace local_roombooking\form;

defined('MOODLE_INTERNAL') || die();

require_once("$CFG->libdir/formslib.php");

class filter_form extends \moodleform {
    public function definition() {
        global $DB;

        $filterform = $this->_form;

        // Get all courses
        $courses = $DB->get_records('course');
        $course_options = [0 => get_string('any', 'local_roombooking')];
        
        // Filter out site front page (id=1) and add remaining courses to options
        foreach ($courses as $course) {
            if ($course->id > 1) {
                $course_options[$course->id] = $course->fullname;
            }
        }
        $filterform->addElement('select', 'courseid', get_string('course', 'local_roombooking'), $course_options);
        $filterform->setType('courseid', PARAM_INT);

        // // Room selection dropdown
        // $room_options = ['' => get_string('any', 'local_roombooking')] + $DB->get_records_menu('local_roombooking_rooms', null, '', 'id, name');
        // $filterform->addElement('select', 'roomid', get_string('room', 'local_roombooking'), $room_options);
        // $filterform->setType('roomid', PARAM_INT);

        // Room selection dropdown with types - use 0 for "Any" instead of empty string
        $rooms = $DB->get_records('local_roombooking_rooms', null, '', 'id, name, roomtype');
        // $rooms = $DB->get_records('local_roombooking_rooms', ['deleted' => 0], '', 'id, name, roomtype');


        $room_options = [0 => get_string('any', 'local_roombooking')];  // Default option for "Any"

        foreach ($rooms as $room) {
            // Validate room type and get its localized string
            if (isset($room->roomtype) && in_array($room->roomtype, ['fixed', 'dynamic'])) {
                $roomtype = get_string($room->roomtype, 'local_roombooking');
            } else {
                $roomtype = get_string('invalidroomtype', 'local_roombooking');
            }
            // Construct the option label with room name and type
            $room_options[$room->id] = format_string($room->name) . ' (' . $roomtype . ')';
        }

        // Add a dropdown (select) field for selecting a room with types displayed.
        $filterform->addElement('select', 'roomid', get_string('room', 'local_roombooking'), $room_options);
        $filterform->setType('roomid', PARAM_INT);

        // Add submit button
        $this->add_action_buttons(false, get_string('submit', 'local_roombooking'));
    }
}
