<?php
// General plugin strings
$string['pluginname'] = 'خدمة حجز الفصول الدراسية';
$string['registeringroom'] = 'خدمة حجز الفصول الدراسية';
$string['selectacourse'] = 'اختر مقررًا دراسيًا';
$string['selectaroom'] = 'اختر غرفة';
$string['course'] = 'المقرر الدراسي';
$string['room'] = 'الغرفة';
$string['startdatetime'] = 'تاريخ ووقت البدء';
$string['enddatetime'] = 'تاريخ ووقت الانتهاء';
$string['recurrence'] = 'التكرار';
$string['once'] = 'مرة واحدة';
$string['daily'] = 'يوميًا';
$string['weekly'] = 'أسبوعيًا';
$string['monthly'] = 'شهريًا';
$string['bookroom'] = 'حجز الغرفة';
$string['required'] = 'مطلوب';
$string['roomunavailable'] = 'الغرفة المحددة غير متاحة في الوقت المختار.';
$string['course_help'] = 'اختر الدورة المرتبطة بحجز الغرفة. تأكد من اختيار الدورة الصحيحة التي تحتاج الغرفة لها.';
$string['room_help'] = 'اختر الغرفة بناءً على احتياجاتك. يمكنك الاطلاع على نوع الغرفة (ثابتة أو ديناميكية) والسعة القصوى بجانب اسم الغرفة.';

// Success/Error/Notification Messages
$string['successmessage'] = 'تم الحجز بنجاح! لقد تم حجز غرفتك.';
$string['bookingupdated'] = 'تم تحديث الحجز بنجاح.';
$string['errordeletingbooking'] = 'حدث خطأ أثناء حذف الحجز.';
$string['roomnotavailable'] = 'الغرفة غير متاحة';
$string['alternativerooms'] = 'الغرف البديلة المتاحة:';
$string['noalternativerooms'] = 'لا توجد غرف بديلة متاحة للفترة الزمنية المحددة.';
$string['endbeforestart'] = 'يجب أن يكون وقت إنتهاء الحجز بعد وقت البدء';
$string['recurrenceendbeforestart'] = 'لا يمكن أن يكون تاريخ نهاية التكرار قبل تاريخ بداية الحجز';
$string['invalidbookingid'] = 'رقم الحجز غير صالح';
$string['bookingnotfound'] = 'لم يتم العثور على الحجز';
$string['errorupdatingbooking'] = 'حدث خطأ أثناء تحديث الحجز';
$string['erroraddingbooking'] = 'حدث خطأ أثناء إضافة الحجز';
$string['requestsubmitted'] = 'تم إرسال طلب الحجز بنجاح.';
$string['errorcheckingavailability'] = 'حدث خطأ أثناء البحث عن الغرف المتاحة';
$string['availableroomsmessage'] = 'الغرف المتاحة: {$a->available_rooms}';
$string['unexpectederror'] = '!حدث خطأ غير متوقع';
$string['errorprocessingbooking'] = 'حدث خطأ أثناء عملية حجز الغرفة';
$string['successaddclassroom'] = 'تم حجز الغرفة بنجاح';


// Confirmation Strings
$string['deletebookingconfirm'] = 'هل أنت متأكد أنك تريد حذف هذا الحجز؟ لا يمكن التراجع عن هذا الإجراء.';
$string['deleteconfirmation'] = 'هل أنت متأكد أنك تريد حذف الحجز مع المعرّف {$a}؟';
$string['deleteconfirmationdetails'] = 'هل أنت متأكد أنك تريد حذف الحجز للمقرر: <strong>{$a->course}</strong>، في الغرفة: <strong>{$a->room}</strong>، بدءًا من: <strong>{$a->starttime}</strong> وانتهاءً بـ: <strong>{$a->endtime}</strong> مع التكرار: <strong>{$a->recurrence}</strong>?';

// Booking Management & Table UI
$string['username'] = 'اسم المستخدم';
$string['managebookings'] = 'إدارة الحجوزات';
$string['managebookingsdashboard'] = 'لوحة إدارة الفصول الدراسية';
$string['courseid'] = 'معرّف المقرر';
$string['roomid'] = 'معرّف الغرفة';
$string['startdate'] = 'تاريخ البدء';
$string['starttime'] = 'وقت البدء';
$string['endtime'] = 'وقت الانتهاء';
$string['edit'] = 'تعديل';
$string['delete'] = 'حذف';
$string['actions'] = 'الإجراءات';
$string['id'] = 'معرّف';
$string['editbooking'] = 'تعديل الحجز';
$string['deletebooking'] = 'حذف الحجز';

// Permissions & Access Control
$string['roombooking:viewbookings'] = 'عرض حجوزات الغرف';
$string['roombooking:managebookings'] = 'إدارة حجوزات الغرف';
$string['roombooking:deletebookings'] = 'حذف حجوزات الغرف';
$string['nopermissions'] = 'ليس لديك الصلاحيات اللازمة للوصول إلى هذه الميزة.';
$string['nocreatepermissions'] = 'ليس لديك الإذن لإنشاء طلب حجز.';
$string['cannoteditbooking'] = 'ليس لديك إذن بتعديل هذا الحجز.';
$string['noactions'] = 'ليس لديك إذن';
$string['nopermission'] = 'ليس لديك الإذن لأداء هذا الإجراء.';
$string['exceedmaximumduration'] = 'تجاوزت مدة الحجز، الحد الأقصى المسموح به وهو {$a} ساعات.';

// Filter & Search Strings
$string['filter'] = 'تصفية الحجوزات';
$string['applyfilters'] = 'تطبيق الفلاتر';
$string['startdate'] = 'تاريخ البدء';
$string['enddate'] = 'تاريخ الانتهاء';
$string['recurrenceenddate'] = 'تاريخ نهاية التكرار';
//$string['any'] = 'أي';
$string['any'] = 'الكل';
$string['course'] = 'المقرر الدراسي';
$string['bookingday'] = 'يوم الحجز';
$string['classroomfilter'] = 'تصفية حجوزات الفصول الدراسية';
$string['submit'] = 'إرسال';
$string['classroomdata'] = 'بيانات حجز الفصل الدراسي';
$string['noclassroomsfound'] = 'لم يتم العثور على أي حجوزات للفصول الدراسية حسب الفلاتر المختارة.';
$string['filteredresults'] = 'النتائج المصفاة';
$string['allclassrooms'] = 'جميع حجوزات الفصول الدراسية';

// Group Bookings
$string['confirmdeletegroup'] = 'هل أنت متأكد أنك تريد حذف جميع الحجوزات لمجموعة المعرّف {$a}؟';
$string['groupbookingdeleted'] = 'تم حذف جميع الحجوزات لمجموعة المعرّف {$a}.';
$string['editgroupbooking'] = 'تعديل حجز المجموعة';
$string['groupbookingdetails'] = 'الحجوزات في نفس المجموعة:';
$string['deleteallbookings'] = 'هل تريد حذف جميع الحجوزات في هذه المجموعة؟';
$string['bookingdeleted'] = 'تم حذف جميع الحجوزات في المجموعة بنجاح.';

// Additional Settings
$string['settings'] = 'الإعدادات';
$string['enable'] = 'تفعيل نظام الحجز';
$string['enable_desc'] = 'تفعيل أو تعطيل نظام حجز الفصول الدراسية';
$string['role'] = 'الدور المطلوب';
$string['role_desc'] = 'الدور المطلوب لإجراء الحجوزات';
$string['configuration'] = 'إعدادات الحجز';

// Date & Time Formats
$string['strftimedatetime'] = '%d %B %Y، %H:%M'; // مثال للتنسيق، يمكن تعديله حسب الحاجة

// Additional strings for delete confirmations
$string['deleteallbookings'] = 'هل تريد حذف جميع الحجوزات في هذه المجموعة؟';
$string['bookingdetails'] = 'تفاصيل الحجز للمعرّف: {$a}';

$string['managerooms'] = 'إدارة الغرف';
$string['roomname'] = 'اسم الغرفة';
$string['capacity'] = 'السعة';
$string['requiredcapacity'] = 'السعة المطلوبة';
$string['location'] = 'الموقع';
$string['description'] = 'الوصف';
$string['roomadded'] = 'تمت إضافة الغرفة بنجاح';
$string['roomupdated'] = 'تم تحديث الغرفة بنجاح';
$string['roomdeleted'] = 'تم حذف الغرفة بنجاح';
$string['editroom'] = 'تعديل الغرفة';
$string['addroom'] = 'إضافة غرفة جديدة';
$string['existingrooms'] = 'الغرف الحالية';
$string['actions'] = 'الإجراءات';
$string['edit'] = 'تعديل';
$string['delete'] = 'حذف';
$string['norooms'] = 'لم يتم العثور على غرف';
$string['cannotdeleteroom'] = 'لا يمكن حذف الغرفة لأنها مرتبطة بحجوزات حالية';
$string['required'] = 'هذا الحقل مطلوب';
$string['savechanges'] = 'حفظ التغييرات';
$string['cancel'] = 'إلغاء';

$string['invalidcapacity'] = 'يرجى إدخال سعة صالحة.';
$string['roomexceedsmaxcapacity'] = 'السعة المطلوبة تتجاوز الحد الأقصى المسموح به للغرفة ';
$string['validnumber'] = 'يرجى إدخال رقم صحيح.';
$string['invalidrecurrenceenddate'] = '!تاريخ إنتهاء التكرار غير صحيح';
$string['invaliddatetime'] = 'تاريخ البدء/تاريخ الإنتهاء غير صالح';
$string['invalidtimetobook'] = '!تاريخ بداية الحجز يجب أن يكون قبل تاريخ الإنتهاء';
$string['recurrenceendbeforeend'] = ' !تاريخ إنتهاء التكرار يجب أن يكون قبل تاريخ إنتهاء الحجز';
$string['invalidrecurrencetype'] = '!نوع التكرار غير صحيح';
$string['recurrenceintervalisnotsetproperly'] = 'لم يتم ضبط الفاصل الزمني للتكرار بشكل صحيح';

$string['roomtype'] = 'نوع الغرفة';
$string['fixed'] = 'ثابت';
$string['dynamic'] = 'متغير';
$string['invalidroomtype'] = 'تم اختيار نوع غرفة غير صحيح.';
$string['invalidcapacity'] = 'يرجى إدخال سعة صالحة أكبر من الصفر.';

// Column Headers
$string['column_id'] = '#';
$string['column_course'] = 'الدورة';
$string['column_room'] = 'القاعة';
$string['column_capacity'] = 'السعة';
$string['column_start_date'] = 'تاريخ البدء';
$string['column_start_time'] = 'وقت البدء';
$string['column_end_time'] = 'وقت الانتهاء';
$string['column_recurrence'] = 'التكرار';
$string['column_user'] = 'منفذ االطلب';
$string['actions_label'] = 'الإجراءات';
$string['column_status'] = 'الحالة';

// New Strings for Modals
$string['approve_request'] = 'الموافقة';
$string['reject_request'] = 'رفض';
$string['approve_confirmation'] = 'هل أنت متأكد من الموافقة على هذا الطلب؟';
$string['reject_confirmation'] = 'هل أنت متأكد من رفض هذا الطلب؟';
$string['reject_note_placeholder'] = 'يرجى تقديم ملاحظة لرفض الطلب';
$string['reject_note_required'] = 'مطلوب تقديم ملاحظة للرفض.';
$string['approve_success'] = 'تمت الموافقة على الطلب بنجاح.';
$string['reject_success'] = 'تم رفض الطلب بنجاح.';
$string['approve_error'] = 'حدث خطأ أثناء الموافقة على الطلب.';
$string['reject_error'] = 'حدث خطأ أثناء رفض الطلب.';
$string['confirm'] = 'تأكيد';
$string['cancel'] = 'إلغاء';
$string['exportcsv'] = 'تصدير CSV';
$string['clearfilters'] = 'إزالة الفلاتر';

// Status labels
$string['status_pending'] = 'قيد الانتظار';
$string['status_approved'] = 'تمت الموافقة';
$string['status_rejected'] = 'تم الرفض';
$string['unknown_status'] = 'قيد الإجراء  ';
$string['awaiting_approval'] = 'بانتظار الموافقة في مرحلة أخرى';


$string['recurrence_none'] = 'لايوجد';
$string['recurrence_daily'] = 'يومي';
$string['recurrence_weekly'] = 'أسبوعي';
$string['recurrence_monthly'] = 'شهري';
$string['recurrence_unknown'] = 'Unknown';

// Workflow strings
$string['booking_approved'] = 'تمت الموافقة على الحجز بنجاح';
$string['booking_rejected'] = 'تم رفض الحجز بنجاح';
$string['confirm_title'] = 'التأكيد';
$string['confirm_approve'] = 'هل أنت متأكد أنك تريد الموافقة على هذا الحجز؟';
$string['confirm_reject'] = 'هل أنت متأكد أنك تريد رفض هذا الحجز؟';
$string['rejection_reason'] = ' تم رفض طلب الحجز الخاص بك. السبب';
$string['approval_note'] = 'ملاحظة الموافقة';
$string['awaiting_approval'] = 'بانتظار الموافقة في مرحلة مختلفة';
$string['statusalreadyfinal'] = 'تمت الموافقة النهائية على هذا الحجز من قبل';
$string['cannotrejectapproved'] = 'لا يمكن رفض حجز تمت الموافقة عليه من قبل';
$string['cannotreject'] = 'لا يمكن رفض هذا الحجز في مرحلته الحالية';

// Management Dashboard
$string['manage'] = 'إدارة';
$string['viewbookings'] = 'عرض الحجوزات';
$string['viewfilterbookings'] = 'عرض وتصفية حجوزات {$a->type}';
$string['reports'] = 'التقارير';
$string['generatereports'] = 'إنشاء تقارير وإحصائيات الحجز';
$string['vieweditrooms'] = 'عرض وإنشاء وتعديل تفاصيل الفصول الدراسية';
$string['bookinginterface'] = 'واجهة الحجز';
$string['managementdashboard'] = 'لوحة الإدارة';

// Additional capability strings
$string['roombooking:managerooms'] = 'إدارة غرف حجز الفصول الدراسية';

$string['invalidroomid'] = 'معرّف الغرفة غير صالح.';
$string['roomnotavailableWithlistofrooms'] = 'الغرفة المحددة غير متاحة. الغرف البديلة المتاحة: {$a->available_rooms}.';

// إظهار/إخفاء الغرف المؤرشفة (المخفية)
$string['showhidden'] = 'إظهار الغرف المخفية';
$string['showonlyvisible'] = 'إظهار الغرف الظاهرة فقط';
$string['hide'] = 'إخفاء';
$string['restore'] = 'استرجاع';

