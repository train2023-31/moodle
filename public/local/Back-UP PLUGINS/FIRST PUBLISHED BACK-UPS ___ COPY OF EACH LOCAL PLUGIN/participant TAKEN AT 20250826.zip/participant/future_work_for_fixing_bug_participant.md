# Bug Tracking - Participant Module

## Bug #1: Misleading Arabic Naming - "مستخدم" Should Be Changed

**Issue Description:**
The current Arabic naming uses "مستخدم" (user) which is too generic and doesn't accurately describe the training assignment purpose of the system.

**Expected Behavior:**
- Use more specific Arabic terms like "طلب إسناد تدريبي" (Training Assignment Request)
- Consistent terminology throughout the interface

**Current Behavior:**
- Generic "مستخدم" (user) term used throughout
- Confusing for users trying to understand the system's purpose

**Recommended Solution:**
- Change "مستخدم" to "طلب إسناد تدريبي" (Training Assignment Request)
- Update language strings in `/lang/ar/local_participant.php`
- Ensure consistent terminology across interface

**Priority:** Medium
**Status:** Open
**Date Reported:** [Current Date]

---
