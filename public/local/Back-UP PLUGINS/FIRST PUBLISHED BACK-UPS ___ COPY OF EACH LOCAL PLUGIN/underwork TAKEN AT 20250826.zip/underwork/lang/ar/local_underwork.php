<?php
// Arabic language strings for the 'Under Work' plugin.

$string['pluginname'] = 'قيد العمل';
$string['underworkmessage'] = 'جاري العمل على هذه الصفحة   .';
$string['backtohome'] = 'العودة إلى الصفحة الرئيسية';

// Capability strings
$string['underwork:view'] = 'عرض الصفحات قيد العمل';
