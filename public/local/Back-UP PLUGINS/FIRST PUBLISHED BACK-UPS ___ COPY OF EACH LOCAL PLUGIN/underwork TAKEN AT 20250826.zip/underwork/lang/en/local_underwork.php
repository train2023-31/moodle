<?php
// English language strings for the 'Under Work' plugin.

$string['pluginname'] = 'Under Work';
$string['underworkmessage'] = 'This page is under work.';
$string['backtohome'] = 'Return to Home Page';

// Capability strings
$string['underwork:view'] = 'View under work pages';
