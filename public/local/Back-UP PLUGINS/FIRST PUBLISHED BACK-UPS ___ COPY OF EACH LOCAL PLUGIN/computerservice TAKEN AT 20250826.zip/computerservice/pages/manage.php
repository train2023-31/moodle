<?php
// ============================================================================
//  Management view – filter, view, approve, and reject device requests
// ============================================================================

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/local/computerservice/classes/form/filter_form.php');
require_once($CFG->dirroot . '/local/computerservice/classes/simple_workflow_manager.php');

$fromrequestphp = defined('FROM_REQUEST_PHP') && FROM_REQUEST_PHP;

if (!$fromrequestphp) {
    require_login();
    $context = context_system::instance();
    require_capability('local/computerservice:managerequests', $context);

    $PAGE->set_url('/local/computerservice/manage.php');
    $PAGE->set_context($context);
    $PAGE->set_title(get_string('managerequests', 'local_computerservice'));
    $PAGE->set_heading(get_string('managerequests', 'local_computerservice'));
}

/* ───────────────────────────── LIST + FILTER ───────────────────────────── */

$actionurl  = new moodle_url('/local/computerservice/index.php', ['tab' => 'manage']);
$filterform = new \local_computerservice\form\filter_form($actionurl, [], 'post', '', ['class' => 'custom-filter-form']);

$conditions = [];
if ($filterdata = $filterform->get_data()) {
    foreach (['statusid' => 'status_id', 'courseid' => 'courseid', 'userid' => 'userid'] as $form => $dbfield) {
        if (!empty($filterdata->$form)) {
            $conditions[$dbfield] = $filterdata->$form;
        }
    }
    
    // Handle urgency filter separately to properly handle '0' value
    if (isset($filterdata->urgency) && $filterdata->urgency !== '') {
        $conditions['is_urgent'] = (int)$filterdata->urgency; // Convert to integer for database comparison
    }
    
    // Debug: Log the filter data for troubleshooting
    if (debugging()) {
        debugging('Filter data: ' . print_r($filterdata, true));
        debugging('Conditions: ' . print_r($conditions, true));
    }
}

$sqlconditions = [];
$params = [];
foreach ($conditions as $field => $value) {
    $sqlconditions[] = "r.$field = :$field";
    $params[$field]  = $value;
}
$sqlwhere = $sqlconditions ? 'WHERE ' . implode(' AND ', $sqlconditions) : '';

$langfield = current_language() === 'ar' ? 'display_name_ar' : 'display_name_en';

$sql = "SELECT r.*,
               s.$langfield AS statusname
          FROM {local_computerservice_requests} r
          JOIN {course}                 c ON c.id = r.courseid
          JOIN {local_status}           s ON s.id = r.status_id
        $sqlwhere
      ORDER BY r.timecreated DESC";

$requests   = $DB->get_records_sql($sql, $params);
$renderable = new \local_computerservice\output\manage_requests($requests);

/* ───────────────────────────── OUTPUT ───────────────────────────── */

if (!$fromrequestphp) {
    echo $OUTPUT->header();
    $filterform->display();
    echo $OUTPUT->render($renderable);
    echo $OUTPUT->footer();
}
