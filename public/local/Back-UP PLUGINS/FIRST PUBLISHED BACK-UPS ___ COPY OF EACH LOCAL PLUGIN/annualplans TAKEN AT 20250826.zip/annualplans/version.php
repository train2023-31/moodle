<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_annualplans';
$plugin->version = 2025081200; // The current date in YYYYMMDDXX format
$plugin->requires = 2020110300; // Moodle 3.10 release and later
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.9 (Build: 2025081200 Audit Fields)';
