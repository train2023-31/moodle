<?php
/**
 * Installation function for local_annualplans plugin
 * 
 * IMPORTANT INSTALLATION NOTES:
 * =============================
 * Before running this installation, ensure that:
 * 
 * 1. COURSE CATEGORIES SETUP:
 *    - Create the required course categories in Moodle (Site administration > Courses > Manage courses and categories)
 *    - Note down the category IDs from the mdl_course_categories table
 *    - Update the type_id values in the $course_codes_data array below to match your category IDs
 * 
 * 2. TO FIND CATEGORY IDs:
 *    Run this SQL query: SELECT id, name FROM mdl_course_categories WHERE name IN ('Intelligence', 'Management', 'Language', 'Administration', 'Technology');
 *    
 * 3. REQUIRED CATEGORIES:
 *    - Intelligence (update type_id for 'INT' code)
 *    - Management (update type_id for 'MGT' code)  
 *    - Language (update type_id for 'LAN' code)
 *    - Administration (update type_id for 'ADM' code)
 *    - Technology (update type_id for 'TEC' code)
 * 
 * 4. IF CATEGORIES DON'T EXIST:
 *    - Create them manually in Moodle interface, OR
 *    - Set type_id to NULL for codes that don't have matching categories, OR
 *    - Create the categories programmatically before this installation
 */
function xmldb_local_annualplans_install() {
    global $DB;
    $dbman = $DB->get_manager(); // Loads the database manager

    // Begin a transaction before making database changes.
    $transaction = $DB->start_delegated_transaction();
    $dummy_data = [
        [
            'year' => 2025,
            'title' => 'الخطة السنوية الأولية 2025',
            'date_created' => time(),
            'status' => 'نشط',
            'description' => 'هذا هو وصف الخطة السنوية الأولية.'
        ],
        [
            'year' => 2025,
            'title' => 'الخطة السنوية الثانوية 2025',
            'date_created' => time(),
            'status' => '',
            'description' => 'هذا هو وصف الخطة السنوية الثانوية.'
        ]
    ];
    foreach ($dummy_data as $data) {
        if (!$DB->insert_record('local_annual_plan', (object) $data)) {
            // If there's an error inserting a record, throw an exception which will cause the transaction to roll back.
            throw new dml_exception('inserterror', 'Error inserting dummy data into local_annual_plan_table.');
        }
    } 

        $fin_data = [
        [
            'id' => 1,
            'code' => 'X',
            'description_en' => 'Others',
            'description_ar' => 'أخرى'
        ],
         [
            'id' => 2,
            'code' => 'T',
            'description_en' => 'Training Plan',
            'description_ar' => 'خطة التدريب'
        ],
        [
            'id' => 3,
            'code' => 'P',
            'description_en' => 'Project',
            'description_ar' => 'مشروع'
        ],
        [
            'id' => 4,
            'code' => 'O',
            'description_en' => 'Work',
            'description_ar' => 'مهمة عمل'
        ],
    ];
    foreach ($fin_data as $data) {
        if (!$DB->insert_record('local_annual_plan_finance_source', (object) $data)) {
            // If there's an error inserting a record, throw an exception which will cause the transaction to roll back.
            throw new dml_exception('inserterror', 'Error inserting dummy data into local_annual_plan_finance_source table.');
        }
    }


            $courseLvl_data = [
        [
            'id' => 1,
            'name' => 'BSCOC',
            'description_en' => 'BSC Officer Candidates',
            'description_ar' => 'الدورة التأسيسية ض.م',
            'is_internal' => 1
        ],
         [
            'id' => 2,
            'name' => 'BSCP',
            'description_en' => 'BSC writers',
            'description_ar' => 'الدوة التأسيسة للكتبة',
            'is_internal' => 1
        ],
        [
            'id' => 3,
            'name' => 'SACI',
            'description_en' => 'Security Awareness Course',
            'description_ar' => 'دورات ت.أ',
            'is_internal' => 1
        ],
        [
            'id' => 4,
            'name' => 'DSC',
            'description_en' => 'Department Specialized courses',
            'description_ar' => 'دورات تخصصية لأقسام.د',
            'is_internal' => 1
        ],
        [
            'id' => 5,
            'name' => 'OQC',
            'description_en' => 'Officers Qualification Course',
            'description_ar' => 'دورة ت.ض',
            'is_internal' => 1
        ],
        [
            'id' => 6,
            'name' => 'MSACE',
            'description_en' => 'M Security Awarenss Course - External',
            'description_ar' => 'دورة.ت.أ.ع.خ',
            'is_internal' => 0
        ],
        [
            'id' => 7,
            'name' => 'CSACE',
            'description_en' => 'Civil Security Awarenss Course - External',
            'description_ar' => 'دورة ت.أ.م.خ',
            'is_internal' => 0
        ]        
    ];
    foreach ($courseLvl_data as $data) {
        if (!$DB->insert_record('local_annual_plan_course_level', (object) $data)) {
            // If there's an error inserting a record, throw an exception which will cause the transaction to roll back.
            throw new dml_exception('inserterror', 'Error inserting dummy data into local_annual_plan_course_level table.');
        }
    }

    // Insert default course codes
    // ================================================================================================
    // CRITICAL: UPDATE type_id VALUES BEFORE INSTALLATION
    // ================================================================================================
    // The type_id values below MUST match the actual category IDs in your mdl_course_categories table.
    // 
    // STEPS TO UPDATE:
    // 1. Check your course categories: SELECT id, name FROM mdl_course_categories;
    // 2. Find the IDs for these categories: Intelligence, Management, Language, Administration, Technology
    // 3. Update the corresponding type_id values below
    // 4. If a category doesn't exist, either create it first or set type_id to NULL
    //
    // EXAMPLE:
    // If your Intelligence category has ID 15 instead of 9, change:
    // 'type_id' => 9, // to 'type_id' => 15,
    // ================================================================================================
    $course_codes_data = [
        // Category codes
        [
            'type' => 'category',
            'code_en' => 'MGT',
            'code_ar' => 'ادر',
            'description_en' => 'Management',
            'description_ar' => 'إدارة',
            'type_id' => 7, // This type_id depends on the course_categories table rows
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'category',
            'code_en' => 'LAN',
            'code_ar' => 'لغه',
            'description_en' => 'Language',
            'description_ar' => 'اللغة',
            'type_id' => 8, // This type_id depends on the course_categories table rows
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'category', 
            'code_en' => 'IST',
            'code_ar' => 'ستخ',
            'description_en' => 'Intelligence',
            'description_ar' => 'الذكاء',
            'type_id' => 9, // This type_id depends on the course_categories table rows
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'category',
            'code_en' => 'COM',
            'code_ar' => 'حسب',
            'description_en' => 'Computer',
            'description_ar' => 'حاسب آلي',
            'type_id' => 10, // This type_id depends on the course_categories table rows
            'timecreated' => time(),
            'timemodified' => time()
        ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'a',
        //     'code_ar' => 'a', 
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'b',
        //     'code_ar' => 'b',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category', 
        //     'code_en' => 'c',
        //     'code_ar' => 'c',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'd',
        //     'code_ar' => 'd',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'e',
        //     'code_ar' => 'e',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'f',
        //     'code_ar' => 'f',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'g',
        //     'code_ar' => 'g',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'h',
        //     'code_ar' => 'h',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'i',
        //     'code_ar' => 'i',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'j',
        //     'code_ar' => 'j',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'k',
        //     'code_ar' => 'k',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'l',
        //     'code_ar' => 'l',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'm',
        //     'code_ar' => 'm',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'n',
        //     'code_ar' => 'n',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'o',
        //     'code_ar' => 'o',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'p',
        //     'code_ar' => 'p',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'q',
        //     'code_ar' => 'q',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'r',
        //     'code_ar' => 'r',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 's',
        //     'code_ar' => 's',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 't',
        //     'code_ar' => 't',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'u',
        //     'code_ar' => 'u',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'v',
        //     'code_ar' => 'v',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'w',
        //     'code_ar' => 'w',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'x',
        //     'code_ar' => 'x',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'y',
        //     'code_ar' => 'y',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'z',
        //     'code_ar' => 'z',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'aa',
        //     'code_ar' => 'aa',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ab',
        //     'code_ar' => 'ab',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ac',
        //     'code_ar' => 'ac',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ad',
        //     'code_ar' => 'ad',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ae',
        //     'code_ar' => 'ae',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'af',
        //     'code_ar' => 'af',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ag',
        //     'code_ar' => 'ag',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ah',
        //     'code_ar' => 'ah',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ai',
        //     'code_ar' => 'ai',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'aj',
        //     'code_ar' => 'aj',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ak',
        //     'code_ar' => 'ak',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'al',
        //     'code_ar' => 'al',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'am',
        //     'code_ar' => 'am',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'an',
        //     'code_ar' => 'an',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // [
        //     'type' => 'category',
        //     'code_en' => 'ao',
        //     'code_ar' => 'ao',
        //     'description_en' => 'Administration',
        //     'description_ar' => 'إدارة',
        //     'type_id' => null, // This type_id depends on the course_categories table rows
        //     'timecreated' => time(),
        //     'timemodified' => time()
        // ],
        // Targeted group codes
        [
            'type' => 'targeted_group',
            'code_en' => 'O',
            'code_ar' => 'O',
            'description_en' => 'Officer',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'targeted_group',
            'code_en' => 'NO',
            'code_ar' => 'NO',
            'description_en' => 'Non-officer',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'targeted_group',
            'code_en' => 'X',
            'code_ar' => 'X',
            'description_en' => 'Others',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        // Group number codes
        [
            'type' => 'group_number',
            'code_en' => '1',
            'code_ar' => '1',
            'description_en' => 'Group 1',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'group_number',
            'code_en' => '2',
            'code_ar' => '2',
            'description_en' => 'Group 2',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'group_number',
            'code_en' => '3',
            'code_ar' => '3',
            'description_en' => 'Group 3',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        // Course codes
        [
            'type' => 'course',
            'code_en' => '01',
            'code_ar' => '01',
            'description_en' => 'Batch no 01',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'course',
            'code_en' => '02',
            'code_ar' => '02',
            'description_en' => 'Batch no 02',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'course',
            'code_en' => '03',
            'code_ar' => '03',
            'description_en' => 'Batch No 03',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
                // Course grades
        [
            'type' => 'grade',
            'code_en' => '1',
            'code_ar' => '1',
            'description_en' => 'Beginner',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'grade',
            'code_en' => '2',
            'code_ar' => '2',
            'description_en' => 'Intermediate',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ],
        [
            'type' => 'grade',
            'code_en' => '3',
            'code_ar' => '3',
            'description_en' => 'Advance',
            'description_ar' => '',
            'type_id' => null,
            'timecreated' => time(),
            'timemodified' => time()
        ]
    ];

    foreach ($course_codes_data as $data) {
        if (!$DB->insert_record('local_annual_plan_course_codes', (object) $data)) {
            // If there's an error inserting a record, throw an exception which will cause the transaction to roll back.
            throw new dml_exception('inserterror', 'Error inserting dummy data into local_annual_plan_course_codes table.');
        }
    }

    // If we reach here, everything has been successful, commit the transaction.
    $transaction->allow_commit();
    
    // ================================================================================================
    // POST-INSTALLATION VERIFICATION
    // ================================================================================================
    // After installation, verify the data was inserted correctly by running these queries:
    // 
    // 1. Check annual plans: SELECT * FROM mdl_local_annual_plan;
    // 2. Check finance sources: SELECT * FROM mdl_local_annual_plan_finance_source;
    // 3. Check course levels: SELECT * FROM mdl_local_annual_plan_course_level;
    // 4. Check course codes: SELECT * FROM mdl_local_annual_plan_course_codes;
    // 5. Verify category links: 
    //    SELECT cc.*, cat.name as category_name 
    //    FROM mdl_local_annual_plan_course_codes cc 
    //    LEFT JOIN mdl_course_categories cat ON cc.type_id = cat.id 
    //    WHERE cc.type = 'category';
    // 
    // If any category shows NULL in category_name, update the type_id value in the course_codes table.
    // ================================================================================================
}
?>
