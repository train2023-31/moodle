<?php
$definitions = array(
    'annual_plan_cache' => array(
        'mode' => cache_store::MODE_APPLICATION,
    ),
);
