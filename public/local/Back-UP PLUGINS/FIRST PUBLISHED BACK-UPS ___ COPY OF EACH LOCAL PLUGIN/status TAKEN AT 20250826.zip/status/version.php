<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_status';
$plugin->version   = 2025070803; // Added participants_workflow
$plugin->requires  = 2020061500; // Moodle 3.9+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '3.0.7 - PARTICIPANTS WORKFLOW ADDED';
