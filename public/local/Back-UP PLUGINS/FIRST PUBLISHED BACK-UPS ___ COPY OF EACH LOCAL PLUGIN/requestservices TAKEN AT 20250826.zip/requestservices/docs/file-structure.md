# File Structure Documentation

## Root Directory Files

### version.php
**Purpose**: Plugin metadata and version information
- Defines plugin component name (`local_requestservices`)
- Sets plugin version (2025071301)
- Specifies minimum Moodle version requirement (2022041900)
- Declares maturity level and release version

### index.php
**Purpose**: Main entry point and tab controller
- Handles course context and user authentication
- Manages tab navigation system
- Includes capability checking (`local/requestservices:view`)
- Dynamically loads tab content from `/tabs/` directory
- Supports 6 main tabs: allrequests, computerservicesTab, financialservices, registeringroom, requestparticipant, residencebooking

**Key Functions**:
- Course ID validation and context setup
- Tab parameter handling
- Dynamic tab file inclusion
- Error handling for missing tab files

### lib.php
**Purpose**: Core plugin functions and Moodle integration
- Contains `local_requestservices_extend_navigation_course()` function
- Adds the plugin to course navigation menu
- Implements capability checking for navigation display

## Directory Structure

### /db/
Contains database-related configurations

#### access.php
**Purpose**: Capability definitions
- Defines `local/requestservices:view` capability
- Sets permission context (CONTEXT_COURSE)
- Grants access to teachers and editing teachers by default

### /tabs/
Contains individual tab implementation files

#### allrequests.php (2.2KB, 57 lines)
**Purpose**: Overview tab showing all request types
- Implements vertical subtab navigation
- Uses Bootstrap grid system for layout
- Provides unified view across all service categories

#### computerservicesTab.php (3.1KB, 79 lines)
**Purpose**: Computer services request interface
- Integrates with `local_computerservice` plugin
- Includes request form and workflow manager
- Handles form submission and processing

#### financialservices.php (2.8KB, 77 lines)
**Purpose**: Financial services request interface
- Manages budget and funding requests
- Includes form handling and validation

#### registeringroom.php (2.6KB, 53 lines)
**Purpose**: Room registration and booking interface
- Handles facility booking requests
- Manages room availability and scheduling

#### requestparticipant.php (4.0KB, 86 lines)
**Purpose**: Lecturer and participant request interface
- Manages requests for teaching staff and role players
- Handles participant assignment and scheduling

#### residencebooking.php (2.1KB, 53 lines)
**Purpose**: Accommodation booking interface
- Manages residence and dormitory booking requests
- Handles availability and booking confirmation

### /tabs/subtabs/
Contains subtab implementation files for detailed views

#### computerservicesview.php (1.8KB, 50 lines)
**Purpose**: Detailed view for computer service requests

#### financialservicesview.php (1.3KB, 40 lines)
**Purpose**: Detailed view for financial service requests

#### participantview.php (4.3KB, 99 lines)
**Purpose**: Detailed view for participant requests

#### registeringroomview.php (1.5KB, 49 lines)
**Purpose**: Detailed view for room registration requests

#### residencebookingview.php (1.6KB, 42 lines)
**Purpose**: Detailed view for residence booking requests

### /templates/
Contains Mustache templates for UI rendering

#### computerservices_requests.mustache (1.6KB, 63 lines)
**Purpose**: Template for computer services request display
- Shows device requests and quantities
- Displays request status and dates

#### financialservicesview.mustache (1.6KB, 64 lines)
**Purpose**: Template for financial services display
- Shows funding types and requested amounts
- Displays budget approval status

#### participantview.mustache (1.2KB, 40 lines)
**Purpose**: Template for participant request display
- Shows lecturer and role player requests
- Displays availability and assignment status

#### registeringroomview.mustache (15KB, 378 lines)
**Purpose**: Comprehensive room registration template
- Complex form with multiple room options
- Includes scheduling and availability display

#### residencebookingview.mustache (15KB, 381 lines)
**Purpose**: Comprehensive residence booking template
- Detailed accommodation booking form
- Includes room types and amenity selection

### /classes/output/
Contains PHP renderer classes for template data preparation

#### computerservices_requests.php (1.2KB, 41 lines)
**Purpose**: Data renderer for computer services template

#### financialservicesview.php (1.2KB, 40 lines)
**Purpose**: Data renderer for financial services template

#### participantview.php (1.1KB, 37 lines)
**Purpose**: Data renderer for participant template

#### registeringroomview.php (6.0KB, 143 lines)
**Purpose**: Data renderer for room registration template

#### residencebookingview.php (4.0KB, 98 lines)
**Purpose**: Data renderer for residence booking template

### /lang/
Contains language string definitions

#### /lang/en/local_requestservices.php (943B, 25 lines)
**Purpose**: English language strings
- Plugin name and tab labels
- Form field labels and messages
- Status and error messages

#### /lang/ar/local_requestservices.php (1.1KB, 25 lines)
**Purpose**: Arabic language strings
- Arabic translations for all English strings
- RTL (Right-to-Left) language support

## Dependencies

### External Plugin Dependencies
- **local_computerservice**: Required for computer services functionality
  - Provides request form (`request_form.php`)
  - Provides workflow manager (`simple_workflow_manager.php`)

### Moodle Core Dependencies
- **Navigation API**: For course navigation integration
- **Capability System**: For permission management
- **Template System**: For Mustache template rendering
- **Tab API**: For tab navigation functionality
- **Bootstrap Framework**: For responsive layout

## File Naming Conventions

- **Tab files**: Named after their function (e.g., `computerservicesTab.php`)
- **Template files**: Use `.mustache` extension with descriptive names
- **Language files**: Follow Moodle standard (`local_requestservices.php`)
- **Class files**: Follow PSR-4 autoloading standards
- **Renderer files**: Located in `/classes/output/` directory 