<?php
defined('MOODLE_INTERNAL') || die();

global $PAGE, $OUTPUT, $DB, $USER, $CFG;

// Ensure necessary variables are available
$courseid = required_param('id', PARAM_INT);
$course = get_course($courseid);
$context = context_course::instance($courseid);

$lang = current_language();
$devicenamefield = ($lang === 'ar') ? 'd.devicename_ar' : 'd.devicename_en';

// Use LEFT JOINs to ensure all requests are shown even if device/course is missing
$sql = "
   SELECT csr.id, csr.courseid, c.fullname as course, csr.numdevices, csr.deviceid, $devicenamefield as devicename, csr.timecreated, csr.status_id 
FROM {local_computerservice_requests} csr
LEFT JOIN {course} c ON csr.courseid = c.id
LEFT JOIN {local_computerservice_devices} d ON csr.deviceid = d.id
WHERE csr.courseid = :course_id
ORDER BY csr.timecreated DESC
";

$params = ['course_id' => $courseid];
$computerservices = $DB->get_records_sql($sql, $params);

// Include the simple_workflow_manager class
require_once($CFG->dirroot . '/local/computerservice/classes/simple_workflow_manager.php');

// Prepare data for renderable
$prepared = [];
foreach ($computerservices as $row) {
    $row->devices = $row->devicename ?? '';
    $row->readable_status = \local_computerservice\simple_workflow_manager::get_status_name($row->status_id);
    $prepared[] = $row;
}

// Debug: Output the prepared data for the renderable
// echo '<pre style="background:#fffbe6; color:#333; border:1px solid #ccc; padding:10px;">';
// print_r($prepared);
// echo '</pre>';

// Include the renderable class
require_once($CFG->dirroot . '/local/requestservices/classes/output/computerservices_requests.php');

// Instantiate the renderable
$renderable = new \local_requestservices\output\computerservices_requests($prepared);

// Output the page
echo $OUTPUT->render($renderable);