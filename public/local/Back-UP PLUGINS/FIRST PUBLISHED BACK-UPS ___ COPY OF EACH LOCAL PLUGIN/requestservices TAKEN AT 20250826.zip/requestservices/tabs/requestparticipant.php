<?php
require_once($CFG->dirroot . '/local/participant/classes/form/request_form.php');

$context = context_system::instance();
// require_capability('local/participant:addrequest', $context);

$actionurl = new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'requestparticipant']);

$mform = new \local_participant\form\request_form($actionurl, ['courseid' => $courseid]);


// Process the form if it's submitted.
if ($mform->is_cancelled()) {
    // Redirect to the main page or a specific tab if the form is cancelled.
    redirect(new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'requestparticipant']));
} else if ($data = $mform->get_data()) {
    // Process the form data.
    try {
        // Fetch necessary course data.
        $moodle_course = $DB->get_record('course', ['id' => $data->courseid], 'idnumber');

        $course_idnumber_part = explode('-', $moodle_course->idnumber)[0];
        $plan_course = $DB->get_record('local_annual_plan_course', ['courseid' => $course_idnumber_part], 'annualplanid');

        // Get participant type data for automatic compensation calculation
        $participant_type = $DB->get_record('local_participant_request_types', 
            ['id' => $data->participant_type_id], 
            'cost, calculation_type', 
            MUST_EXIST
        );
        
        // Calculate compensation amount based on type and duration
        $compensation_amount = 0;
        if ($participant_type->calculation_type == 'dynamic') {
            // For dynamic types (like external lecturers), use the amount from form
            $compensation_amount = isset($data->compensation_amount) ? $data->compensation_amount : 0;
        } else {
            // For fixed rates (days/hours), calculate automatically
            $compensation_amount = $data->duration_amount * $participant_type->cost;
        }

        $new_request = new stdClass();
        $new_request->course_id = $data->courseid;
        $new_request->annual_plan_id = $plan_course->annualplanid;
        $new_request->participant_type_id = $data->participant_type_id;
        $new_request->duration_amount = $data->duration_amount;
        $new_request->compensation_amount = $compensation_amount;
        $new_request->is_internal_participant = $data->participant_type_id == 5 ? 0 : 1;
        $new_request->external_lecturer_id = !empty($data->external_lecturer_id) ? $data->external_lecturer_id : null;
        $new_request->internal_user_id = !empty($data->internal_user_id) ? $data->internal_user_id : null;
        $new_request->requested_date = date('Y-m-d H:i:s', $data->requested_date);
        $new_request->request_status_id = \local_participant\simple_workflow_manager::get_initial_status_id();
        $new_request->is_approved = 0;
        $new_request->created_by = $USER->id ?? 0;
        $new_request->time_created = time();
        $new_request->time_modified = time();

        // Insert the new request into the database.
        $DB->insert_record('local_participant_requests', $new_request);

        // Redirect upon successful submission.
        // redirect(
        //     new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'requestparticipant']),
        //     get_string('requestadded', 'local_participant'),
        //     null,
        //     \core\output\notification::NOTIFY_SUCCESS
        // );
        \core\notification::add(
            get_string('requestadded', 'local_participant'),
            \core\notification::SUCCESS
        );
    } catch (dml_exception $e) {
        // Handle database errors.
        debugging("Database insert error: " . $e->getMessage(), DEBUG_DEVELOPER);
        redirect(
            new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'requestparticipant']),
            get_string('inserterror', 'local_participant'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
}

// Display the form.
$mform->display();
