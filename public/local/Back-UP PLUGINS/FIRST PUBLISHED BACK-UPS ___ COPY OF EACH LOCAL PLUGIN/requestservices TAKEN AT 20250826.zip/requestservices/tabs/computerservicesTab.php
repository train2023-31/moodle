<?php




// Require login and permission to view the tab.

require_capability('local/requestservices:view', $context);

// Include the form class and workflow manager
require_once($CFG->dirroot . '/local/computerservice/classes/form/request_form.php');
require_once($CFG->dirroot . '/local/computerservice/classes/simple_workflow_manager.php');


 
    $actionurl = new moodle_url('/local/requestservices/index.php', array('id' => $courseid, 'tab' => 'computerservicesTab'));
    
    // Instantiate the form
    $mform = new \local_computerservice\form\request_form($actionurl, array('id' => $courseid));
    
    
    // Process form data if submitted
    if ($mform->is_cancelled()) {
        // Handle form cancellation (e.g., redirect to another page)
        redirect(new moodle_url('/local/requestservices/index.php', array('id' => $courseid, 'tab' => 'computerservicesTab')));
    } else if ($data = $mform->get_data()) {
        // Handle form submission with enhanced workflow system
        
        // Capture the single selected device ID
        $selecteddeviceid = $data->deviceid;
        
        // Fetch the device name using bilingual support
        $device = $DB->get_record('local_computerservice_devices',
                                  ['id' => $selecteddeviceid],
                                  'devicename_en, devicename_ar',
                                  MUST_EXIST);

        $selecteddevicename = (current_language() === 'ar')
            ? $device->devicename_ar
            : $device->devicename_en;

        // Get default status ID from workflow
        $defaultstatusid = \local_computerservice\simple_workflow_manager::get_initial_status_id();

        // Calculate urgent status
        $now = time();
        $needed = $data->request_needed_by;
        // OLD CODE: Requests needed within 48 hours (2 days) were marked urgent
        // $is_urgent = (($needed - $now) < 2 * DAYSECS) ? 1 : 0;
        // NEW CODE: Only requests needed today or tomorrow are marked urgent
        $is_urgent = (($needed - $now) < DAYSECS) ? 1 : 0;

        // Prepare the data for insertion into the database
        $record = new stdClass();
        $record->userid = $USER->id;
        $record->courseid = $data->courseid;
        $record->numdevices = $data->numdevices;
        $record->devices = $selecteddevicename;
        $record->deviceid = $selecteddeviceid; // Save the device ID for correct reporting
        $record->comments = $data->comments;
        $record->status_id = $defaultstatusid;  // Use new workflow system
        $record->timecreated = $now;
        $record->timemodified = $now;
        $record->request_needed_by = $needed;
        $record->is_urgent = $is_urgent;

        // Insert the record into the local_computerservice_requests table
        $DB->insert_record('local_computerservice_requests', $record);

        // Add a redirect after successful insertion to avoid double submission
        redirect(
            new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'computerservicesTab']),
            get_string('requestsubmitted', 'local_computerservice'),
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    }
    
    $mform->display();


