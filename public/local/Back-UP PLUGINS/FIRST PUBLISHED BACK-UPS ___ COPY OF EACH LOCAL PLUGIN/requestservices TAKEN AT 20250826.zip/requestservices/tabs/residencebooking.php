<?php
require_once($CFG->dirroot .'/local/residencebooking/classes/form/residencebooking_form.php');

$context = context_system::instance();
// require_capability('local/participant:addrequest', $context);

$actionurl = new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'residencebooking']);

//need updating here dont forget
$mform = new \local_residencebooking\form\residencebooking_form($actionurl, ['courseid' => $courseid]);


   // Process form data if submitted
   if ($mform->is_cancelled()) {
    // Handle form cancellation (e.g., redirect to another page)
    redirect(new moodle_url('/local/requestservices/index.php', array('id' => $courseid, 'tab' => 'residencebooking')));
} else if ($data = $mform->get_data()) {
    // Prepare data for insertion into the database
    $record = new stdClass();
    $record->courseid = $data->courseid;
    $record->residence_type = $data->residence_type;
    $record->start_date = $data->start_date;
    $record->end_date = $data->end_date;
    $record->purpose = $data->purpose;
    $record->notes = $data->notes;
    $record->guest_name = $data->guest_name;
    $record->service_number = $data->service_number;
    $record->userid = $data->userid;
    $record->status_id = \local_residencebooking\simple_workflow_manager::get_initial_status_id();  // Use the correct initial status from workflow manager


    // Insert into the database
    $DB->insert_record('local_residencebooking_request', $record);
    
     /*    \core\notification::add(
        get_string('requestsubmitted', 'local_residencebooking'),
        \core\notification::SUCCESS
    ); */

           //Add a redirect after successful insertion to avoid double submission
        redirect(
    new moodle_url('/local/requestservices/index.php', ['id' => $courseid, 'tab' => 'residencebooking']),
    get_string('requestsubmitted', 'local_residencebooking'),
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
require_sesskey();  // Add this after form submission check if applicable

}

$mform->display();

