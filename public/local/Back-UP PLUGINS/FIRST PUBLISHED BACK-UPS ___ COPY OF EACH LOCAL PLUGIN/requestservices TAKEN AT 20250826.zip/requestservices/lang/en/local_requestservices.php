<?php
$string['pluginname'] = 'Request Services Tab';
$string['requestservices'] = 'Request Services';
$string['requestservices:view'] = 'View Request Services tab in course';
$string['allrequests'] = 'All Request ';
$string['computerservicesTab'] = ' computer services ';
$string['financialservices'] = ' financial services  ';
$string['registeringroom'] = '  room registration ';
$string['requestparticipant'] = '  request lecturer/role player ';
$string['residencebooking'] = '  request residence booking ';
$string['invalidtab'] = 'working on page   ';

// global
$string['course'] = 'Course';
$string['requestdate'] = 'Request date';
$string['status'] = 'Status';

// computerservices_requests.mustache
$string['numdevices'] = 'Number of devices';
$string['devices'] = 'Requested devices';

// financialservicesview.mustache
$string['fundingtype'] = 'Funding type';
$string['pricerequested'] = 'Requested amount';
