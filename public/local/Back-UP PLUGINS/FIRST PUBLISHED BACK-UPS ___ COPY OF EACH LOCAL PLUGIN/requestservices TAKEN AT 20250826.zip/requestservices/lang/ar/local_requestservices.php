<?php
$string['pluginname'] = 'تبويب طلب الخدمات';
$string['requestservices'] = 'طلب الخدمات';
$string['requestservices:view'] = 'عرض تبويب طلب الخدمات في المقرر';
$string['allrequests'] = ' جميع الطلبات ';
$string['computerservicesTab'] = '  طلب الأجهزة ';
$string['financialservices'] = '  طلب تمويل  ';
$string['registeringroom'] = ' حجز الفصل الدراسي';
$string['requestparticipant'] = ' طلب محاضر/ لاعب دور';
$string['residencebooking'] = ' طلب الإقامة والإعاشة والنقل ';
$string['invalidtab'] = ' جاري العمل على هذه الصفحة ';

// global
$string['course'] = 'المقرر';
$string['requestdate'] = 'تاريخ الطلب';
$string['status'] = 'حالة الطلب';

// computerservices_requests.mustache
$string['numdevices'] = 'عدد الأجهزة';
$string['devices'] = 'الأجهزة المطلوبة';

// financialservicesview.mustache
$string['fundingtype'] = 'نوع التمويل';
$string['pricerequested'] = 'المبلغ المطلوب';
