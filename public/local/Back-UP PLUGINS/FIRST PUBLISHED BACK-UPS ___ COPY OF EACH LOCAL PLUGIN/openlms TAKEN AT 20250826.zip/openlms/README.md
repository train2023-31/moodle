# Open LMS local util plugin

This plugin is required by the following plugins published by Open LMS:

* [Programs for Moodle](https://github.com/open-lms-open-source/moodle-enrol_programs)
