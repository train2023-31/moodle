<?php
require_once('../../config.php');
require_login();
// Hi ahmed
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/employee/index.php'));
$PAGE->set_title(get_string('pluginname', 'local_employee'));
$PAGE->set_heading(get_string('pluginname', 'local_employee'));

echo $OUTPUT->header();
echo html_writer::tag('h2', get_string('manageemployees', 'local_employee'));

// Fetch employee data from database
$employees = $DB->get_records('employee');

echo '<table border="1">';
echo '<tr><th>ID</th><th>Name</th><th>Position</th><th>Email</th><th>Created_at</th></tr>';
foreach ($employees as $employee) {
    echo '<tr>';
    echo '<td>' . $employee->id . '</td>';
    echo '<td>' . $employee->name . '</td>';
    echo '<td>' . $employee->position . '</td>';
    echo '<td>' . $employee->email . '</td>';
    echo '<td>' . $employee->created_at . '</td>';
    echo '</tr>';
}
echo '</table>';


echo $OUTPUT->footer();