<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_employee', get_string('pluginname', 'local_employee'));
    $ADMIN->add('localplugins', $settings);
}