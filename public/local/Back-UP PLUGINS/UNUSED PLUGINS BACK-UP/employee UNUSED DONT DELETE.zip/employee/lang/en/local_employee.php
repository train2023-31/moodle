<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Employee';
$string['employeelist'] = 'Employee List';
$string['manageemployees'] = 'Manage Employees';