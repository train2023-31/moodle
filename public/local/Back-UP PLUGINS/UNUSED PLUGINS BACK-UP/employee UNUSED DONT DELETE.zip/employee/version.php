<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_employee';
$plugin->version   = 2025022600;
$plugin->requires  = 2020110900; // Moodle 3.10+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';
