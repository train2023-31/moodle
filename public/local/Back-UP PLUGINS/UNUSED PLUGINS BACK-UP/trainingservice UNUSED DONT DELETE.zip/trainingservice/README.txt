## local/trainingservice

### Description
The `local/trainingservice` plugin provides a comprehensive service for managing guest residences related to training programs within Moodle. It allows administrators to manage residence requests, track and approve accommodations, and generate reports on residence usage.

### Key Features
- Manage guest residence requests.
- Track and approve residence accommodations.
- Generate reports on residence usage.
- Seamlessly integrates with Moodle's user management.

### Installation
1. Copy the `trainingservice` folder to `moodle/local/`.
2. Navigate to Site Administration -> Notifications to complete the installation.
3. Configure the plugin settings under Site Administration -> Plugins -> Local plugins -> Training Service.

### Usage
#### Accessing the Plugin
- Navigate to the local plugins menu to access the Training Service.
- The main page allows you to create and manage residence requests.

#### Creating Residence Requests
1. Access the residence request form from the plugin's main page.
2. Fill in the required details including residence type, start and end dates, purpose, and any additional notes.
3. Submit the form to create a new residence request.

#### Managing Residence Requests
- View all residence requests in a table format.
- Approve or delete requests directly from the table.
- Track the status and details of each request.

#### Generating Reports
- Access the reporting section to generate detailed reports on residence usage.
- Analyze trends and occupancy rates over specific periods.

### File Structure
- index.php Main entry point for the plugin, handles form submissions and displays the residence requests table.
- classes/form/training_residences_form.php: Defines the form for submitting new residence requests.
- classes/data_manager.php: Handles data operations such as fetching residence types, purposes, and managing requests.
- classes/requests_table.php*:*: Defines and displays the table for managing residence requests.
- db/install.xml: Defines the database schema for storing residence-related data.
- version.php: Contains version and dependency information for the plugin.

### Database
#### Tables
- local_trainingservice_residences_request: Stores residence requests.
  - Fields:
    - `id`: Primary key.
    - `residence_type`: References the residence type.
    - `start_date`: Start date of the residence.
    - `end_date`: End date of the residence.
    - `purpose`: References the purpose of the residence.
    - `notes`: Additional notes.
    - `userid`: ID of the user making the request.
- local_trainingservice_residence_types: Stores different types of residences.
  - Fields:
    - `id`: Primary key.
    - `type_name`: Name of the residence type.
- local_trainingservice_purpose: Stores purposes of residence requests.
  - Fields:
    - `id`: Primary key.
    - `description`: Description of the purpose.

### Support
For support, refer to the Moodle documentation or contact the plugin maintainer.

### License
This plugin is licensed under the [GNU GPL v3](https://www.gnu.org/licenses/gpl-3.0.html).

### Version Information
- Version: 1.0.0
- Maturity: Stable
- Release Date: 2024-05-01
- Requires: Moodle 2022111800 or later

### Changelog
#### 1.0.0
- Initial release with features for managing and tracking guest residences related to training programs.
