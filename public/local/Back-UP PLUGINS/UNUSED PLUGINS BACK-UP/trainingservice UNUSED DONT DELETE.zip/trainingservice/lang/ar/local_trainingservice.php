<?php
// General plugin name and description
$string['pluginname'] = 'خدمة التدريب';
$string['settings'] = 'الإعدادات';
$string['enable'] = 'تمكين';
$string['enable_desc'] = 'تمكين أو تعطيل وظائف خدمة التدريب.';
$string['role'] = 'الدور الافتراضي';
$string['role_desc'] = 'اختر الدور الافتراضي للمستخدمين الذين يقدمون الطلبات.';

// Form labels and buttons
$string['guestdetails'] = 'تفاصيل الضيف';
$string['residence_type'] = 'نوع الإقامة';
$string['start_date'] = 'تاريخ البدء';
$string['end_date'] = 'تاريخ الانتهاء';
$string['purpose'] = 'الغرض';
$string['notes'] = 'ملاحظات';
$string['submit'] = 'إرسال';
$string['view'] = 'عرض الطلبات القديمة';

// Navigation and table headings
$string['viewrequests'] = 'عرض الطلبات';
$string['back'] = 'العودة';
$string['applyrequests'] = 'تقديم طلبات الإقامة';
$string['id'] = 'المعرف';
$string['residencetype'] = 'نوع الإقامة';
$string['startdate'] = 'تاريخ البدء';
$string['enddate'] = 'تاريخ الانتهاء';
$string['purpose'] = 'الغرض';
$string['notes'] = 'ملاحظات';
$string['user'] = 'المستخدم';
$string['delete'] = 'حذف';
$string['actions'] = 'الإجراءات';

// Notification messages
$string['requestdeleted'] = 'تم حذف الطلب بنجاح';
$string['confirmdelete'] = 'هل أنت متأكد أنك تريد حذف هذا الطلب؟';
$string['errordeletingrequest'] = 'خطأ في حذف الطلب';
$string['successmessage'] = 'تم تقديم طلبك بنجاح';

// Manage table headings
$string['status'] = 'الحالة';
$string['approve'] = 'الموافقة';
$string['reject'] = 'رفض';
$string['delete'] = 'حذف';
$string['requestapproved'] = 'تمت الموافقة على طلب الإقامة.';
$string['requestrejected'] = 'تم رفض طلب الإقامة.';
$string['requestdeleted'] = 'تم حذف طلب الإقامة.';
$string['confirmdelete'] = 'هل أنت متأكد أنك تريد حذف هذا الطلب؟';
$string['managerequests'] = 'إدارة طلبات الإقامة';
