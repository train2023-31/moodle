<?php
// General plugin name and description
$string['pluginname'] = 'Training Service';
$string['settings'] = 'Settings';
$string['enable'] = 'Enable';
$string['enable_desc'] = 'Enable or disable the Training Service functionality.';
$string['role'] = 'Default role';
$string['role_desc'] = 'Select the default role for users making requests.';

// Form labels and buttons
$string['guestdetails'] = 'Guest Details';
$string['residence_type'] = 'Residence Type';
$string['start_date'] = 'Start Date';
$string['end_date'] = 'End Date';
$string['purpose'] = 'Purpose';
$string['notes'] = 'Notes';
$string['submit'] = 'Submit';
$string['view'] = 'View Old Requests';

// Navigation and table headings
$string['viewrequests'] = 'View Requests';
$string['back'] = 'Back';
$string['applyrequests'] = 'Apply Residence Requests';
$string['id'] = 'ID';
$string['residencetype'] = 'Residence Type';
$string['startdate'] = 'Start Date';
$string['enddate'] = 'End Date';
$string['purpose'] = 'Purpose';
$string['notes'] = 'Notes';
$string['user'] = 'User';
$string['delete'] = 'Delete';
$string['actions'] = 'Actions';

// Notification messages
$string['requestdeleted'] = 'Request successfully deleted';
$string['confirmdelete'] = 'Are you sure you want to delete this request?';
$string['errordeletingrequest'] = 'Error deleting request';
$string['successmessage'] = 'Your request has been successfully submitted';

// Manage table headings
$string['status'] = 'Status';
$string['approve'] = 'Approve';
$string['reject'] = 'Reject';
$string['delete'] = 'Delete';
$string['requestapproved'] = 'The residence request has been approved.';
$string['requestrejected'] = 'The residence request has been rejected.';
$string['requestdeleted'] = 'The residence request has been deleted.';
$string['confirmdelete'] = 'Are you sure you want to delete this request?';
$string['managerequests'] = 'Manage Residence Requests';