<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // Create a new category under Site Administration for Training Service
    $category = new admin_category('local_trainingservice', get_string('pluginname', 'local_trainingservice'));
    $ADMIN->add('root', $category);

    // Create a settings page to host various settings
    $settingspage = new admin_settingpage('local_trainingservice_settings', get_string('settings', 'local_trainingservice'));
    
    // Check if we are on the full tree to avoid performance issues
    if ($ADMIN->fulltree) {
        // Add a setting for enabling/disabling the Training Service
        $settingspage->add(new admin_setting_configcheckbox(
            'local_trainingservice/enable',
            get_string('enable', 'local_trainingservice'),
            get_string('enable_desc', 'local_trainingservice'),
            1 // Default to enabled
        ));

        // Add a dropdown setting for selecting the default role for users
        $roles = get_all_roles();
        $roleoptions = array();
        foreach ($roles as $role) {
            $roleoptions[$role->id] = $role->shortname;
        }

        $settingspage->add(new admin_setting_configselect(
            'local_trainingservice/role',
            get_string('role', 'local_trainingservice'),
            get_string('role_desc', 'local_trainingservice'),
            null, // Default to no selection
            $roleoptions
        ));
    }

    // Add the settings page to the category
    $ADMIN->add('local_trainingservice', $settingspage);

    // Add additional management links for ease of access
    $ADMIN->add('local_trainingservice', new admin_externalpage(
        'local_trainingservice_manage',
        get_string('applyrequests', 'local_trainingservice'),
        new moodle_url('/local/trainingservice/index.php'),
        'moodle/site:config' // Require admin permissions to access this page
    ));

    // Add a new settings page under "Training Service plugin".
    $ADMIN->add('local_trainingservice', new admin_externalpage(
        'local_trainingservice_manage_requests',
        get_string('managerequests', 'local_trainingservice'),
        new moodle_url('/local/trainingservice/manage_requests.php'),
        'moodle/site:config' // Ensure only users with this capability can see the link.
    ));
}
