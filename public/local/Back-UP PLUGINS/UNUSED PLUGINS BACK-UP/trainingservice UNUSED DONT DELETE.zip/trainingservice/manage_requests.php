<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/tablelib.php');

// Include plugin-specific classes.
require_once('classes/data_manager.php');
require_once('classes/manage_requests_table.php');  // Load the new manage_requests_table class

// Ensure the user is logged in and has the necessary capabilities.
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context); // Only authorized users can access

// Set up the page properties (URL, context, title, heading).
$PAGE->set_url(new moodle_url('/local/trainingservice/manage_requests.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('managerequests', 'local_trainingservice'));
$PAGE->set_heading(get_string('managerequests', 'local_trainingservice'));

// Output the page header and heading.
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('managerequests', 'local_trainingservice'));

// Initialize and display the table for all residence requests.
$table = new \local_trainingservice\classes\manage_requests_table('uniqueid_managerequests');
$table->query_db(20, true); // Display all requests (no filtering).
$table->out(20, true);

if ($action = optional_param('action', '', PARAM_ALPHA)) {
    $requestid = required_param('id', PARAM_INT); // Ensure the request ID is passed.

    if ($action === 'approve') {
        \local_trainingservice\data_manager::approve_residence_request($requestid); // Approve the request.
        echo $OUTPUT->notification(get_string('requestapproved', 'local_trainingservice'), 'notifysuccess');
    } elseif ($action === 'reject') {
        \local_trainingservice\data_manager::reject_residence_request($requestid); // Reject the request.
        echo $OUTPUT->notification(get_string('requestrejected', 'local_trainingservice'), 'notifyproblem');
    } elseif ($action === 'delete') {
        \local_trainingservice\data_manager::delete_residence_request($requestid); // Delete the request.
        echo $OUTPUT->notification(get_string('requestdeleted', 'local_trainingservice'), 'notifysuccess');
    }

    // Redirect to refresh the page and clear actions.
    redirect($PAGE->url);
}

// Output the page footer.
echo $OUTPUT->footer();
