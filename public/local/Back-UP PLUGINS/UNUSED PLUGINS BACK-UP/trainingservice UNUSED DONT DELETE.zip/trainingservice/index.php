<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir.'/adminlib.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/tablelib.php');

require_once('classes/form/training_residences_form.php');
require_once('classes/data_manager.php');
require_once('classes/pending_requests_table.php');  // Load the new pending_requests_table

require_login();

$context = context_system::instance();
require_capability('local/trainingservice:manage', $context);

$PAGE->set_url(new moodle_url('/local/trainingservice/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pluginname', 'local_trainingservice'));
$PAGE->set_heading(get_string('pluginname', 'local_trainingservice'));

global $DB, $OUTPUT, $PAGE;

echo $OUTPUT->header();

// Initialize the residence request form
$form = new \local_trainingservice\form\training_residences_form();

if ($form->is_cancelled()) {
    redirect(new moodle_url('/'));
} elseif ($data = $form->get_data()) {
    try {
        \local_trainingservice\data_manager::add_residence((array)$data);
        echo $OUTPUT->notification(get_string('successmessage', 'local_trainingservice'), 'notifysuccess');
    } catch (\moodle_exception $e) {
        echo $OUTPUT->notification($e->getMessage(), 'notifyproblem');
    }
    redirect($PAGE->url);  // Refresh the page to show updated data
} else {
    $form->display();
}

echo $OUTPUT->heading(get_string('applyrequests', 'local_trainingservice'));

// Initialize and display the table for pending residence requests
$table = new \local_trainingservice\classes\pending_requests_table('uniqueid_pendingrequests');
$table->query_db(20, true);  // Only pending requests
$table->out(20, true);

if ($action = optional_param('action', '', PARAM_ALPHA)) {
    $requestid = required_param('id', PARAM_INT);

    if ($action === 'approve') {
        \local_trainingservice\data_manager::approve_residence_request($requestid);
        echo $OUTPUT->notification(get_string('requestapproved', 'local_trainingservice'), 'notifysuccess');
    } elseif ($action === 'reject') {
        \local_trainingservice\data_manager::reject_residence_request($requestid);
        echo $OUTPUT->notification(get_string('requestrejected', 'local_trainingservice'), 'notifyproblem');
    } elseif ($action === 'delete') {
        \local_trainingservice\data_manager::delete_residence_request($requestid);
        echo $OUTPUT->notification(get_string('requestdeleted', 'local_trainingservice'), 'notifysuccess');
    }

    // Redirect to refresh the page and clear action parameters
    redirect($PAGE->url);
}

echo $OUTPUT->footer();
