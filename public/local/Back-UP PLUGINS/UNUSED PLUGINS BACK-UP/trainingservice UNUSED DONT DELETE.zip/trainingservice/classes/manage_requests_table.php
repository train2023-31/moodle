<?php
namespace local_trainingservice\classes;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/tablelib.php');

class manage_requests_table extends \table_sql {
    public function __construct($uniqueid) {
        parent::__construct($uniqueid);

        // Define the base URL for the table (manage_requests.php).
        $this->define_baseurl(new \moodle_url('/local/trainingservice/manage_requests.php'));

        // Define the columns and headers to display in the table.
        $this->define_columns(['id', 'residence_type', 'start_date', 'end_date', 'purpose', 'notes', 'userid', 'status', 'actions']);
        $this->define_headers([
            get_string('id', 'local_trainingservice'),
            get_string('residence_type', 'local_trainingservice'),
            get_string('start_date', 'local_trainingservice'),
            get_string('end_date', 'local_trainingservice'),
            get_string('purpose', 'local_trainingservice'),
            get_string('notes', 'local_trainingservice'),
            get_string('user', 'local_trainingservice'),
            get_string('status', 'local_trainingservice'),
            get_string('actions', 'local_trainingservice')
        ]);

        // Table settings (no collapsing, general table style).
        $this->collapsible(false);
        $this->set_attribute('class', 'generaltable generalbox');

        // Set up the table's internal configuration.
        $this->setup();
    }

    // Custom rendering for the residence type column.
    public function col_residence_type($values) {
        // Return the human-readable name of the residence type.
        return $values->residence_type_name;
    }

    // Custom rendering for the purpose column.
    public function col_purpose($values) {
        // Return the human-readable description of the purpose.
        return $values->purpose_description;
    }

    // Custom rendering for the user column (displays the user's full name).
    public function col_userid($values) {
        // Return the full name of the user.
        return $values->firstname . ' ' . $values->lastname;
    }

    // Custom rendering for the start date column
    public function col_start_date($values) {
        return userdate($values->start_date);  // Convert Unix timestamp to readable date
    }

    // Custom rendering for the end date column
    public function col_end_date($values) {
        return userdate($values->end_date);  // Convert Unix timestamp to readable date
    }

    // Method to query the database and fetch records for the table.
    public function query_db($pagesize, $useinitialsbar = true) {
        global $DB;

        // Call the setup method to ensure the table is properly configured.
        $this->setup();

        // Get the total count of records in the 'local_trainingservice_residences_request' table.
        $totalcount = $DB->count_records('local_trainingservice_residences_request');

        // Get sorting preferences and pagination settings.
        $sort = $this->get_sql_sort();
        $offset = $this->get_page_start();

        // SQL query to fetch residence requests, join with residence types, purposes, and users.
        $sql = "SELECT r.*, u.firstname, u.lastname, rt.type_name as residence_type_name, p.description as purpose_description
                FROM {local_trainingservice_residences_request} r
                JOIN {user} u ON r.userid = u.id
                JOIN {local_trainingservice_residence_types} rt ON r.residence_type = rt.id
                JOIN {local_trainingservice_purpose} p ON r.purpose = p.id";

        // Append sorting if specified.
        if (!empty($sort)) {
            $sql .= " ORDER BY $sort";
        }

        // Fetch the records from the database based on pagination and sorting.
        $this->rawdata = $DB->get_records_sql($sql, null, $offset, $pagesize);

        // Set the pagination size and total number of records.
        $this->pagesize($pagesize, $totalcount);

        // Optionally display initials bar (disabled by default here).
        if ($useinitialsbar) {
            $this->initialbars(false);
        }
    }

    // Custom rendering for the actions column (approve, reject, delete).
    public function col_actions($values) {
        // Create the approve link for each row.
        $approve_link = new \moodle_url($this->baseurl, ['action' => 'approve', 'id' => $values->id]);
        $approve_button = \html_writer::link($approve_link, 
            '<i class="fa fa-check"></i> ' . get_string('approve', 'local_trainingservice'), 
            [
                'class' => 'btn btn-success btn-sm',
                'title' => get_string('approve_request', 'local_trainingservice'),
                'aria-label' => get_string('approve_request', 'local_trainingservice'),
            ]
        );

        // Create the reject link for each row.
        $reject_link = new \moodle_url($this->baseurl, ['action' => 'reject', 'id' => $values->id]);
        $reject_button = \html_writer::link($reject_link, 
            '<i class="fa fa-times"></i> ' . get_string('reject', 'local_trainingservice'), 
            [
                'class' => 'btn btn-danger btn-sm',
                'title' => get_string('reject_request', 'local_trainingservice'),
                'aria-label' => get_string('reject_request', 'local_trainingservice'),
            ]
        );

        // Create the delete link for each row with a confirmation prompt.
        $delete_link = new \moodle_url($this->baseurl, ['action' => 'delete', 'id' => $values->id]);
        $delete_button = \html_writer::link($delete_link, 
            '<i class="fa fa-trash"></i> ' . get_string('delete', 'local_trainingservice'), 
            [
                'class' => 'btn btn-warning btn-sm',
                'title' => get_string('delete_request', 'local_trainingservice'),
                'aria-label' => get_string('delete_request', 'local_trainingservice'),
                'onclick' => "return confirm('" . get_string('confirmdelete', 'local_trainingservice') . "');",
            ]
        );

        // Return the combined action buttons as HTML.
        return '<div class="action-buttons">' . $approve_button . $reject_button . $delete_button . '</div>';
    }
}
