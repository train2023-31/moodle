<?php
namespace local_trainingservice\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/formslib.php'); // Required for Moodle form handling.
require_once($CFG->dirroot . '/local/trainingservice/classes/data_manager.php'); // Including the data_manager class for fetching data from the database.

class training_residences_form extends \moodleform {
    
    /**
     * Define the form structure and validation rules.
     */
    protected function definition() {
        global $DB, $USER; // Global database and user variables.
        $mform = $this->_form; // Reference to the form object.

        // Adding a header for the form section (guest details).
        $mform->addElement('header', 'guestdetails', get_string('guestdetails', 'local_trainingservice'));

        // Fetch residence types from the database using data_manager.
        $residence_types = \local_trainingservice\data_manager::get_residence_types();
        $residence_type_options = []; // Initialize an array for the options.

        // Populate the residence types options array from the database.
        foreach ($residence_types as $type) {
            $residence_type_options[$type->id] = $type->type_name; // Use ID as value and type name as label.
        }

        // Add a dropdown menu (select element) for selecting residence type.
        $mform->addElement('select', 'residence_type', get_string('residence_type', 'local_trainingservice'), $residence_type_options);

        // Add a hidden field for the current user ID, so it gets submitted with the form.
        $mform->addElement('hidden', 'userid', $USER->id);
        $mform->setType('userid', PARAM_INT); // Ensure that the user ID is treated as an integer.

        // Add a date selector element for the start date of the residence.
        $mform->addElement('date_selector', 'start_date', get_string('start_date', 'local_trainingservice'));

        // Add a date selector element for the end date of the residence.
        $mform->addElement('date_selector', 'end_date', get_string('end_date', 'local_trainingservice'));

        // Fetch purposes from the database using data_manager.
        $purposes = \local_trainingservice\data_manager::get_purposes();
        $purpose_options = []; // Initialize an array for the purpose options.

        // Populate the purpose options array from the database.
        foreach ($purposes as $purpose) {
            $purpose_options[$purpose->id] = $purpose->description; // Use ID as value and description as label.
        }

        // Add a dropdown menu (select element) for selecting the purpose.
        $mform->addElement('select', 'purpose', get_string('purpose', 'local_trainingservice'), $purpose_options);

        // Add a textarea element for entering notes.
        $mform->addElement('textarea', 'notes', get_string('notes', 'local_trainingservice'));
        $mform->setType('notes', PARAM_TEXT); // Set the field type to PARAM_TEXT to ensure valid text input.

        // Add a validation rule to make the notes field mandatory (not empty).
        // The 'required' rule ensures the field is filled in before form submission.
        $mform->addRule('notes', get_string('required'), 'required', null, 'client');

        // Add a submit button to submit the form.
        $mform->addElement('submit', 'submit_TrainingResidencesForm', get_string('submit', 'local_trainingservice'));
    }
}
