<?php
namespace local_trainingservice;

defined('MOODLE_INTERNAL') || die();

class data_manager {
    // Fetch all residence types.
    public static function get_residence_types() {
        global $DB;
        return $DB->get_records('local_trainingservice_residence_types');
    }

    // Fetch all purposes.
    public static function get_purposes() {
        global $DB;
        return $DB->get_records('local_trainingservice_purpose');
    }

    // Insert a new residence request.
    public static function add_residence($data) {
        global $DB;
        return $DB->insert_record('local_trainingservice_residences_request', $data);
    }

    // Delete a residence request by ID.
    public static function delete_residence_request($requestid) {
        global $DB;
        return $DB->delete_records('local_trainingservice_residences_request', ['id' => $requestid]);
    }

    // Approve a residence request by updating its status.
    public static function approve_residence_request($requestid) {
        global $DB;
        return $DB->update_record('local_trainingservice_residences_request', [
            'id' => $requestid,
            'status' => 'approved'
        ]);
    }

    // Reject a residence request by updating its status.
    public static function reject_residence_request($requestid) {
        global $DB;
        return $DB->update_record('local_trainingservice_residences_request', [
            'id' => $requestid,
            'status' => 'rejected'
        ]);
    }

    // Fetch the residence type name by its ID.
    public static function get_residence_type_name($type_id) {
        global $DB;
        $type = $DB->get_record('local_trainingservice_residence_types', ['id' => $type_id]);
        return $type ? $type->type_name : '';
    }

    // Fetch the purpose description by its ID.
    public static function get_purpose_description($purpose_id) {
        global $DB;
        $purpose = $DB->get_record('local_trainingservice_purpose', ['id' => $purpose_id]);
        return $purpose ? $purpose->description : '';
    }
}
