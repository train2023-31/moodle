<?php
namespace local_trainingservice\classes;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/tablelib.php');

class requests_table extends \table_sql {
    public function __construct($uniqueid) {
        parent::__construct($uniqueid);
    
        // Define the base URL for the table (this will be index.php now).
        $this->define_baseurl(new \moodle_url('/local/trainingservice/index.php'));
    
        // Define the columns and headers as before.
        $this->define_columns(['id', 'residence_type', 'start_date', 'end_date', 'purpose', 'notes', 'userid', 'status', 'actions']);
        $this->define_headers([
            get_string('id', 'local_trainingservice'),
            get_string('residence_type', 'local_trainingservice'),
            get_string('start_date', 'local_trainingservice'),
            get_string('end_date', 'local_trainingservice'),
            get_string('purpose', 'local_trainingservice'),
            get_string('notes', 'local_trainingservice'),
            get_string('user', 'local_trainingservice'),
            get_string('status', 'local_trainingservice'),
            get_string('actions', 'local_trainingservice')
        ]);
    
        $this->setup(); // Set up the table.
    }
    

    // Custom rendering for the residence type column.
    public function col_residence_type($values) {
        return $values->residence_type_name;  // Get the residence type name from the joined data.
    }

    // Custom rendering for the start date column.
    public function col_start_date($values) {
        return userdate($values->start_date);  // Convert Unix timestamp to readable date.
    }

    // Custom rendering for the end date column.
    public function col_end_date($values) {
        return userdate($values->end_date);  // Convert Unix timestamp to readable date.
    }

    // Custom rendering for the purpose column.
    public function col_purpose($values) {
        return $values->purpose_description;  // Get the purpose description from the joined data.
    }

    // Custom rendering for the user column (displays the user's full name).
    public function col_userid($values) {
        return $values->firstname . ' ' . $values->lastname;  // Combine first and last name of the user.
    }

    // Custom rendering for the status column.
    public function col_status($values) {
        return ucfirst($values->status);  // Display status as capitalized string.
    }

    // Custom rendering for the actions column (approve, reject, delete).
    public function col_actions($values) {
        // Approve action link.
        $approve_link = new \moodle_url($this->baseurl, ['action' => 'approve', 'id' => $values->id]);
        $approve_button = \html_writer::link($approve_link, 
            '<i class="fa fa-check"></i> ' . get_string('approve', 'local_trainingservice'), 
            [
                'class' => 'btn btn-success btn-sm',
                'title' => get_string('approve_request', 'local_trainingservice'),
                'aria-label' => get_string('approve_request', 'local_trainingservice'),
            ]
        );
    
        // Reject action link.
        $reject_link = new \moodle_url($this->baseurl, ['action' => 'reject', 'id' => $values->id]);
        $reject_button = \html_writer::link($reject_link, 
            '<i class="fa fa-times"></i> ' . get_string('reject', 'local_trainingservice'), 
            [
                'class' => 'btn btn-danger btn-sm',
                'title' => get_string('reject_request', 'local_trainingservice'),
                'aria-label' => get_string('reject_request', 'local_trainingservice'),
            ]
        );
    
        // Delete action link.
        $delete_link = new \moodle_url($this->baseurl, ['action' => 'delete', 'id' => $values->id]);
        $delete_button = \html_writer::link($delete_link, 
            '<i class="fa fa-trash"></i> ' . get_string('delete', 'local_trainingservice'), 
            [
                'class' => 'btn btn-warning btn-sm',
                'title' => get_string('delete_request', 'local_trainingservice'),
                'aria-label' => get_string('delete_request', 'local_trainingservice'),
                'onclick' => "return confirm('" . get_string('confirmdelete', 'local_trainingservice') . "');",
            ]
        );
    
        // Return the combined action buttons.
        return $approve_button . ' ' . $reject_button . ' ' . $delete_button;
    }

    // Method to fetch the data and query the database for table content.
    public function query_db($pagesize, $useinitialsbar = true, $statusfilter = null) {
        global $DB;
    
        // Call the setup method to ensure the table is properly set up.
        $this->setup();
    
        // Get the total number of records, filtered by status if applicable.
        $params = [];
        $where = '';
    
        if ($statusfilter !== null) {
            $where = 'WHERE r.status = :status';
            $params['status'] = $statusfilter;
        }
    
        // Get the total number of records based on the filter.
        $sqlcount = "SELECT COUNT(1) 
                     FROM {local_trainingservice_residences_request} r
                     $where";
        $totalcount = $DB->count_records_sql($sqlcount, $params);
    
        // Get the sorting preferences and pagination settings.
        $sort = $this->get_sql_sort();
        $offset = $this->get_page_start();
    
        // SQL query to fetch the residence requests and join with the user table.
        $sql = "SELECT r.*, u.firstname, u.lastname, rt.type_name as residence_type_name, p.description as purpose_description
                FROM {local_trainingservice_residences_request} r
                JOIN {user} u ON r.userid = u.id
                JOIN {local_trainingservice_residence_types} rt ON r.residence_type = rt.id
                JOIN {local_trainingservice_purpose} p ON r.purpose = p.id
                $where";
    
        // Append the sorting clause to the SQL query if sorting is enabled.
        if (!empty($sort)) {
            $sql .= " ORDER BY $sort";
        }
    
        // Fetch the records and assign them to the table's raw data.
        $this->rawdata = $DB->get_records_sql($sql, $params, $offset, $pagesize);
    
        // Set the pagination for the table.
        $this->pagesize($pagesize, $totalcount);
    
        // Optionally display the initials bar (disabled in this case).
        if ($useinitialsbar) {
            $this->initialbars(false);
        }
    }
}
