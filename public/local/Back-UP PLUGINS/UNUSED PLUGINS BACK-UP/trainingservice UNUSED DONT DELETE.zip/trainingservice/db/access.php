<?php

$capabilities = [
    'local/trainingservice:submit' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'user' => CAP_ALLOW
        ]
      //  'clonepermissionsfrom' => 'moodle/site:config' //this is for taking the permissions from Moodle !!
    ],
    'local/trainingservice:manage' => [
        'riskbitmask' => RISK_DATALOSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'manager' => CAP_ALLOW,
            'admin' => CAP_ALLOW,// Allow managers to manage bookings.
            'editingteacher' => CAP_ALLOW,
        ]
    ],
];
