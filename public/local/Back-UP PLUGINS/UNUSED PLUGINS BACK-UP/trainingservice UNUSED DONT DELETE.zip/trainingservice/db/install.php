<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Post installation procedure
 *
 * @see upgrade_plugins_modules()
 */
function xmldb_local_trainingservice_install() {
    global $DB;

    // Insert default residence types in Arabic
    $residence_types = [
        (object)['type_name' => 'غرفة فندقية'],
        (object)['type_name' => 'سكن التدريب'],
        (object)['type_name' => 'شقة'],
        (object)['type_name' => 'سكن خاص'],
    ];

    foreach ($residence_types as $type) {
        $DB->insert_record('local_trainingservice_residence_types', $type);
    }

    // Insert default purposes in Arabic
    $purposes = [
        (object)['description' => 'تقديم محاضرة'],
        (object)['description' => 'حضور درس'],
        (object)['description' => 'تنظيم دورة'],
        (object)['description' => 'أخرى'],
    ];

    foreach ($purposes as $purpose) {
        $DB->insert_record('local_trainingservice_purpose', $purpose);
    }

    // Insert initial residence requests
    $initial_residences_requests = [
        (object)[
            'residence_type' => 1, // Assuming the first residence type is 'غرفة فندقية'
            'start_date' => strtotime('2024-05-01'),
            'end_date' => strtotime('2024-05-10'),
            'purpose' => 1, // Assuming the first purpose is 'تقديم محاضرة'
            'notes' => 'سليمان الناعبي 98885547',
            'userid' => 1 // Assuming the user with ID 2 exists
        ],
        (object)[
            'residence_type' => 2, // Assuming the second residence type is 'سكن التدريب'
            'start_date' => strtotime('2024-06-01'),
            'end_date' => strtotime('2024-06-15'),
            'purpose' => 2, // Assuming the second purpose is 'حضور درس'
            'notes' => 'أحمد السيابي 95554441',
            'userid' => 2 // Assuming the user with ID 3 exists
        ],
        (object)[
            'residence_type' => 3, // Assuming the third residence type is 'شقة'
            'start_date' => strtotime('2024-07-01'),
            'end_date' => strtotime('2024-07-20'),
            'purpose' => 3, // Assuming the third purpose is 'تنظيم دورة'
            'notes' => 'محمد البادي 95547788',
            'userid' => 1 // Assuming the user with ID 4 exists
        ],
    ];

    foreach ($initial_residences_requests as $request) {
        $DB->insert_record('local_trainingservice_residences_request', $request);
    }
}
