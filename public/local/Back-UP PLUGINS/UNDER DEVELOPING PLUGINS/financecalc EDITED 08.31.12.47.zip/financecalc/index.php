<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main index page for the financecalc plugin.
 *
 * @package    local_financecalc
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');

// Check for valid login and capability.
require_login();
$context = context_system::instance();
require_capability('local/financecalc:view', $context);

// Set up the page.
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/financecalc/index.php'));
$PAGE->set_title(get_string('pluginname', 'local_financecalc'));
$PAGE->set_heading(get_string('pluginname', 'local_financecalc'));
$PAGE->set_pagelayout('standard');

// Output starts here.
echo $OUTPUT->header();

// Main content area with cards
echo html_writer::start_div('card-deck', ['style' => 'display:flex;gap:20px;margin-top:30px;']);

// Clause Spending Report Card
$clause_report_url = new moodle_url('/local/financecalc/pages/clause_report.php');
echo html_writer::start_div('card', ['style' => 'flex:1;text-align:center;padding:20px;border:1px solid #ccc;border-radius:10px;']);
echo html_writer::tag('div', '📊', ['style' => 'font-size:40px;margin-bottom:10px;']);
echo html_writer::tag('h3', get_string('clause_spending_report', 'local_financecalc'));
echo html_writer::tag('p', 'View detailed spending analysis for all clauses');
echo html_writer::link($clause_report_url, get_string('clause_spending_report', 'local_financecalc'),
    ['class' => 'btn btn-info', 'style' => 'margin-top:10px;']);
echo html_writer::end_div();

// Financial Overview Card
$financial_report_url = new moodle_url('/local/financecalc/pages/report.php');
echo html_writer::start_div('card', ['style' => 'flex:1;text-align:center;padding:20px;border:1px solid #ccc;border-radius:10px;']);
echo html_writer::tag('div', '📈', ['style' => 'font-size:40px;margin-bottom:10px;']);
echo html_writer::tag('h3', get_string('financialoverview', 'local_financecalc'));
echo html_writer::tag('p', 'View overall financial data and spending analysis');
echo html_writer::link($financial_report_url, get_string('financialoverview', 'local_financecalc'),
    ['class' => 'btn btn-primary', 'style' => 'margin-top:10px;']);
echo html_writer::end_div();

echo html_writer::end_div();

// About section
echo html_writer::start_div('mt-4');
echo html_writer::tag('h3', get_string('about_finance_calculator', 'local_financecalc'));
echo html_writer::tag('p', get_string('about_finance_calculator_desc', 'local_financecalc'));
echo html_writer::end_div();

echo $OUTPUT->footer();
