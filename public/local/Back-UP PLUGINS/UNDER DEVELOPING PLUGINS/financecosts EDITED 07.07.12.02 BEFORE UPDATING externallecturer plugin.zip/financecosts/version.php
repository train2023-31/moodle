<?php
// This file is part of Moodle – http://moodle.org/
//
// local_financecosts – plugin version definition.
// See http://docs.moodle.org/dev/version.php for details.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_financecosts';
$plugin->version   = 2025070700;       // YmdHis – bump on every change.
$plugin->release   = '1.0.0';
$plugin->requires  = 2022041900;       // Moodle 3.11 (min).
$plugin->maturity  = MATURITY_ALPHA;   // Change when stable.
