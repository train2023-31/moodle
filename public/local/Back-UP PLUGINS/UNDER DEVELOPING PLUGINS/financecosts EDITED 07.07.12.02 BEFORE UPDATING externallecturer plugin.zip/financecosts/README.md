# Finance Costs Plugin

A centralized financial cost management system for Moodle that aggregates and reports on costs from various finance-related plugins.

## Features

### 📊 Dashboard
- Real-time cost summaries (Total, Approved, Pending, Rejected)
- Financial data aggregation from multiple sources
- Clean, responsive interface with Bootstrap cards

### 📋 Data Management
- Detailed cost records with filtering and pagination
- Course-based and status-based filtering
- Unified view of costs from all integrated plugins

### ⚙️ Management Interface
- Category CRUD operations for cost organization
- Sync log viewer with detailed operation history
- Manual data synchronization controls
- Comprehensive settings management

### 🔄 Automated Synchronization
- **Sync Financial Data**: Runs daily at 2:00 AM
- **Aggregate Reports**: Runs twice daily at 6:30 AM and 6:30 PM
- Automatic log cleanup and data validation

## Integrated Plugins

### 1. External Lecturer Plugin
- **Table**: `externallecturer_courses`
- **Cost Field**: `cost`
- **Status**: Treated as "pending" by default

### 2. Finance Services Plugin
- **Table**: `local_financeservices`
- **Amount Field**: `price_requested`
- **Status**: Integrated with workflow system (`local_status`)

### 3. Finance Services Clauses
- **Table**: `local_financeservices_clause`
- **Amount Field**: `amount`
- **Status**: Active/deleted flag support

## Database Schema

### Categories Table (`local_financecosts_cat`)
```sql
- id (int): Primary key
- name (varchar): Category name (unique)
- description (text): Category description
- isactive (tinyint): Active status
- timecreated (int): Creation timestamp
- timemodified (int): Last modification timestamp
```

### Sync Log Table (`local_financecosts_log`)
```sql
- id (int): Primary key
- runat (int): Execution timestamp
- status (varchar): Operation status (running/success/error/aggregated)
- details (text): JSON-encoded operation details
```

## API Documentation

### Manager Class (`\local_financecosts\manager`)

#### `get_summary_totals(): array`
Returns dashboard summary with total, approved, pending, and rejected amounts.

#### `get_detailed_rows(int $page, int $perpage, ?int $course, ?string $status): array`
Returns paginated, filtered cost records with metadata.

#### `get_course_options(): array`
Returns available courses for filtering dropdowns.

#### `get_status_options(): array`
Returns available status options for filtering.

### Sync Manager Class (`\local_financecosts\sync_manager`)

#### `sync_all_data(): array`
Performs complete data synchronization from all integrated plugins.

#### `aggregate_data(): array`
Aggregates financial data for reporting purposes.

#### `get_recent_logs(int $limit = 50): array`
Retrieves recent synchronization logs.

#### `clean_old_logs(int $days_to_keep = 90): void`
Cleans up old log entries.

## Installation

1. Place the plugin in `/local/financecosts/`
2. Visit Site Administration → Notifications to install
3. Configure capabilities for finance staff
4. Set up automatic synchronization in Site Administration → Server → Scheduled Tasks

## Configuration

### Admin Settings
- **Sync Frequency**: How often data should be synchronized (hours)
- **Log Retention**: Number of days to keep sync logs

### Capabilities
- **local/financecosts:view**: View dashboard and cost data
- **local/financecosts:manage**: Manage categories and system settings

## Usage

### Accessing the Plugin
Navigate to: **Site Administration → Plugins → Local plugins → Finance Costs**

### Dashboard
View real-time financial summaries and key metrics.

### Data View
Browse detailed cost records with advanced filtering:
- Filter by course
- Filter by status
- Paginated results with search

### Management
- Create and manage cost categories
- Monitor synchronization logs
- Perform manual sync operations
- View sync statistics and summaries

## Cron Tasks

### Sync Financial Data
- **Frequency**: Daily at 2:00 AM
- **Purpose**: Synchronize data from external plugins
- **Class**: `\local_financecosts\task\sync_financial_data`

### Aggregate Reports
- **Frequency**: Twice daily (6:30 AM, 6:30 PM)
- **Purpose**: Generate aggregated reports and statistics
- **Class**: `\local_financecosts\task\aggregate_reports`

## Troubleshooting

### Common Issues

1. **No data appearing**: Check if integrated plugins are installed and have data
2. **Sync failures**: Check logs in Management → Sync Logs
3. **Permission errors**: Verify user has appropriate capabilities

### Log Analysis
All synchronization operations are logged with detailed JSON information:
- Success/failure status
- Record counts processed
- Error messages and stack traces
- Performance metrics

## Development

### Adding New Data Sources
1. Update `manager::get_summary_totals()` to include new aggregation queries
2. Modify `manager::get_detailed_rows()` to include new data in UNION query
3. Add sync methods in `sync_manager` class
4. Update language strings as needed

### Custom Categories
Categories can be used to organize costs by:
- Department
- Project
- Cost center
- Time period
- Custom business logic

## Support

For technical support or feature requests, please contact your system administrator or development team.

## Version History

- **v1.0**: Initial implementation with basic dashboard
- **v2.0**: Added real aggregation queries and sync functionality
- **v2.1**: Complete management interface with category CRUD
- **v2.2**: Enhanced logging and automated synchronization 