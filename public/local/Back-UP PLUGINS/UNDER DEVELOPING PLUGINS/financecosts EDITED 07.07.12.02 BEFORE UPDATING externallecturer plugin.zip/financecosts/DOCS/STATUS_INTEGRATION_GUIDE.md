# Status Integration Guide

## Overview

The Finance Costs plugin integrates with the **local_status** plugin to track the approval status of each cost request. This guide explains how status integration works and how to implement it in your own plugins.

## Status System Architecture

### Direct Status Relationship

Each financial record can have a `status_id` field that directly references `local_status.id`:

```sql
-- Your plugin table with status integration
CREATE TABLE your_plugin_table (
    id int(10) PRIMARY KEY,
    course_id int(10),
    amount decimal(10,2),
    status_id int(10) NOT NULL,  -- Direct link to local_status
    created_time int(10),
    
    FOREIGN KEY (status_id) REFERENCES mdl_local_status(id)
);
```

### How Status Integration Works

1. **Request Creation**: When a financial record is created, it gets assigned a `status_id`
2. **Status Changes**: The `status_id` can be updated as the request moves through workflow
3. **Reporting**: Finance Costs reads the current status directly from the status table
4. **Real-time**: Status is always current, no separate workflow tracking needed

## Status Table Structure

The `local_status` table typically contains:

```sql
CREATE TABLE mdl_local_status (
    id int(10) PRIMARY KEY,
    name varchar(50) NOT NULL,           -- Internal status name
    display_name_en varchar(100),        -- User-friendly English name
    display_name_ar varchar(100),        -- User-friendly Arabic name  
    color varchar(7),                    -- Hex color for UI
    seq int(10),                         -- Sort order
    isactive tinyint(1) DEFAULT 1,       -- Active flag
    created_at timestamp,
    updated_at timestamp
);
```

### Sample Status Data

```sql
INSERT INTO mdl_local_status (name, display_name_en, display_name_ar, color, seq) VALUES
('pending_review', 'Pending Review', 'قيد المراجعة', '#ffc107', 1),
('approved_finance', 'Approved by Finance', 'موافق من المالية', '#28a745', 2),
('rejected_incomplete', 'Rejected - Incomplete', 'مرفوض - ناقص', '#dc3545', 3),
('approved_final', 'Final Approval', 'الموافقة النهائية', '#17a2b8', 4);
```

## Status Name Conventions

The Finance Costs plugin categorizes statuses based on name patterns:

### Approved Statuses
Status names containing these keywords are considered "approved":
- `approved`
- `approve` 
- `accept`
- `completed`
- `paid`
- `final`

**Examples:**
- `approved_finance`
- `approved_final`
- `accept_payment`
- `completed_processing`

### Pending Statuses
Status names containing these keywords are considered "pending":
- `pending`
- `waiting`
- `review`
- `submitted`
- `draft`
- `processing`

**Examples:**
- `pending_review`
- `waiting_approval`
- `submitted_finance`
- `draft_request`

### Rejected Statuses
Status names containing these keywords are considered "rejected":
- `reject`
- `denied`
- `decline`
- `cancelled`
- `refunded`

**Examples:**
- `rejected_incomplete`
- `denied_budget`
- `cancelled_request`
- `refunded_payment`

## Integration Methods

### Method 1: Direct Status Field (Recommended)

**Advantages:**
- Simple foreign key relationship
- Real-time status updates
- Single JOIN for queries
- Data integrity through constraints

```sql
-- Add status field to existing table
ALTER TABLE your_plugin_table 
ADD COLUMN status_id int(10) NOT NULL DEFAULT 1,
ADD FOREIGN KEY (status_id) REFERENCES mdl_local_status(id);
```

**Query Example:**
```sql
SELECT 
    yp.amount,
    COALESCE(s.display_name_en, s.name, 'unknown') as status,
    s.color as status_color
FROM your_plugin_table yp
LEFT JOIN mdl_local_status s ON s.id = yp.status_id
WHERE yp.deleted = 0;
```

### Method 2: Migration Script for Existing Data

If your plugin already has status data in a different format:

```php
// In your plugin's db/upgrade.php
function xmldb_yourplugin_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    if ($oldversion < 2025010100) {
        // Step 1: Add status_id field
        $table = new xmldb_table('your_plugin_table');
        $field = new xmldb_field('status_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '1');
        
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        
        // Step 2: Migrate existing status data
        $status_mapping = [
            'draft' => 'pending_review',
            'submitted' => 'pending_review', 
            'approved' => 'approved_finance',
            'rejected' => 'rejected_incomplete'
        ];
        
        foreach ($status_mapping as $old_status => $new_status) {
            $new_status_id = $DB->get_field('local_status', 'id', ['name' => $new_status]);
            if ($new_status_id) {
                $DB->set_field('your_plugin_table', 'status_id', $new_status_id, ['old_status_field' => $old_status]);
            }
        }
        
        // Step 3: Drop old status field (optional)
        // $old_field = new xmldb_field('old_status_field');
        // if ($dbman->field_exists($table, $old_field)) {
        //     $dbman->drop_field($table, $old_field);
        // }
        
        upgrade_plugin_savepoint(true, 2025010100, 'yourplugin', 'local');
    }
    
    return true;
}
```

## Finance Costs Integration Queries

### Summary Totals by Status

```sql
-- Approved amounts
SELECT COALESCE(SUM(yp.amount), 0) as approved_total
FROM your_plugin_table yp
INNER JOIN mdl_local_status s ON s.id = yp.status_id
WHERE s.name LIKE '%approved%' AND yp.deleted = 0;

-- Pending amounts  
SELECT COALESCE(SUM(yp.amount), 0) as pending_total
FROM your_plugin_table yp
INNER JOIN mdl_local_status s ON s.id = yp.status_id
WHERE s.name LIKE '%pending%' AND yp.deleted = 0;

-- Rejected amounts
SELECT COALESCE(SUM(yp.amount), 0) as rejected_total
FROM your_plugin_table yp
INNER JOIN mdl_local_status s ON s.id = yp.status_id
WHERE s.name LIKE '%reject%' AND yp.deleted = 0;
```

### Detailed Data with Status

```sql
-- For Finance Costs detailed view
SELECT 
    yp.course_id as courseid,
    yp.amount,
    COALESCE(s.display_name_en, s.name, 'unknown') as status,
    yp.created_time as timecreated,
    'yourplugin' as source,
    s.color as status_color
FROM your_plugin_table yp
LEFT JOIN mdl_local_status s ON s.id = yp.status_id
WHERE yp.deleted = 0
ORDER BY yp.created_time DESC;
```

### Status Options for Filtering

```sql
-- Get only statuses actually used by your plugin
SELECT DISTINCT s.name, s.display_name_en, s.seq
FROM mdl_local_status s
INNER JOIN your_plugin_table yp ON yp.status_id = s.id
WHERE s.isactive = 1
ORDER BY s.seq, s.display_name_en;
```

## Implementation in Finance Costs Plugin

### Manager Class Integration

```php
// In classes/manager.php - get_summary_totals()
public static function get_summary_totals(): array {
    global $DB;
    
    // Your plugin approved amounts
    $approved = 0;
    if ($DB->get_manager()->table_exists('your_plugin_table')) {
        $approved += (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(yp.amount), 0)
            FROM {your_plugin_table} yp
            INNER JOIN {local_status} s ON s.id = yp.status_id
            WHERE s.name LIKE '%approved%' AND yp.deleted = 0
        ");
    }
    
    // Similar for pending and rejected...
    
    return ['total' => $total, 'approved' => $approved, 'pending' => $pending, 'rejected' => $rejected];
}
```

### Detailed View Integration

```php
// In classes/manager.php - get_detailed_rows()
// Add to UNION query:
UNION ALL

SELECT 
    yp.course_id as courseid,
    yp.amount,
    COALESCE(s.display_name_en, s.name, 'pending') as status,
    yp.created_time as timecreated,
    'yourplugin' as source
FROM {your_plugin_table} yp
LEFT JOIN {local_status} s ON s.id = yp.status_id
WHERE yp.deleted = 0
```

## Custom Status Logic

### Complex Status Mapping

For plugins with complex status requirements:

```php
// Custom status categorization function
public static function categorize_status($status_name) {
    $approved_patterns = ['approved', 'accept', 'completed', 'paid', 'final'];
    $pending_patterns = ['pending', 'waiting', 'review', 'submitted', 'draft'];
    $rejected_patterns = ['reject', 'denied', 'decline', 'cancelled', 'refunded'];
    
    $status_lower = strtolower($status_name);
    
    foreach ($approved_patterns as $pattern) {
        if (strpos($status_lower, $pattern) !== false) {
            return 'approved';
        }
    }
    
    foreach ($rejected_patterns as $pattern) {
        if (strpos($status_lower, $pattern) !== false) {
            return 'rejected';
        }
    }
    
    foreach ($pending_patterns as $pattern) {
        if (strpos($status_lower, $pattern) !== false) {
            return 'pending';
        }
    }
    
    return 'pending'; // Default for unknown statuses
}
```

### SQL CASE Statement for Complex Logic

```sql
-- Complex status categorization in SQL
SELECT 
    yp.amount,
    CASE 
        WHEN s.name IN ('draft', 'submitted', 'waiting_review') THEN 'pending'
        WHEN s.name IN ('approved_finance', 'approved_final', 'completed') THEN 'approved'
        WHEN s.name IN ('rejected_budget', 'cancelled', 'denied') THEN 'rejected'
        WHEN s.name LIKE '%pending%' OR s.name LIKE '%waiting%' THEN 'pending'
        WHEN s.name LIKE '%approved%' OR s.name LIKE '%accept%' THEN 'approved'
        WHEN s.name LIKE '%reject%' OR s.name LIKE '%denied%' THEN 'rejected'
        ELSE 'pending'
    END as status_category,
    COALESCE(s.display_name_en, s.name, 'unknown') as status_display
FROM your_plugin_table yp
LEFT JOIN mdl_local_status s ON s.id = yp.status_id
WHERE yp.deleted = 0;
```

## Status Workflow Examples

### Basic Three-State Workflow

```sql
-- Status progression: Draft → Review → Approved/Rejected
INSERT INTO mdl_local_status (name, display_name_en, seq) VALUES
('draft_request', 'Draft Request', 1),
('pending_review', 'Pending Review', 2),
('approved_final', 'Approved', 3),
('rejected_incomplete', 'Rejected', 4);
```

### Complex Multi-Level Workflow

```sql
-- Multi-department approval workflow
INSERT INTO mdl_local_status (name, display_name_en, seq) VALUES
('submitted_initial', 'Submitted', 1),
('pending_department', 'Pending Department Approval', 2),
('pending_finance', 'Pending Finance Approval', 3),
('pending_director', 'Pending Director Approval', 4),
('approved_final', 'Final Approval', 5),
('rejected_department', 'Rejected by Department', 6),
('rejected_finance', 'Rejected by Finance', 7),
('rejected_budget', 'Rejected - Budget Exceeded', 8);
```

## Best Practices

### 1. Status Naming Conventions
- Use descriptive, consistent naming patterns
- Include the approval level or reason in the name
- Use underscores for readability
- Avoid special characters

### 2. Display Names
- Always provide user-friendly display names
- Support multiple languages if needed
- Keep display names concise but clear

### 3. Database Design
- Use foreign key constraints for data integrity
- Add indexes on status_id for performance
- Consider soft deletes instead of hard deletes

### 4. Error Handling
- Always handle cases where status_id might be null
- Use COALESCE for fallback display values
- Check for status table existence before queries

### 5. Performance Optimization
```sql
-- Add indexes for better performance
ALTER TABLE your_plugin_table ADD INDEX idx_status_id (status_id);
ALTER TABLE your_plugin_table ADD INDEX idx_composite (status_id, deleted, created_time);
```

## Testing Status Integration

### 1. Database Testing

```sql
-- Test status queries
SELECT s.name, COUNT(*) as record_count, SUM(yp.amount) as total_amount
FROM your_plugin_table yp
INNER JOIN mdl_local_status s ON s.id = yp.status_id
WHERE yp.deleted = 0
GROUP BY s.id, s.name
ORDER BY s.seq;
```

### 2. Finance Costs Integration Testing

1. Create test records with different statuses
2. Verify dashboard totals update correctly
3. Test status filtering in management interface
4. Check sync log entries

### 3. Status Transition Testing

```php
// Test status changes
$record = $DB->get_record('your_plugin_table', ['id' => 1]);
$new_status_id = $DB->get_field('local_status', 'id', ['name' => 'approved_final']);
$record->status_id = $new_status_id;
$DB->update_record('your_plugin_table', $record);

// Verify Finance Costs reflects the change immediately
```

## Troubleshooting

### Common Issues

1. **Status not appearing in filters**
   - Check that status is actually used by records
   - Verify status is marked as active
   - Ensure proper JOIN in status options query

2. **Incorrect status categorization**
   - Review status name patterns
   - Check for typos in status names
   - Verify LIKE patterns in categorization queries

3. **Performance issues**
   - Add indexes on status_id
   - Optimize JOIN queries
   - Consider status name patterns for efficiency

4. **Missing status display names**
   - Always use COALESCE for fallback values
   - Check for null display_name_en values
   - Provide default status handling

This guide provides everything needed to implement robust status integration that works seamlessly with the Finance Costs plugin.