# Database Schema Guide

## Overview

This guide provides detailed requirements and best practices for database schema design when integrating with the Finance Costs plugin.

## Required Fields

Every financial data source must have these essential fields:

### 1. Primary Key
```sql
id int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY
```
- **Purpose**: Unique identifier for each record
- **Required**: Yes
- **Type**: Auto-incrementing integer

### 2. Course Reference
```sql
course_id int(10) NOT NULL
```
- **Purpose**: Links to Moodle course for filtering and organization
- **Required**: Yes
- **Type**: Integer (references `mdl_course.id`)
- **Index**: Recommended for performance

### 3. Amount Field
```sql
amount decimal(10,2) NOT NULL
```
- **Purpose**: The financial value to be aggregated
- **Required**: Yes
- **Type**: Decimal with 2 decimal places for currency precision
- **Constraints**: Should be positive, non-null

### 4. Timestamp
```sql
created_time int(10) NOT NULL
```
- **Purpose**: When the financial record was created
- **Required**: Yes
- **Type**: Unix timestamp (integer)
- **Usage**: For sorting and date-based filtering

## Optional but Recommended Fields

### 5. Status Integration
```sql
status_id int(10) NOT NULL DEFAULT 1
```
- **Purpose**: Links to status workflow system
- **Type**: Integer (references `mdl_local_status.id`)
- **Default**: Set to a valid status ID (typically 'pending')
- **Benefits**: Enables approved/pending/rejected categorization

### 6. Soft Delete Flag
```sql
deleted tinyint(1) NOT NULL DEFAULT 0
```
- **Purpose**: Allows marking records as inactive without deletion
- **Type**: Boolean (0 = active, 1 = deleted)
- **Benefits**: Maintains data integrity and audit trail

### 7. Updated Timestamp
```sql
updated_time int(10) DEFAULT NULL
```
- **Purpose**: Tracks when record was last modified
- **Type**: Unix timestamp (integer)
- **Usage**: Audit trail and change tracking

## Complete Schema Template

```sql
CREATE TABLE mdl_your_plugin_table (
    -- Required fields
    id int(10) NOT NULL AUTO_INCREMENT,
    course_id int(10) NOT NULL,
    amount decimal(10,2) NOT NULL,
    created_time int(10) NOT NULL,
    
    -- Recommended fields
    status_id int(10) NOT NULL DEFAULT 1,
    deleted tinyint(1) NOT NULL DEFAULT 0,
    updated_time int(10) DEFAULT NULL,
    
    -- Your plugin-specific fields
    user_id int(10) DEFAULT NULL,
    description text DEFAULT NULL,
    category varchar(50) DEFAULT NULL,
    reference_number varchar(50) DEFAULT NULL,
    
    -- Primary key
    PRIMARY KEY (id),
    
    -- Foreign keys
    FOREIGN KEY (course_id) REFERENCES mdl_course(id),
    FOREIGN KEY (status_id) REFERENCES mdl_local_status(id),
    FOREIGN KEY (user_id) REFERENCES mdl_user(id),
    
    -- Indexes for performance
    KEY idx_course_id (course_id),
    KEY idx_status_id (status_id),
    KEY idx_created_time (created_time),
    KEY idx_deleted (deleted),
    KEY idx_composite (course_id, status_id, deleted, created_time)
);
```

## Field Naming Conventions

### Standard Field Names

Use these standard names when possible for consistency:

| Purpose | Recommended Name | Alternative Names |
|---------|------------------|-------------------|
| Primary Key | `id` | - |
| Course Reference | `course_id` | `courseid` |
| Amount | `amount` | `price`, `cost`, `fee_amount` |
| Creation Time | `created_time` | `timecreated`, `date_created` |
| Status Reference | `status_id` | `statusid` |
| Soft Delete | `deleted` | `is_deleted`, `active` |
| Update Time | `updated_time` | `timemodified`, `date_updated` |
| User Reference | `user_id` | `userid`, `student_id` |

### Custom Field Guidelines

- Use lowercase with underscores (`fee_type`, not `FeeType`)
- Be descriptive but concise (`payment_method`, not `pm`)
- Avoid reserved words (`type` → `record_type`)
- Use consistent prefixes for related fields (`payment_amount`, `payment_date`, `payment_method`)

## Data Types and Constraints

### Financial Amounts
```sql
-- For currency values
amount decimal(10,2) NOT NULL CHECK (amount >= 0)

-- For large amounts (millions)
amount decimal(15,2) NOT NULL CHECK (amount >= 0)

-- For quantities/percentages
quantity decimal(8,3) NOT NULL CHECK (quantity >= 0)
```

### Timestamps
```sql
-- Unix timestamps (recommended for Moodle)
created_time int(10) NOT NULL

-- MySQL timestamps (alternative)
created_at timestamp DEFAULT CURRENT_TIMESTAMP
updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
```

### Text Fields
```sql
-- Short descriptions
description varchar(255) DEFAULT NULL

-- Long text content
notes text DEFAULT NULL

-- Status/category codes
status_code varchar(20) NOT NULL

-- Reference numbers
reference_number varchar(50) DEFAULT NULL
```

### Boolean Fields
```sql
-- Recommended: tinyint
deleted tinyint(1) NOT NULL DEFAULT 0
is_approved tinyint(1) NOT NULL DEFAULT 0

-- Alternative: boolean (MySQL 8.0+)
deleted boolean NOT NULL DEFAULT false
```

## Indexing Strategy

### Primary Indexes
```sql
-- Always on primary key
PRIMARY KEY (id)

-- Foreign key indexes
KEY idx_course_id (course_id)
KEY idx_status_id (status_id)
KEY idx_user_id (user_id)
```

### Query-Specific Indexes
```sql
-- For date-based queries
KEY idx_created_time (created_time)

-- For soft delete filtering
KEY idx_deleted (deleted)

-- For amount-based queries
KEY idx_amount (amount)
```

### Composite Indexes
```sql
-- For Finance Costs aggregation queries
KEY idx_financecosts (course_id, status_id, deleted, created_time)

-- For user-specific queries
KEY idx_user_course (user_id, course_id, deleted)

-- For status workflow queries
KEY idx_status_time (status_id, deleted, created_time)
```

## Migration Scripts

### Adding Status Integration to Existing Table

```sql
-- Step 1: Add status_id field
ALTER TABLE mdl_your_plugin_table 
ADD COLUMN status_id int(10) NOT NULL DEFAULT 1 AFTER amount;

-- Step 2: Add foreign key constraint
ALTER TABLE mdl_your_plugin_table 
ADD FOREIGN KEY (status_id) REFERENCES mdl_local_status(id);

-- Step 3: Add index for performance
ALTER TABLE mdl_your_plugin_table 
ADD KEY idx_status_id (status_id);

-- Step 4: Set appropriate default status for existing records
UPDATE mdl_your_plugin_table 
SET status_id = (SELECT id FROM mdl_local_status WHERE name = 'pending_review' LIMIT 1)
WHERE status_id = 1;
```

### Adding Soft Delete to Existing Table

```sql
-- Step 1: Add deleted field
ALTER TABLE mdl_your_plugin_table 
ADD COLUMN deleted tinyint(1) NOT NULL DEFAULT 0;

-- Step 2: Add index
ALTER TABLE mdl_your_plugin_table 
ADD KEY idx_deleted (deleted);

-- Step 3: Update composite indexes to include deleted
ALTER TABLE mdl_your_plugin_table 
ADD KEY idx_composite_new (course_id, status_id, deleted, created_time);

-- Step 4: Drop old composite index if exists
-- ALTER TABLE mdl_your_plugin_table DROP KEY idx_composite_old;
```

## Moodle XMLDB Schema

For Moodle plugins, define your schema in `db/install.xml`:

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<XMLDB PATH="your_plugin/db" VERSION="2025010100" 
       COMMENT="XMLDB for your plugin"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:noNamespaceSchemaLocation="../../../../lib/xmldb/xmldb.xsd">

  <TABLES>
    <TABLE NAME="your_plugin_table" COMMENT="Financial records for your plugin">
      <FIELDS>
        <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
        <FIELD NAME="course_id" TYPE="int" LENGTH="10" NOTNULL="true"/>
        <FIELD NAME="amount" TYPE="number" LENGTH="10" DECIMALS="2" NOTNULL="true"/>
        <FIELD NAME="status_id" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="1"/>
        <FIELD NAME="created_time" TYPE="int" LENGTH="10" NOTNULL="true"/>
        <FIELD NAME="deleted" TYPE="int" LENGTH="1" NOTNULL="true" DEFAULT="0"/>
        <FIELD NAME="description" TYPE="text" NOTNULL="false"/>
      </FIELDS>
      
      <KEYS>
        <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
        <KEY NAME="fk_course" TYPE="foreign" FIELDS="course_id" REFTABLE="course" REFFIELDS="id"/>
        <KEY NAME="fk_status" TYPE="foreign" FIELDS="status_id" REFTABLE="local_status" REFFIELDS="id"/>
      </KEYS>
      
      <INDEXES>
        <INDEX NAME="idx_course_id" FIELDS="course_id"/>
        <INDEX NAME="idx_status_id" FIELDS="status_id"/>
        <INDEX NAME="idx_created_time" FIELDS="created_time"/>
        <INDEX NAME="idx_deleted" FIELDS="deleted"/>
        <INDEX NAME="idx_composite" FIELDS="course_id, status_id, deleted"/>
      </INDEXES>
    </TABLE>
  </TABLES>
</XMLDB>
```

## Performance Considerations

### Query Optimization

```sql
-- Good: Uses indexes effectively
SELECT SUM(amount) FROM mdl_your_plugin_table 
WHERE course_id = 10 AND deleted = 0 AND status_id IN (2,3,4);

-- Bad: Full table scan
SELECT SUM(amount) FROM mdl_your_plugin_table 
WHERE YEAR(FROM_UNIXTIME(created_time)) = 2025;

-- Better: Use timestamp ranges
SELECT SUM(amount) FROM mdl_your_plugin_table 
WHERE created_time BETWEEN 1704067200 AND 1735689599  -- 2025 timestamp range
AND deleted = 0;
```

### Index Usage Guidelines

1. **Primary Key**: Always indexed automatically
2. **Foreign Keys**: Index all foreign key fields
3. **Filter Fields**: Index fields used in WHERE clauses
4. **Sort Fields**: Index fields used in ORDER BY
5. **Composite Indexes**: For multi-field queries

### Avoid Over-Indexing

```sql
-- Too many indexes can hurt INSERT/UPDATE performance
-- Good: Essential indexes only
KEY idx_course_status (course_id, status_id)
KEY idx_created_time (created_time)

-- Bad: Redundant indexes
KEY idx_course_id (course_id)        -- Redundant with composite
KEY idx_status_id (status_id)        -- Redundant with composite  
KEY idx_course_status (course_id, status_id)
```

## Data Validation

### Database Constraints

```sql
-- Amount validation
CHECK (amount >= 0)
CHECK (amount <= 999999.99)

-- Status validation
FOREIGN KEY (status_id) REFERENCES mdl_local_status(id)

-- Time validation  
CHECK (created_time > 0)
CHECK (updated_time IS NULL OR updated_time >= created_time)
```

### Application-Level Validation

```php
// In your plugin's form validation
public function validation($data, $files) {
    $errors = parent::validation($data, $files);
    
    // Amount validation
    if (!is_numeric($data['amount']) || $data['amount'] <= 0) {
        $errors['amount'] = get_string('error_invalid_amount', 'your_plugin');
    }
    
    // Course validation
    if (!$DB->record_exists('course', ['id' => $data['course_id']])) {
        $errors['course_id'] = get_string('error_invalid_course', 'your_plugin');
    }
    
    // Status validation
    if (!$DB->record_exists('local_status', ['id' => $data['status_id'], 'isactive' => 1])) {
        $errors['status_id'] = get_string('error_invalid_status', 'your_plugin');
    }
    
    return $errors;
}
```

## Common Schema Patterns

### Simple Fee Structure

```sql
-- Basic course fees
CREATE TABLE mdl_local_coursefeess (
    id int(10) PRIMARY KEY AUTO_INCREMENT,
    course_id int(10) NOT NULL,
    fee_amount decimal(10,2) NOT NULL,
    fee_type varchar(50) NOT NULL,  -- 'enrollment', 'lab', 'material'
    status_id int(10) NOT NULL DEFAULT 1,
    created_time int(10) NOT NULL,
    deleted tinyint(1) DEFAULT 0
);
```

### User-Specific Charges

```sql
-- Individual student charges
CREATE TABLE mdl_local_studentcharges (
    id int(10) PRIMARY KEY AUTO_INCREMENT,
    course_id int(10) NOT NULL,
    user_id int(10) NOT NULL,
    charge_amount decimal(10,2) NOT NULL,
    charge_type varchar(50) NOT NULL,
    status_id int(10) NOT NULL DEFAULT 1,
    due_date int(10) DEFAULT NULL,
    paid_date int(10) DEFAULT NULL,
    created_time int(10) NOT NULL,
    deleted tinyint(1) DEFAULT 0,
    
    UNIQUE KEY unq_user_course_type (user_id, course_id, charge_type, deleted)
);
```

### Service-Based Billing

```sql
-- External service costs
CREATE TABLE mdl_local_servicecharges (
    id int(10) PRIMARY KEY AUTO_INCREMENT,
    course_id int(10) NOT NULL,
    service_type varchar(50) NOT NULL,  -- 'lecturer', 'equipment', 'software'
    service_provider varchar(100) DEFAULT NULL,
    unit_cost decimal(10,2) NOT NULL,
    quantity decimal(8,2) NOT NULL DEFAULT 1.00,
    total_amount decimal(10,2) GENERATED ALWAYS AS (unit_cost * quantity) STORED,
    status_id int(10) NOT NULL DEFAULT 1,
    start_date int(10) DEFAULT NULL,
    end_date int(10) DEFAULT NULL,
    created_time int(10) NOT NULL,
    deleted tinyint(1) DEFAULT 0
);
```

## Testing Your Schema

### Data Integrity Tests

```sql
-- Test foreign key constraints
INSERT INTO mdl_your_plugin_table (course_id, amount, created_time) 
VALUES (99999, 100.00, UNIX_TIMESTAMP());  -- Should fail if course doesn't exist

-- Test check constraints
INSERT INTO mdl_your_plugin_table (course_id, amount, created_time) 
VALUES (1, -50.00, UNIX_TIMESTAMP());  -- Should fail if amount check exists
```

### Performance Tests

```sql
-- Test query performance with EXPLAIN
EXPLAIN SELECT SUM(amount) FROM mdl_your_plugin_table 
WHERE course_id = 10 AND deleted = 0;

-- Test index usage
SHOW INDEX FROM mdl_your_plugin_table;
```

### Finance Costs Integration Tests

```sql
-- Test aggregation queries
SELECT 
    COALESCE(SUM(amount), 0) as total,
    COUNT(*) as record_count
FROM mdl_your_plugin_table 
WHERE deleted = 0;

-- Test status-based aggregation
SELECT 
    s.name as status_name,
    COALESCE(SUM(yp.amount), 0) as status_total
FROM mdl_your_plugin_table yp
INNER JOIN mdl_local_status s ON s.id = yp.status_id
WHERE yp.deleted = 0
GROUP BY s.id, s.name;
```

Following these schema guidelines ensures optimal performance, data integrity, and seamless integration with the Finance Costs plugin. 