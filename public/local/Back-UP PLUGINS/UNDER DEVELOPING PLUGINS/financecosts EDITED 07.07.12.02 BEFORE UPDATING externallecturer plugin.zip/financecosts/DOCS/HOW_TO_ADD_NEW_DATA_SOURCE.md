# How to Add a New Data Source - Complete Guide

## Overview

The Finance Costs plugin (`local_financecosts`) is designed to aggregate financial data from multiple source plugins within a Moodle installation. This guide explains how to integrate a new plugin or database table as a data source.

## Current Architecture

The plugin uses a **modular approach** with these key components:

- **`manager.php`** - Core business logic and data aggregation
- **`sync_manager.php`** - Data synchronization operations  
- **Union queries** - Combines data from multiple sources
- **Direct status integration** - Uses `status_id` field linking to `local_status` table
- **Automated cron tasks** - Daily sync and bi-daily aggregation

## Prerequisites

Before adding a new data source, ensure your plugin has:

1. **Database table** with financial data
2. **Proper field structure** (see recommended schema below)
3. **Status integration** (optional but recommended)
4. **Course relationship** for filtering capabilities

## Step-by-Step Integration Guide

### Step 1: Database Structure Requirements

Your plugin table should have these essential fields:

```sql
-- Recommended structure for finance plugins
CREATE TABLE your_plugin_table (
    id int(10) PRIMARY KEY AUTO_INCREMENT,
    course_id int(10) NOT NULL,           -- Course reference
    amount_field decimal(10,2) NOT NULL,  -- The financial amount
    status_id int(10),                    -- Link to local_status table (optional)
    created_time int(10) NOT NULL,        -- Timestamp
    deleted tinyint(1) DEFAULT 0,         -- Soft delete flag (optional)
    -- Your other plugin-specific fields...
    
    FOREIGN KEY (course_id) REFERENCES mdl_course(id),
    FOREIGN KEY (status_id) REFERENCES mdl_local_status(id)
);
```

**Required Fields:**
- **Primary key** (`id`)
- **Course reference** (`course_id`) - for filtering by course
- **Amount field** (`amount_field`) - the financial value to aggregate
- **Timestamp** (`created_time`) - for sorting and filtering

**Optional but Recommended:**
- **Status field** (`status_id`) - links to the status workflow system
- **Soft delete** (`deleted`) - allows marking records as inactive without deletion

### Step 2: Update Manager Class (`classes/manager.php`)

The manager class needs updates in **4 key methods**:

#### A) Summary Totals (`get_summary_totals()`)

Add your plugin's totals to the dashboard calculations:

```php
// Around line 30, after existing plugin totals
// Get totals from Your Plugin
$yourplugin_total = 0;
if ($DB->get_manager()->table_exists('your_plugin_table')) {
    $yourplugin_total = (float)$DB->get_field_sql("
        SELECT COALESCE(SUM(yp.amount_field), 0)
        FROM {your_plugin_table} yp
        WHERE yp.deleted = 0  -- if using soft delete
    ");
}

// Add to grand total
$total = $externallecturer_total + $financeservices_total + $yourplugin_total;

// If your plugin has status integration, add to status-specific totals:
if ($DB->get_manager()->table_exists('your_plugin_table')) {
    // Approved amounts
    $approved += (float)$DB->get_field_sql("
        SELECT COALESCE(SUM(yp.amount_field), 0)
        FROM {your_plugin_table} yp
        INNER JOIN {local_status} s ON s.id = yp.status_id
        WHERE s.name LIKE '%approved%' AND yp.deleted = 0
    ");
    
    // Pending amounts
    $pending += (float)$DB->get_field_sql("
        SELECT COALESCE(SUM(yp.amount_field), 0)
        FROM {your_plugin_table} yp
        INNER JOIN {local_status} s ON s.id = yp.status_id
        WHERE s.name LIKE '%pending%' AND yp.deleted = 0
    ");
    
    // Rejected amounts
    $rejected += (float)$DB->get_field_sql("
        SELECT COALESCE(SUM(yp.amount_field), 0)
        FROM {your_plugin_table} yp
        INNER JOIN {local_status} s ON s.id = yp.status_id
        WHERE s.name LIKE '%reject%' AND yp.deleted = 0
    ");
}
```

#### B) Detailed Data Query (`get_detailed_rows()`)

Add your plugin to the main UNION query around line 90:

```php
-- Add this to the existing UNION query, before ") combined_data"
UNION ALL

-- Your Plugin data
SELECT 
    yp.course_id as courseid,
    yp.amount_field as amount,
    COALESCE(s.display_name_en, s.name, 'pending') as status,
    yp.created_time as timecreated,
    'yourplugin' as source
FROM {your_plugin_table} yp
LEFT JOIN {local_status} s ON s.id = yp.status_id
WHERE yp.deleted = 0  -- if using soft delete
```

For conditional inclusion (safe approach):
```php
            " . ($DB->get_manager()->table_exists('your_plugin_table') ? "
            UNION ALL
            
            SELECT 
                yp.course_id as courseid,
                yp.amount_field as amount,
                COALESCE(s.display_name_en, s.name, 'pending') as status,
                yp.created_time as timecreated,
                'yourplugin' as source
            FROM {your_plugin_table} yp
            LEFT JOIN {local_status} s ON s.id = yp.status_id
            WHERE yp.deleted = 0
            " : "") . "
```

#### C) Update Count Query

Also add your plugin to the count query in the same method:

```php
-- Add to the count query UNION
UNION ALL

SELECT 1
FROM {your_plugin_table} yp
LEFT JOIN {local_status} s ON s.id = yp.status_id
WHERE yp.deleted = 0
```

#### D) Course Options (`get_course_options()`)

Add your plugin's courses to the filtering options around line 160:

```php
SELECT DISTINCT c.id, c.fullname
FROM {course} c
WHERE c.id IN (
    SELECT DISTINCT course_id FROM {local_financeservices}
    UNION
    SELECT DISTINCT courseid FROM {externallecturer_courses}
    UNION
    SELECT DISTINCT course_id FROM {your_plugin_table} WHERE deleted = 0  -- Add this line
)
ORDER BY c.fullname
```

### Step 3: Update Sync Manager (`classes/sync_manager.php`)

#### A) Add to Main Sync Method (`sync_all_data()`)

Around line 30, add your plugin to the sync process:

```php
// Sync your plugin data
$stats['yourplugin_count'] = $this->sync_yourplugin_data();
```

#### B) Create Sync Method

Add a new private method at the end of the class:

```php
/**
 * Sync your plugin data.
 *
 * @return int Number of records processed
 */
private function sync_yourplugin_data(): int {
    global $DB;

    // Check if your plugin tables exist
    if (!$DB->get_manager()->table_exists('your_plugin_table')) {
        return 0;
    }

    $sql = "SELECT COUNT(*) FROM {your_plugin_table} 
            WHERE amount_field IS NOT NULL AND amount_field > 0
            AND deleted = 0";  // if using soft delete

    return $DB->count_records_sql($sql);
}
```

#### C) Update Aggregation (`aggregate_data()`)

Add your plugin to the record count around line 55:

```php
$stats['record_count'] = $DB->count_records_sql("
    SELECT COUNT(*) FROM (
        SELECT 1 FROM {local_financeservices}
        UNION ALL
        SELECT 1 FROM {externallecturer_courses}
        UNION ALL  
        SELECT 1 FROM {local_financeservices_clause} WHERE deleted = 0
        UNION ALL
        SELECT 1 FROM {your_plugin_table} WHERE deleted = 0  -- Add this line
    ) combined
");
```

### Step 4: Update Cron Task Output (`classes/task/sync_financial_data.php`)

Add logging for your plugin around line 35:

```php
mtrace('Synchronization completed successfully.');
mtrace("- External lecturer costs processed: {$result['externallecturer_count']}");
mtrace("- Finance services processed: {$result['financeservices_count']}");
mtrace("- Clauses processed: {$result['clause_count']}");
mtrace("- Your plugin processed: {$result['yourplugin_count']}");  // Add this line
```

### Step 5: Add Language Strings (`lang/en/local_financecosts.php`)

```php
$string['source_yourplugin'] = 'Your Plugin Name';
$string['task_sync_yourplugin'] = 'Sync Your Plugin Data';
```

### Step 6: Update Filter Handling (Optional)

If you need special filtering logic, update the WHERE clause handling in `get_detailed_rows()`:

```php
if ($course) {
    $where[] = '(fs.course_id = :courseid OR ec.courseid = :courseid2 OR yp.course_id = :courseid3)';
    $params['courseid'] = $course;
    $params['courseid2'] = $course;
    $params['courseid3'] = $course;  // Add this
}
```

## Status Integration Guide

### Option 1: Add Status Field to Existing Table

If your plugin doesn't have status tracking:

```sql
ALTER TABLE your_plugin_table 
ADD COLUMN status_id int(10) NOT NULL DEFAULT 1,
ADD FOREIGN KEY (status_id) REFERENCES mdl_local_status(id);
```

### Option 2: Create Migration Script

In your plugin's `db/upgrade.php`:

```php
function xmldb_yourplugin_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    if ($oldversion < 2025010100) {
        $table = new xmldb_table('your_plugin_table');
        $field = new xmldb_field('status_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '1');
        
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
            
            // Set default status for existing records
            $default_status = $DB->get_field('local_status', 'id', ['name' => 'pending'], IGNORE_MISSING);
            if ($default_status) {
                $DB->set_field('your_plugin_table', 'status_id', $default_status);
            }
        }
        
        upgrade_plugin_savepoint(true, 2025010100, 'yourplugin', 'yourtype');
    }
    
    return true;
}
```

### Status Name Conventions

The system recognizes these status name patterns:

- **Approved**: `approved`, `approve`, `accept`, `completed`
- **Pending**: `pending`, `waiting`, `review`, `submitted`
- **Rejected**: `reject`, `denied`, `decline`, `cancelled`

## Testing Your Integration

### 1. Manual Testing

1. Visit `/local/financecosts/` to see the dashboard
2. Check that your plugin's data appears in totals
3. Visit the Management page (`/local/financecosts/manage.php`)
4. Verify your data appears in the detailed table

### 2. Cron Testing

Test the synchronization:

```bash
# Run the sync task manually
php admin/cli/scheduled_task.php --execute=\\local_financecosts\\task\\sync_financial_data

# Run the aggregation task
php admin/cli/scheduled_task.php --execute=\\local_financecosts\\task\\aggregate_reports
```

### 3. Status Integration Testing

1. Change status values in your plugin
2. Refresh the financecosts dashboard
3. Verify totals update correctly in approved/pending/rejected categories

### 4. Filter Testing

1. Use course and status filters on the Management page
2. Verify your plugin's data filters correctly
3. Test pagination with large datasets

## Common Issues and Solutions

### Issue 1: Table Not Found Errors

**Solution**: Always check table existence:
```php
if (!$DB->get_manager()->table_exists('your_plugin_table')) {
    return 0; // or appropriate default
}
```

### Issue 2: Data Not Appearing

**Check these items:**
1. Table and field names match exactly
2. JOIN conditions are correct
3. WHERE clauses don't exclude your data
4. Amount fields contain valid numeric data

### Issue 3: Status Integration Not Working

**Verify:**
1. `status_id` field exists and is populated
2. Status names follow expected conventions
3. JOIN to `local_status` table is correct

### Issue 4: Performance Issues

**Optimizations:**
1. Add database indexes on key fields:
   ```sql
   ALTER TABLE your_plugin_table ADD INDEX idx_course_id (course_id);
   ALTER TABLE your_plugin_table ADD INDEX idx_status_id (status_id);
   ALTER TABLE your_plugin_table ADD INDEX idx_created_time (created_time);
   ```

2. Use appropriate WHERE clauses to limit data
3. Consider pagination for large datasets

## Best Practices

### 1. **Defensive Programming**
- Always check table existence before queries
- Use COALESCE for null handling
- Include error handling in sync methods

### 2. **Performance**
- Use appropriate database indexes
- Limit unnecessary JOINs
- Use efficient WHERE clauses

### 3. **Data Integrity**
- Use foreign key constraints where possible
- Implement soft delete instead of hard delete
- Maintain audit trails with timestamps

### 4. **User Experience**
- Provide meaningful source names in language strings
- Include helpful error messages
- Use consistent status naming conventions

### 5. **Maintainability**
- Follow existing code patterns
- Document any special requirements
- Use descriptive variable and method names

## Example Implementation

See `DOCS/EXAMPLE_ENROLLMENT_FEES.md` for a complete working example of integrating an enrollment fees plugin.

## Need Help?

If you encounter issues during integration:

1. Check the sync logs in the Management interface
2. Review database structure requirements
3. Test queries independently before integration
4. Verify status workflow setup if using status integration

The Finance Costs plugin is designed to be extensible - following this guide should allow seamless integration of any finance-related data source. 