# Finance Costs Plugin - Documentation

## Overview

This documentation provides comprehensive guides for extending and integrating with the Finance Costs plugin (`local_financecosts`). The plugin is designed to aggregate financial data from multiple sources within a Moodle installation.

## Documentation Contents

### 📋 [How to Add a New Data Source - Complete Guide](HOW_TO_ADD_NEW_DATA_SOURCE.md)
**Essential reading for developers**
- Step-by-step integration process
- Required code modifications
- Testing procedures
- Best practices and common issues

### 🔧 [Example: Enrollment Fees Plugin Integration](EXAMPLE_ENROLLMENT_FEES.md)
**Practical implementation example**
- Complete working example with code
- Database structure and sample data
- Testing scenarios and expected results
- Customization options

### ⚡ [Status Integration Guide](STATUS_INTEGRATION_GUIDE.md)
**Status workflow system integration**
- Status system architecture
- Direct status field implementation
- Status categorization patterns
- Migration scripts for existing data

### 🗄️ [Database Schema Guide](DATABASE_SCHEMA_GUIDE.md)
**Database design requirements and best practices**
- Required and recommended fields
- Schema templates and naming conventions
- Performance optimization and indexing
- Moodle XMLDB integration

## Quick Start Guide

### For New Plugin Integration

1. **Read the [Complete Guide](HOW_TO_ADD_NEW_DATA_SOURCE.md)** - Essential overview
2. **Review the [Database Guide](DATABASE_SCHEMA_GUIDE.md)** - Ensure proper schema
3. **Study the [Example](EXAMPLE_ENROLLMENT_FEES.md)** - See complete implementation
4. **Implement Status Integration** - Follow [Status Guide](STATUS_INTEGRATION_GUIDE.md)
5. **Test thoroughly** - Use testing procedures from the guides

### For Status System Integration Only

1. **Read [Status Integration Guide](STATUS_INTEGRATION_GUIDE.md)**
2. **Review schema requirements** in [Database Guide](DATABASE_SCHEMA_GUIDE.md)
3. **Follow migration scripts** for existing plugins

## Architecture Overview

The Finance Costs plugin uses a **modular architecture** that allows easy integration of new data sources:

```
┌─────────────────────────────────────────────────────────────┐
│                    Finance Costs Plugin                     │
├─────────────────────────────────────────────────────────────┤
│                     Manager Class                          │
│  ┌─────────────────┐ ┌─────────────────┐ ┌───────────────┐ │
│  │  Summary Totals │ │ Detailed Data   │ │ Course Filter │ │
│  │  Aggregation    │ │ UNION Queries   │ │ Options       │ │
│  └─────────────────┘ └─────────────────┘ └───────────────┘ │
├─────────────────────────────────────────────────────────────┤
│                   Sync Manager Class                       │
│  ┌─────────────────┐ ┌─────────────────┐ ┌───────────────┐ │
│  │ Data Sync       │ │ Aggregation     │ │ Log Management│ │
│  │ Operations      │ │ Tasks           │ │              │ │
│  └─────────────────┘ └─────────────────┘ └───────────────┘ │
├─────────────────────────────────────────────────────────────┤
│                    Data Sources                            │
│  ┌─────────────────┐ ┌─────────────────┐ ┌───────────────┐ │
│  │ External        │ │ Finance         │ │ Your Plugin   │ │
│  │ Lecturer        │ │ Services        │ │ (New Source)  │ │
│  └─────────────────┘ └─────────────────┘ └───────────────┘ │
├─────────────────────────────────────────────────────────────┤
│                  Status Integration                        │
│              ┌─────────────────────────────────┐            │
│              │         local_status            │            │
│              │    (Status Workflow System)     │            │
│              └─────────────────────────────────┘            │
└─────────────────────────────────────────────────────────────┘
```

## Integration Methods

### Method 1: Database Table Integration
- **Scope**: Integrate existing database tables
- **Requirements**: Table with course_id, amount, and optional status_id
- **Guides**: [Database Schema Guide](DATABASE_SCHEMA_GUIDE.md)

### Method 2: Plugin Integration  
- **Scope**: Full plugin integration with sync capabilities
- **Requirements**: Moodle plugin with financial data
- **Guides**: [Complete Guide](HOW_TO_ADD_NEW_DATA_SOURCE.md)

### Method 3: Status-Only Integration
- **Scope**: Add status workflow to existing financial data
- **Requirements**: Add status_id field to existing tables
- **Guides**: [Status Integration Guide](STATUS_INTEGRATION_GUIDE.md)

## Current Data Sources

The plugin currently aggregates data from:

| Data Source | Table | Amount Field | Status Integration |
|-------------|-------|--------------|-------------------|
| External Lecturer | `externallecturer_courses` | `cost` | Default: "pending" |
| Finance Services | `local_financeservices` | `price_requested` | ✅ Direct `status_id` |
| Finance Services Clauses | `local_financeservices_clause` | Various | ✅ Direct `status_id` |

## Key Features

### ✅ Real-time Aggregation
- No caching delays
- Direct database queries
- Immediate status updates

### ✅ Status Workflow Integration  
- Direct `status_id` linking
- Approved/Pending/Rejected categorization
- Real-time status changes

### ✅ Flexible Architecture
- Table existence checks
- Graceful degradation
- No hard dependencies

### ✅ Automated Synchronization
- Daily data sync (2:00 AM)
- Bi-daily aggregation (6:30 AM/PM)
- Comprehensive logging

### ✅ Management Interface
- Dashboard with summary totals
- Detailed data view with filtering
- Administrative management tools

## Requirements

### System Requirements
- Moodle 3.9+ (recommended 4.0+)
- PHP 7.4+ (recommended 8.0+)
- MySQL 5.7+ or PostgreSQL 10+

### Plugin Dependencies
- **local_status** (optional but recommended for status workflow)
- **Source plugins** (external lecturer, finance services, etc.)

## File Structure

```
local/financecosts/
├── DOCS/                           # Documentation (this folder)
│   ├── README.md                   # This file
│   ├── HOW_TO_ADD_NEW_DATA_SOURCE.md
│   ├── EXAMPLE_ENROLLMENT_FEES.md
│   ├── STATUS_INTEGRATION_GUIDE.md
│   └── DATABASE_SCHEMA_GUIDE.md
├── classes/
│   ├── manager.php                 # Core business logic
│   ├── sync_manager.php           # Data synchronization
│   ├── form/                      # Form classes
│   ├── output/                    # Renderer classes  
│   └── task/                      # Cron tasks
├── db/
│   ├── install.xml                # Database schema
│   ├── access.php                 # Capabilities
│   └── tasks.php                  # Scheduled tasks
├── lang/en/
│   └── local_financecosts.php     # Language strings
├── index.php                      # Dashboard page
├── manage.php                     # Management interface
├── settings.php                   # Admin settings
└── version.php                    # Plugin version
```

## Support and Development

### Getting Help

1. **Documentation**: Start with the relevant guide above
2. **Examples**: Study the enrollment fees example
3. **Testing**: Use provided test scenarios
4. **Code Review**: Follow existing patterns in the codebase

### Contributing

When extending the plugin:

1. **Follow the guides** in this documentation
2. **Maintain backward compatibility** 
3. **Add appropriate tests** for your integration
4. **Update documentation** if adding new patterns
5. **Use defensive programming** (table existence checks, etc.)

### Best Practices

1. **Safety First**: Always check table existence before queries
2. **Performance**: Use appropriate indexes and efficient queries  
3. **Consistency**: Follow existing naming conventions and patterns
4. **Documentation**: Comment complex logic and provide examples
5. **Testing**: Test thoroughly across different scenarios

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.2 | 2025 | Current documentation version |
| 2.1 | 2024 | Added status integration |
| 2.0 | 2024 | Refactored for modular architecture |
| 1.x | 2023 | Initial versions |

## License

This plugin follows Moodle's GPL v3 license. See the main plugin directory for license details.

---

**Next Steps**: Start with the [Complete Guide](HOW_TO_ADD_NEW_DATA_SOURCE.md) for step-by-step integration instructions. 