<?php
// Capability definitions for local_financecosts.

defined('MOODLE_INTERNAL') || die();

$capabilities = [

    // View dashboard and data (all finance staff).
    'local/financecosts:view' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
    ],

    // Manage categories, mappings, plugin settings.
    'local/financecosts:manage' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
        'riskbitmask'  => RISK_DATALOSS,
    ],
];
