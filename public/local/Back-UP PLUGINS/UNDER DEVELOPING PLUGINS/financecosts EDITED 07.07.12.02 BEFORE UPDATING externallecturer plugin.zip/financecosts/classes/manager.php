<?php
// Data-access / business-logic layer for local_financecosts.
//
// All heavy queries or calculations go here – never in renderers or UI files.

namespace local_financecosts;

defined('MOODLE_INTERNAL') || die();

use moodle_database;
use core_date;

class manager {

    /**
     * Return summary totals for the dashboard cards.
     *
     * @return array{total:float, approved:float, pending:float, rejected:float}
     */
    public static function get_summary_totals(): array {
        global $DB;

        // Get totals from External Lecturer costs
        $externallecturer_total = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(CAST(ec.cost AS DECIMAL(10,2))), 0)
            FROM {externallecturer_courses} ec
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
        ");

        // Get totals from Finance Services requests
        $financeservices_total = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(fs.price_requested), 0)
            FROM {local_financeservices} fs
        ");

        $total = $externallecturer_total + $financeservices_total;

        // Get approved amounts from Finance Services (direct status_id link)
        $approved = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(fs.price_requested), 0)
            FROM {local_financeservices} fs
            INNER JOIN {local_status} s ON s.id = fs.status_id
            WHERE s.name LIKE '%approved%'
        ");

        // Get pending amounts from Finance Services (direct status_id link)
        $pending = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(fs.price_requested), 0)
            FROM {local_financeservices} fs
            INNER JOIN {local_status} s ON s.id = fs.status_id
            WHERE s.name LIKE '%pending%'
        ");

        // Get rejected amounts from Finance Services (direct status_id link)
        $rejected = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(fs.price_requested), 0)
            FROM {local_financeservices} fs
            INNER JOIN {local_status} s ON s.id = fs.status_id
            WHERE s.name LIKE '%reject%'
        ");

        // Add external lecturer costs to pending (assuming no status workflow for them yet)
        $pending += $externallecturer_total;

        return [
            'total'    => $total,
            'approved' => $approved,
            'pending'  => $pending,
            'rejected' => $rejected,
        ];
    }

    /**
     * Return paginated, filtered rows for the Data-view table.
     *
     * @param int      $page   zero-based page number for LIMIT/OFFSET
     * @param int      $perpage records per page
     * @param ?int     $course optional course id filter
     * @param ?string  $status optional status filter
     * @return array [rows, totalcount]
     */
    public static function get_detailed_rows(int $page, int $perpage,
                                             ?int $course, ?string $status): array {
        global $DB;

        $params = [];
        $where  = [];

        if ($course) {
            $where[] = '(fs.course_id = :courseid OR ec.courseid = :courseid2)';
            $params['courseid'] = $course;
            $params['courseid2'] = $course;
        }
        if ($status) {
            if ($status === 'pending') {
                $where[] = "(s.name LIKE '%pending%' OR ec.courseid IS NOT NULL)";
            } else {
                $where[] = '(s.name LIKE :status OR s.display_name_en LIKE :status2)';
                $params['status'] = '%' . $status . '%';
                $params['status2'] = '%' . $status . '%';
            }
        }

        $wheresql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        // Union query to get data from all finance sources
        $sql = "
        SELECT 
            ROW_NUMBER() OVER (ORDER BY timecreated DESC) as id,
            courseid,
            amount,
            status,
            timecreated,
            source
        FROM (
            -- Finance Services data (direct status_id link)
            SELECT 
                fs.course_id as courseid,
                fs.price_requested as amount,
                COALESCE(s.display_name_en, s.name, 'unknown') as status,
                fs.date_time_requested as timecreated,
                'financeservices' as source
            FROM {local_financeservices} fs
            LEFT JOIN {local_status} s ON s.id = fs.status_id
            
            UNION ALL
            
            -- External Lecturer data
            SELECT 
                ec.courseid,
                CAST(ec.cost AS DECIMAL(10,2)) as amount,
                'pending' as status,
                COALESCE((SELECT created_at FROM {employee} LIMIT 1), " . time() . ") as timecreated,
                'externallecturer' as source
            FROM {externallecturer_courses} ec
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
        ) combined_data
        $wheresql
        ORDER BY timecreated DESC
        ";

        // Count query
        $countsql = "
        SELECT COUNT(*) FROM (
            SELECT 1
            FROM {local_financeservices} fs
            LEFT JOIN {local_status} s ON s.id = fs.status_id
            
            UNION ALL
            
            SELECT 1
            FROM {externallecturer_courses} ec
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
        ) combined_data
        $wheresql
        ";

        $total = $DB->count_records_sql($countsql, $params);
        $rows = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);

        return [$rows, $total];
    }

    /**
     * Get all courses that have finance-related data for filtering.
     *
     * @return array Course options for select dropdowns
     */
    public static function get_course_options(): array {
        global $DB;

        $sql = "
        SELECT DISTINCT c.id, c.fullname
        FROM {course} c
        WHERE c.id IN (
            SELECT DISTINCT course_id FROM {local_financeservices}
            UNION
            SELECT DISTINCT courseid FROM {externallecturer_courses}
        )
        ORDER BY c.fullname
        ";

        $courses = $DB->get_records_sql($sql);
        $options = [0 => get_string('all')];
        
        foreach ($courses as $course) {
            $options[$course->id] = $course->fullname;
        }

        return $options;
    }

    /**
     * Get available status options for filtering.
     *
     * @return array Status options for select dropdowns
     */
    public static function get_status_options(): array {
        global $DB;

        // Get all statuses that are actually used in finance requests
        $statuses = $DB->get_records_sql("
            SELECT DISTINCT s.name, s.display_name_en, s.seq
            FROM {local_status} s
            INNER JOIN {local_financeservices} fs ON fs.status_id = s.id
            ORDER BY s.seq, s.display_name_en
        ");

        $options = ['' => get_string('all')];
        $options['pending'] = get_string('pending', 'local_financecosts');
        
        foreach ($statuses as $status) {
            $display_name = !empty($status->display_name_en) ? $status->display_name_en : ucfirst($status->name);
            $options[$status->name] = $display_name;
        }

        return $options;
    }
}
