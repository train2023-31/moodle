<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

/**
 * Form for filtering financial cost data.
 */
class filter_form extends \moodleform {

    /**
     * Define the form.
     */
    public function definition() {
        $mform = $this->_form;

        // Course filter
        $mform->addElement('select', 'course', get_string('course', 'local_financecosts'), 
                          \local_financecosts\manager::get_course_options());

        // Status filter
        $mform->addElement('select', 'status', get_string('status', 'local_financecosts'), 
                          \local_financecosts\manager::get_status_options());

        // Submit button
        $this->add_action_buttons(false, get_string('filter', 'local_financecosts'));
    }
}
