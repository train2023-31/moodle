<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

/**
 * Form for creating and editing finance cost categories.
 */
class category_form extends \moodleform {

    /**
     * Define the form.
     */
    public function definition() {
        $mform = $this->_form;
        $category = $this->_customdata['category'] ?? null;

        // Name field.
        $mform->addElement('text', 'name', get_string('category_name', 'local_financecosts'), ['size' => 50]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', get_string('required'), 'required', null, 'client');
        $mform->addHelpButton('name', 'category_name', 'local_financecosts');

        // Description field.
        $mform->addElement('textarea', 'description', get_string('category_description', 'local_financecosts'), 
                          ['rows' => 4, 'cols' => 50]);
        $mform->setType('description', PARAM_TEXT);
        $mform->addHelpButton('description', 'category_description', 'local_financecosts');

        // Active status.
        $mform->addElement('advcheckbox', 'isactive', get_string('category_active', 'local_financecosts'));
        $mform->setDefault('isactive', 1);
        $mform->addHelpButton('isactive', 'category_active', 'local_financecosts');

        // Set defaults if editing.
        if ($category) {
            $mform->setDefault('name', $category->name);
            $mform->setDefault('description', $category->description);
            $mform->setDefault('isactive', $category->isactive);
        }

        // Action buttons.
        $this->add_action_buttons(true, $category ? get_string('update_category', 'local_financecosts') : get_string('add_category', 'local_financecosts'));
    }

    /**
     * Validate the form data.
     *
     * @param array $data Form data
     * @param array $files Form files
     * @return array Validation errors
     */
    public function validation($data, $files) {
        global $DB;
        
        $errors = parent::validation($data, $files);
        
        // Check for duplicate name.
        $category = $this->_customdata['category'] ?? null;
        $conditions = ['name' => $data['name']];
        if ($category) {
            $conditions['id'] = ['!=', $category->id];
        }
        
        if ($DB->record_exists('local_financecosts_cat', $conditions)) {
            $errors['name'] = get_string('category_name_exists', 'local_financecosts');
        }
        
        return $errors;
    }
} 