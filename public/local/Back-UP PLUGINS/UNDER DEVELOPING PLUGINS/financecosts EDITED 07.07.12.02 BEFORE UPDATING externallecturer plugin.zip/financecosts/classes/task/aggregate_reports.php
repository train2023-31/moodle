<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\task;

use local_financecosts\sync_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to aggregate financial data for reporting.
 */
class aggregate_reports extends \core\task\scheduled_task {

    /**
     * Get a descriptive name for this task (shown to admins).
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_aggregate_reports', 'local_financecosts');
    }

    /**
     * Run the task.
     */
    public function execute() {
        $sync_manager = new sync_manager();
        
        mtrace('Starting financial data aggregation...');
        
        try {
            $result = $sync_manager->aggregate_data();
            
            mtrace('Aggregation completed successfully.');
            mtrace("- Total amount aggregated: {$result['total_amount']}");
            mtrace("- Records processed: {$result['record_count']}");
            
        } catch (\Exception $e) {
            mtrace('Error during aggregation: ' . $e->getMessage());
            throw $e;
        }
    }
} 