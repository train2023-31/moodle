<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\task;

use local_financecosts\sync_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to sync financial data from various plugins.
 */
class sync_financial_data extends \core\task\scheduled_task {

    /**
     * Get a descriptive name for this task (shown to admins).
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_sync_financial_data', 'local_financecosts');
    }

    /**
     * Run the task.
     */
    public function execute() {
        $sync_manager = new sync_manager();
        
        mtrace('Starting financial data synchronization...');
        
        try {
            $result = $sync_manager->sync_all_data();
            
            mtrace('Synchronization completed successfully.');
            mtrace("- External lecturer costs processed: {$result['externallecturer_count']}");
            mtrace("- Finance services processed: {$result['financeservices_count']}");
            mtrace("- Clauses processed: {$result['clause_count']}");
            
        } catch (\Exception $e) {
            mtrace('Error during synchronization: ' . $e->getMessage());
            throw $e;
        }
    }
} 