<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts;

defined('MOODLE_INTERNAL') || die();

/**
 * Sync manager for financial data aggregation and synchronization.
 */
class sync_manager {

    /**
     * Sync all financial data from various plugins.
     *
     * @return array Statistics about the sync operation
     */
    public function sync_all_data(): array {
        global $DB;

        $stats = [
            'externallecturer_count' => 0,
            'financeservices_count' => 0,
            'clause_count' => 0,
            'sync_time' => time(),
        ];

        try {
            // Log the start of sync operation
            $log_id = $this->log_sync_start();

            // Sync external lecturer data
            $stats['externallecturer_count'] = $this->sync_externallecturer_data();

            // Sync finance services data
            $stats['financeservices_count'] = $this->sync_financeservices_data();

            // Sync clause data
            $stats['clause_count'] = $this->sync_clause_data();

            // Log successful completion
            $this->log_sync_completion($log_id, 'success', $stats);

        } catch (\Exception $e) {
            // Log the error
            if (isset($log_id)) {
                $this->log_sync_completion($log_id, 'error', ['error' => $e->getMessage()]);
            }
            throw $e;
        }

        return $stats;
    }

    /**
     * Aggregate financial data for reporting purposes.
     *
     * @return array Statistics about the aggregation
     */
    public function aggregate_data(): array {
        global $DB;

        $stats = manager::get_summary_totals();
        
        // Count total records processed
        $stats['record_count'] = $DB->count_records_sql("
            SELECT COUNT(*) FROM (
                SELECT 1 FROM {local_financeservices}
                UNION ALL
                SELECT 1 FROM {externallecturer_courses}
                UNION ALL  
                SELECT 1 FROM {local_financeservices_clause} WHERE deleted = 0
            ) combined
        ");

        // Store aggregated data in log for historical tracking
        $this->log_aggregation($stats);

        return $stats;
    }

    /**
     * Sync external lecturer cost data.
     *
     * @return int Number of records processed
     */
    private function sync_externallecturer_data(): int {
        global $DB;

        // Check if external lecturer tables exist
        if (!$DB->get_manager()->table_exists('externallecturer_courses')) {
            return 0;
        }

        $sql = "SELECT COUNT(*) FROM {externallecturer_courses} ec
                INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
                WHERE ec.cost IS NOT NULL AND ec.cost != ''";

        return $DB->count_records_sql($sql);
    }

    /**
     * Sync finance services data.
     *
     * @return int Number of records processed
     */
    private function sync_financeservices_data(): int {
        global $DB;

        // Check if finance services tables exist
        if (!$DB->get_manager()->table_exists('local_financeservices')) {
            return 0;
        }

        return $DB->count_records_sql("SELECT COUNT(*) FROM {local_financeservices} WHERE price_requested > 0");
    }

    /**
     * Sync clause data.
     *
     * @return int Number of records processed
     */
    private function sync_clause_data(): int {
        global $DB;

        // Check if clause tables exist
        if (!$DB->get_manager()->table_exists('local_financeservices_clause')) {
            return 0;
        }

        return $DB->count_records('local_financeservices_clause', ['deleted' => 0]);
    }

    /**
     * Log the start of a sync operation.
     *
     * @return int Log record ID
     */
    private function log_sync_start(): int {
        global $DB;

        $record = new \stdClass();
        $record->runat = time();
        $record->status = 'running';
        $record->details = 'Financial data synchronization started';

        return $DB->insert_record('local_financecosts_log', $record);
    }

    /**
     * Log the completion of a sync operation.
     *
     * @param int $log_id Log record ID
     * @param string $status Final status (success/error)
     * @param array $details Additional details
     */
    private function log_sync_completion(int $log_id, string $status, array $details): void {
        global $DB;

        $record = new \stdClass();
        $record->id = $log_id;
        $record->status = $status;
        $record->details = json_encode($details);

        $DB->update_record('local_financecosts_log', $record);
    }

    /**
     * Log aggregation results.
     *
     * @param array $stats Aggregation statistics
     */
    private function log_aggregation(array $stats): void {
        global $DB;

        $record = new \stdClass();
        $record->runat = time();
        $record->status = 'aggregated';
        $record->details = json_encode($stats);

        $DB->insert_record('local_financecosts_log', $record);
    }

    /**
     * Get recent sync logs.
     *
     * @param int $limit Number of logs to retrieve
     * @return array Log records
     */
    public function get_recent_logs(int $limit = 50): array {
        global $DB;

        return $DB->get_records('local_financecosts_log', null, 'runat DESC', '*', 0, $limit);
    }

    /**
     * Clean old log entries.
     *
     * @param int $days_to_keep Number of days to keep logs
     */
    public function clean_old_logs(int $days_to_keep = 90): void {
        global $DB;

        $cutoff_time = time() - ($days_to_keep * 24 * 60 * 60);
        $DB->delete_records_select('local_financecosts_log', 'runat < ?', [$cutoff_time]);
    }

    /**
     * Get summary of sync operations by status.
     *
     * @param int $days Number of days to look back
     * @return array Status summary
     */
    public function get_sync_summary(int $days = 30): array {
        global $DB;

        $since = time() - ($days * 24 * 60 * 60);

        $sql = "SELECT status, COUNT(*) as count
                FROM {local_financecosts_log}
                WHERE runat > ?
                GROUP BY status";

        $results = $DB->get_records_sql($sql, [$since]);
        
        $summary = ['success' => 0, 'error' => 0, 'running' => 0, 'aggregated' => 0];
        
        foreach ($results as $result) {
            $summary[$result->status] = $result->count;
        }

        return $summary;
    }
} 