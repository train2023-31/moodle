<?php
// Front-controller – handles tabs & routing (dashboard, dataview, management).

require_once(__DIR__.'/../../config.php');

$view   = optional_param('view', 'dashboard', PARAM_ALPHA);
$page   = optional_param('page', 0, PARAM_INT);

require_login();
$context = context_system::instance();
require_capability('local/financecosts:view', $context);

$PAGE->set_url(new moodle_url('/local/financecosts/index.php', ['view' => $view]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pluginname', 'local_financecosts'));
$PAGE->set_heading(get_string('pluginname', 'local_financecosts'));

$renderer = $PAGE->get_renderer('local_financecosts');

echo $OUTPUT->header();

// --- Navigation tabs -------------------------------------------------------
$tabs = [
    new tabobject('dashboard',
        new moodle_url('/local/financecosts/index.php', ['view' => 'dashboard']),
        get_string('dashboard', 'local_financecosts')),
    new tabobject('dataview',
        new moodle_url('/local/financecosts/index.php', ['view' => 'dataview']),
        get_string('dataview', 'local_financecosts')),
];

if (has_capability('local/financecosts:manage', $context)) {
    $tabs[] = new tabobject('management',
        new moodle_url('/local/financecosts/index.php', ['view' => 'management']),
        get_string('management', 'local_financecosts'));
}

print_tabs([$tabs], $view);

// --- View dispatch --------------------------------------------------------
switch ($view) {

    case 'dataview':
        // Filter form.
        $mform = new \local_financecosts\form\filter_form(null, []);
        $filterdata = $mform->get_data() ?? (object)['course' => null, 'status' => ''];

        [$rows, $total] =
            \local_financecosts\manager::get_detailed_rows(
                $page, 25, $filterdata->course, $filterdata->status);

        // Form first.
        $mform->display();

        echo $renderer->datatable($rows, $total, $page, 25);
        break;

    case 'management':
        require_capability('local/financecosts:manage', $context);
        echo $OUTPUT->notification('Management UI coming soon.', \core\output\notification::NOTIFY_INFO);
        break;

    case 'dashboard':
    default:
        echo $renderer->dashboard();
        break;
}

echo $OUTPUT->footer();
