# Example: Enrollment Fees Plugin Integration

## Overview

This document provides a complete working example of integrating an enrollment fees plugin (`local_enrollmentfees`) with the Finance Costs plugin. This serves as a practical reference for implementing your own data source integration.

## Scenario

We have an enrollment fees plugin that charges students fees for course enrollment. The plugin has:

- Course-based fees
- Status workflow integration
- Soft delete capability
- Timestamps for audit trail

## Database Structure

### Enrollment Fees Table

```sql
CREATE TABLE mdl_local_enrollmentfees (
    id int(10) NOT NULL AUTO_INCREMENT,
    course_id int(10) NOT NULL,
    student_id int(10) NOT NULL,
    fee_amount decimal(10,2) NOT NULL,
    status_id int(10) NOT NULL DEFAULT 1,
    fee_type varchar(50) DEFAULT 'enrollment',
    payment_method varchar(20) DEFAULT NULL,
    created_time int(10) NOT NULL,
    updated_time int(10) DEFAULT NULL,
    deleted tinyint(1) NOT NULL DEFAULT 0,
    notes text DEFAULT NULL,
    
    PRIMARY KEY (id),
    KEY idx_course_id (course_id),
    KEY idx_student_id (student_id),
    KEY idx_status_id (status_id),
    KEY idx_created_time (created_time),
    KEY idx_deleted (deleted),
    
    FOREIGN KEY (course_id) REFERENCES mdl_course(id),
    FOREIGN KEY (student_id) REFERENCES mdl_user(id),
    FOREIGN KEY (status_id) REFERENCES mdl_local_status(id)
);
```

### Sample Data

```sql
INSERT INTO mdl_local_enrollmentfees 
(course_id, student_id, fee_amount, status_id, created_time, deleted) VALUES
(10, 105, 250.00, 1, 1640995200, 0),  -- pending
(10, 106, 250.00, 2, 1640995300, 0),  -- approved  
(11, 105, 180.00, 3, 1640995400, 0),  -- rejected
(12, 107, 320.00, 1, 1640995500, 0);  -- pending
```

## Integration Implementation

### Step 1: Manager Class Updates (`classes/manager.php`)

#### A) Update `get_summary_totals()` method

```php
/**
 * Return summary totals for the dashboard cards.
 */
public static function get_summary_totals(): array {
    global $DB;

    // Existing code for external lecturer and finance services...
    
    // Add enrollment fees totals
    $enrollmentfees_total = 0;
    if ($DB->get_manager()->table_exists('local_enrollmentfees')) {
        $enrollmentfees_total = (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(ef.fee_amount), 0)
            FROM {local_enrollmentfees} ef
            WHERE ef.deleted = 0
        ");
    }

    $total = $externallecturer_total + $financeservices_total + $enrollmentfees_total;

    // Get approved amounts from enrollment fees
    $approved = /* existing approved calculations */ ;
    if ($DB->get_manager()->table_exists('local_enrollmentfees')) {
        $approved += (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(ef.fee_amount), 0)
            FROM {local_enrollmentfees} ef
            INNER JOIN {local_status} s ON s.id = ef.status_id
            WHERE s.name LIKE '%approved%' AND ef.deleted = 0
        ");
    }

    // Get pending amounts from enrollment fees  
    $pending = /* existing pending calculations */ ;
    if ($DB->get_manager()->table_exists('local_enrollmentfees')) {
        $pending += (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(ef.fee_amount), 0)
            FROM {local_enrollmentfees} ef
            INNER JOIN {local_status} s ON s.id = ef.status_id
            WHERE s.name LIKE '%pending%' AND ef.deleted = 0
        ");
    }

    // Get rejected amounts from enrollment fees
    $rejected = /* existing rejected calculations */ ;
    if ($DB->get_manager()->table_exists('local_enrollmentfees')) {
        $rejected += (float)$DB->get_field_sql("
            SELECT COALESCE(SUM(ef.fee_amount), 0)
            FROM {local_enrollmentfees} ef
            INNER JOIN {local_status} s ON s.id = ef.status_id
            WHERE s.name LIKE '%reject%' AND ef.deleted = 0
        ");
    }

    return [
        'total'    => $total,
        'approved' => $approved,
        'pending'  => $pending,
        'rejected' => $rejected,
    ];
}
```

#### B) Update `get_detailed_rows()` method

```php
public static function get_detailed_rows(int $page, int $perpage, ?int $course, ?string $status): array {
    global $DB;

    $params = [];
    $where  = [];

    // Update course filtering to include enrollment fees
    if ($course) {
        $where[] = '(fs.course_id = :courseid OR ec.courseid = :courseid2 OR ef.course_id = :courseid3)';
        $params['courseid'] = $course;
        $params['courseid2'] = $course;
        $params['courseid3'] = $course;
    }

    // Status filtering logic remains the same...
    
    $wheresql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // Main UNION query with enrollment fees
    $sql = "
    SELECT 
        ROW_NUMBER() OVER (ORDER BY timecreated DESC) as id,
        courseid,
        amount,
        status,
        timecreated,
        source
    FROM (
        -- Finance Services data
        SELECT 
            fs.course_id as courseid,
            fs.price_requested as amount,
            COALESCE(s.display_name_en, s.name, 'unknown') as status,
            fs.date_time_requested as timecreated,
            'financeservices' as source
        FROM {local_financeservices} fs
        LEFT JOIN {local_status} s ON s.id = fs.status_id
        
        UNION ALL
        
        -- External Lecturer data
        SELECT 
            ec.courseid,
            CAST(ec.cost AS DECIMAL(10,2)) as amount,
            'pending' as status,
            COALESCE((SELECT created_at FROM {employee} LIMIT 1), " . time() . ") as timecreated,
            'externallecturer' as source
        FROM {externallecturer_courses} ec
        INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
        
        UNION ALL
        
        -- Enrollment Fees data
        SELECT 
            ef.course_id as courseid,
            ef.fee_amount as amount,
            COALESCE(s.display_name_en, s.name, 'pending') as status,
            ef.created_time as timecreated,
            'enrollmentfees' as source
        FROM {local_enrollmentfees} ef
        LEFT JOIN {local_status} s ON s.id = ef.status_id
        WHERE ef.deleted = 0
    ) combined_data
    $wheresql
    ORDER BY timecreated DESC
    ";

    // Update count query
    $countsql = "
    SELECT COUNT(*) FROM (
        SELECT 1 FROM {local_financeservices} fs LEFT JOIN {local_status} s ON s.id = fs.status_id
        UNION ALL
        SELECT 1 FROM {externallecturer_courses} ec INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
        UNION ALL
        SELECT 1 FROM {local_enrollmentfees} ef LEFT JOIN {local_status} s ON s.id = ef.status_id WHERE ef.deleted = 0
    ) combined_data
    $wheresql
    ";

    $total = $DB->count_records_sql($countsql, $params);
    $rows = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);

    return [$rows, $total];
}
```

#### C) Update `get_course_options()` method

```php
public static function get_course_options(): array {
    global $DB;

    $sql = "
    SELECT DISTINCT c.id, c.fullname
    FROM {course} c
    WHERE c.id IN (
        SELECT DISTINCT course_id FROM {local_financeservices}
        UNION
        SELECT DISTINCT courseid FROM {externallecturer_courses}
        UNION
        SELECT DISTINCT course_id FROM {local_enrollmentfees} WHERE deleted = 0
    )
    ORDER BY c.fullname
    ";

    $courses = $DB->get_records_sql($sql);
    $options = [0 => get_string('all')];
    
    foreach ($courses as $course) {
        $options[$course->id] = $course->fullname;
    }

    return $options;
}
```

### Step 2: Sync Manager Updates (`classes/sync_manager.php`)

#### A) Update `sync_all_data()` method

```php
public function sync_all_data(): array {
    global $DB;

    $stats = [
        'externallecturer_count' => 0,
        'financeservices_count' => 0,
        'clause_count' => 0,
        'enrollmentfees_count' => 0,  // Add this
        'sync_time' => time(),
    ];

    try {
        $log_id = $this->log_sync_start();

        // Existing sync calls...
        $stats['externallecturer_count'] = $this->sync_externallecturer_data();
        $stats['financeservices_count'] = $this->sync_financeservices_data();
        $stats['clause_count'] = $this->sync_clause_data();
        
        // Add enrollment fees sync
        $stats['enrollmentfees_count'] = $this->sync_enrollmentfees_data();

        $this->log_sync_completion($log_id, 'success', $stats);

    } catch (\Exception $e) {
        if (isset($log_id)) {
            $this->log_sync_completion($log_id, 'error', ['error' => $e->getMessage()]);
        }
        throw $e;
    }

    return $stats;
}
```

#### B) Add sync method for enrollment fees

```php
/**
 * Sync enrollment fees data.
 *
 * @return int Number of records processed
 */
private function sync_enrollmentfees_data(): int {
    global $DB;

    // Check if enrollment fees tables exist
    if (!$DB->get_manager()->table_exists('local_enrollmentfees')) {
        return 0;
    }

    $sql = "SELECT COUNT(*) FROM {local_enrollmentfees} 
            WHERE fee_amount IS NOT NULL AND fee_amount > 0
            AND deleted = 0";

    return $DB->count_records_sql($sql);
}
```

#### C) Update `aggregate_data()` method

```php
public function aggregate_data(): array {
    global $DB;

    $stats = manager::get_summary_totals();
    
    // Count total records processed (including enrollment fees)
    $stats['record_count'] = $DB->count_records_sql("
        SELECT COUNT(*) FROM (
            SELECT 1 FROM {local_financeservices}
            UNION ALL
            SELECT 1 FROM {externallecturer_courses}
            UNION ALL  
            SELECT 1 FROM {local_financeservices_clause} WHERE deleted = 0
            UNION ALL
            SELECT 1 FROM {local_enrollmentfees} WHERE deleted = 0
        ) combined
    ");

    $this->log_aggregation($stats);
    return $stats;
}
```

### Step 3: Task Updates (`classes/task/sync_financial_data.php`)

```php
public function execute() {
    $sync_manager = new sync_manager();
    
    mtrace('Starting financial data synchronization...');
    
    try {
        $result = $sync_manager->sync_all_data();
        
        mtrace('Synchronization completed successfully.');
        mtrace("- External lecturer costs processed: {$result['externallecturer_count']}");
        mtrace("- Finance services processed: {$result['financeservices_count']}");
        mtrace("- Clauses processed: {$result['clause_count']}");
        mtrace("- Enrollment fees processed: {$result['enrollmentfees_count']}");
        
    } catch (\Exception $e) {
        mtrace('Error during synchronization: ' . $e->getMessage());
        throw $e;
    }
}
```

### Step 4: Language Strings (`lang/en/local_financecosts.php`)

```php
$string['source_enrollmentfees'] = 'Enrollment Fees';
$string['task_sync_enrollmentfees'] = 'Sync Enrollment Fees Data';
```

## Testing the Integration

### 1. Database Setup

Create test data:

```sql
-- Insert test enrollment fees
INSERT INTO mdl_local_enrollmentfees 
(course_id, student_id, fee_amount, status_id, created_time, deleted) VALUES
(2, 10, 150.00, 1, UNIX_TIMESTAMP(), 0),  -- pending
(2, 11, 150.00, 2, UNIX_TIMESTAMP(), 0),  -- approved
(3, 10, 200.00, 3, UNIX_TIMESTAMP(), 0);  -- rejected
```

### 2. Manual Testing

1. **Visit Dashboard** (`/local/financecosts/`)
   - Verify enrollment fees appear in totals
   - Check approved/pending/rejected breakdowns

2. **Check Management Page** (`/local/financecosts/manage.php`)
   - Verify enrollment fees appear in data table
   - Test course filtering
   - Test status filtering

### 3. Cron Testing

```bash
# Test sync task
php admin/cli/scheduled_task.php --execute=\\local_financecosts\\task\\sync_financial_data

# Expected output:
# Starting financial data synchronization...
# Synchronization completed successfully.
# - External lecturer costs processed: 5
# - Finance services processed: 12
# - Clauses processed: 8
# - Enrollment fees processed: 3
```

### 4. SQL Testing

Test individual queries:

```sql
-- Test summary query
SELECT COALESCE(SUM(ef.fee_amount), 0) as total
FROM mdl_local_enrollmentfees ef
WHERE ef.deleted = 0;

-- Test approved query
SELECT COALESCE(SUM(ef.fee_amount), 0) as approved
FROM mdl_local_enrollmentfees ef
INNER JOIN mdl_local_status s ON s.id = ef.status_id
WHERE s.name LIKE '%approved%' AND ef.deleted = 0;

-- Test detailed data query
SELECT 
    ef.course_id as courseid,
    ef.fee_amount as amount,
    COALESCE(s.display_name_en, s.name, 'pending') as status,
    ef.created_time as timecreated,
    'enrollmentfees' as source
FROM mdl_local_enrollmentfees ef
LEFT JOIN mdl_local_status s ON s.id = ef.status_id
WHERE ef.deleted = 0
ORDER BY ef.created_time DESC;
```

## Expected Results

### Dashboard Totals

With the test data above:
- **Total**: Should include $500.00 from enrollment fees
- **Approved**: Should include $150.00 from approved enrollment fees  
- **Pending**: Should include $150.00 from pending enrollment fees
- **Rejected**: Should include $200.00 from rejected enrollment fees

### Data Table

The management interface should show enrollment fees with:
- Source: "enrollmentfees"
- Proper status labels from the status system
- Course names for filtering
- Correct amounts and timestamps

### Sync Logs

Sync operations should log:
- Number of enrollment fee records processed
- Any errors during synchronization
- Performance statistics

## Common Customizations

### Adding Additional Fields

If you need to display more information:

```php
-- Enhance the detailed query to include additional fields
SELECT 
    ef.course_id as courseid,
    ef.fee_amount as amount,
    COALESCE(s.display_name_en, s.name, 'pending') as status,
    ef.created_time as timecreated,
    'enrollmentfees' as source,
    ef.fee_type,  -- Additional field
    CONCAT(u.firstname, ' ', u.lastname) as student_name  -- Student info
FROM {local_enrollmentfees} ef
LEFT JOIN {local_status} s ON s.id = ef.status_id
LEFT JOIN {user} u ON u.id = ef.student_id
WHERE ef.deleted = 0
```

### Custom Status Logic

For special status handling:

```php
// Custom status mapping
$status_mapping = [
    'draft' => 'pending',
    'submitted' => 'pending', 
    'approved' => 'approved',
    'paid' => 'approved',
    'cancelled' => 'rejected',
    'refunded' => 'rejected'
];

// Use CASE statement in SQL
CASE 
    WHEN s.name IN ('draft', 'submitted') THEN 'pending'
    WHEN s.name IN ('approved', 'paid') THEN 'approved'
    WHEN s.name IN ('cancelled', 'refunded') THEN 'rejected'
    ELSE COALESCE(s.display_name_en, s.name, 'pending')
END as status
```

### Performance Optimization

For large datasets:

```sql
-- Add indexes for better performance
ALTER TABLE mdl_local_enrollmentfees 
ADD INDEX idx_composite (course_id, status_id, deleted, created_time);

-- Use more efficient queries
SELECT /*+ USE_INDEX(ef, idx_composite) */
    ef.course_id, ef.fee_amount, s.name
FROM mdl_local_enrollmentfees ef
INNER JOIN mdl_local_status s ON s.id = ef.status_id
WHERE ef.deleted = 0 
AND ef.created_time > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 YEAR));
```

This example demonstrates a complete integration that follows all best practices and provides a solid foundation for integrating any finance-related plugin with the Finance Costs system. 