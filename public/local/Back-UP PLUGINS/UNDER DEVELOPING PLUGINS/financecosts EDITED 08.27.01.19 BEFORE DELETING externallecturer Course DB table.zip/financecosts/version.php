<?php
// This file is part of Moodle – http://moodle.org/
//
// local_financecosts – plugin version definition.
// See http://docs.moodle.org/dev/version.php for details.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_financecosts';
$plugin->version   = 2025082701;       // YmdHis – bump on every change.
$plugin->release   = '2.3.0';
$plugin->requires  = 2022041900;       // Moodle 3.11 (min).
$plugin->maturity  = MATURITY_STABLE;  // Changed to stable after enhancements.
