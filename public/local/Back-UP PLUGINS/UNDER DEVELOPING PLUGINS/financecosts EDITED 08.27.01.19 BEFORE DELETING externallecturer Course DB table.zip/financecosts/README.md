# Finance Costs Plugin

A centralized financial cost management system for Moodle that aggregates and reports on costs from various finance-related plugins.

## Features

### 📊 Enhanced Dashboard
- Real-time cost summaries (Total, Approved, Pending, Rejected)
- Financial data aggregation from multiple sources with enhanced validation
- Clean, responsive interface with Bootstrap cards
- Enhanced status integration with comprehensive workflow support

### 📋 Enhanced Data Management
- Detailed cost records with filtering and pagination
- Course-based and status-based filtering with enhanced categorization
- Unified view of costs from all integrated plugins
- Additional information display for better context

### ⚙️ Enhanced Management Interface
- Category CRUD operations for cost organization
- Sync log viewer with detailed operation history and analysis
- Manual data synchronization controls
- Comprehensive settings management
- Enhanced statistics and reporting

### 🔄 Enhanced Automated Synchronization
- **Sync Financial Data**: Runs daily at 2:00 AM with enhanced logging
- **Aggregate Reports**: Runs twice daily at 6:30 AM and 6:30 PM with detailed statistics
- Automatic log cleanup and data validation
- Enhanced error handling and performance monitoring

## Integrated Plugins

### 1. External Lecturer Plugin (Enhanced)
- **Table**: `externallecturer_courses`
- **Cost Field**: `cost` (with enhanced validation)
- **Status**: Treated as "pending" by default
- **Enhanced Features**: Lecturer type tracking, nationality, audit trail
- **New Fields**: `lecturer_type`, `nationality`, `civil_number`, `created_by`, `modified_by`

### 2. Finance Services Plugin (Enhanced)
- **Table**: `local_financeservices`
- **Amount Field**: `price_requested` (with enhanced validation)
- **Status**: Integrated with enhanced workflow system (`local_status`)
- **Enhanced Features**: Approval/rejection notes, cause tracking, submission timestamps
- **New Fields**: `date_time_processed`, `date_time_submitted`, `cause`, `rejection_note`, `approval_note`

### 3. Finance Services Clauses (Enhanced)
- **Table**: `local_financeservices_clause`
- **Amount Field**: `amount`
- **Status**: Active/deleted flag support with enhanced tracking

### 4. Status Plugin Integration (Enhanced)
- **Enhanced Status System**: Better workflow management with approver tracking
- **Bilingual Support**: Arabic and English status display names
- **Enhanced Categories**: Better status categorization (approved, pending, rejected)
- **New Features**: Dynamic approver management, workflow instances, transition rules

## Database Schema

### Categories Table (`local_financecosts_cat`)
```sql
- id (int): Primary key
- name (varchar): Category name (unique)
- description (text): Category description
- isactive (tinyint): Active status
- timecreated (int): Creation timestamp
- timemodified (int): Last modification timestamp
```

### Sync Log Table (`local_financecosts_log`)
```sql
- id (int): Primary key
- runat (int): Execution timestamp
- status (varchar): Operation status (running/success/error/aggregated)
- details (text): JSON-encoded operation details (enhanced with detailed statistics)
```

## API Documentation

### Manager Class (`\local_financecosts\manager`)

#### `get_summary_totals(): array`
Returns dashboard summary with total, approved, pending, and rejected amounts (enhanced with better validation).

#### `get_detailed_rows(int $page, int $perpage, ?int $course, ?string $status): array`
Returns paginated, filtered cost records with metadata and additional information.

#### `get_course_options(): array`
Returns available courses for filtering dropdowns (enhanced with better validation).

#### `get_status_options(): array`
Returns available status options for filtering (enhanced with bilingual support and better categorization).

#### `get_enhanced_statistics(): array` (NEW)
Returns comprehensive statistics for dashboard and reporting purposes.

### Sync Manager Class (`\local_financecosts\sync_manager`)

#### `sync_all_data(): array`
Performs complete data synchronization from all integrated plugins (enhanced with detailed statistics).

#### `aggregate_data(): array`
Aggregates financial data for reporting purposes (enhanced with comprehensive statistics).

#### `get_recent_logs(int $limit = 50): array`
Retrieves recent synchronization logs.

#### `clean_old_logs(int $days_to_keep = 90): void`
Cleans up old log entries.

#### `get_detailed_sync_analysis(int $days = 30): array` (NEW)
Provides detailed analysis of sync operations including performance metrics and error tracking.

## Installation

1. Place the plugin in `/local/financecosts/`
2. Visit Site Administration → Notifications to install
3. Configure capabilities for finance staff
4. Set up automatic synchronization in Site Administration → Server → Scheduled Tasks

## Configuration

### Admin Settings
- **Sync Frequency**: How often data should be synchronized (hours)
- **Log Retention**: Number of days to keep sync logs

### Capabilities
- **local/financecosts:view**: View dashboard and cost data
- **local/financecosts:manage**: Manage categories and system settings

## Usage

### Accessing the Plugin
Navigate to: **Site Administration → Plugins → Local plugins → Finance Costs**

### Dashboard
View real-time financial summaries and key metrics with enhanced statistics.

### Data View
Browse detailed cost records with advanced filtering:
- Filter by course
- Filter by status (enhanced with better categorization)
- Paginated results with search
- Additional information display

### Management
- Create and manage cost categories
- Monitor synchronization logs with detailed analysis
- Perform manual sync operations
- View enhanced sync statistics and summaries
- Access detailed sync analysis and performance metrics

## Cron Tasks

### Sync Financial Data
- **Frequency**: Daily at 2:00 AM
- **Purpose**: Synchronize data from external plugins with enhanced logging
- **Class**: `\local_financecosts\task\sync_financial_data`
- **Enhanced Output**: Detailed statistics and performance metrics

### Aggregate Reports
- **Frequency**: Twice daily (6:30 AM, 6:30 PM)
- **Purpose**: Generate aggregated reports and statistics with enhanced analysis
- **Class**: `\local_financecosts\task\aggregate_reports`
- **Enhanced Output**: Comprehensive statistics and status breakdowns

## Troubleshooting

### Common Issues

1. **No data appearing**: Check if integrated plugins are installed and have data
2. **Sync failures**: Check logs in Management → Sync Logs with enhanced error analysis
3. **Permission errors**: Verify user has appropriate capabilities

### Log Analysis
All synchronization operations are logged with detailed JSON information:
- Success/failure status
- Record counts processed
- Error messages and stack traces
- Performance metrics
- Enhanced statistics and analysis

## Development

### Adding New Data Sources
1. Update `manager::get_summary_totals()` to include new aggregation queries
2. Modify `manager::get_detailed_rows()` to include new data in UNION query
3. Add sync methods in `sync_manager` class
4. Update language strings as needed
5. Follow enhanced validation patterns for better data integrity

### Custom Categories
Categories can be used to organize costs by:
- Department
- Project
- Cost center
- Time period
- Custom business logic

## Support

For technical support or feature requests, please contact your system administrator or development team.

## Version History

- **v1.0**: Initial implementation with basic dashboard
- **v2.0**: Added real aggregation queries and sync functionality
- **v2.1**: Complete management interface with category CRUD
- **v2.2**: Enhanced logging and automated synchronization
- **v2.3**: Enhanced integration with updated plugins, better validation, and comprehensive statistics 