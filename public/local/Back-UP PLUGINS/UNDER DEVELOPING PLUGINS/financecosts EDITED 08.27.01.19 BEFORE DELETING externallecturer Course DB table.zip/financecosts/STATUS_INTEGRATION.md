# Status Integration Documentation

## Overview

The Finance Costs plugin integrates with the **local_status** plugin to track the approval status of each cost request. Each finance request has its own status field that directly links to the status system.

## Status Field Architecture

### Direct Status Relationship
Each cost request table has a `status_id` field that directly references `local_status.id`:

```sql
-- Finance Services Request
local_financeservices.status_id → local_status.id

-- Other plugins may have similar direct relationships
-- (External lecturer currently defaults to "pending")
```

### How It Works

1. **Request Creation**: When a cost request is created, it gets assigned a `status_id`
2. **Status Changes**: The `status_id` can be updated as the request moves through workflow
3. **Reporting**: Our plugin reads the current status directly from the status table

## Integration Points

### Finance Services Plugin (`local_financeservices`)

**Table Structure**:
```sql
CREATE TABLE local_financeservices (
    id int(10) PRIMARY KEY,
    course_id int(10),
    price_requested float,
    status_id int(10) NOT NULL,  -- Direct link to local_status
    -- other fields...
    FOREIGN KEY (status_id) REFERENCES local_status(id)
);
```

**Status Integration**:
- ✅ **Direct Link**: `status_id` field directly references status
- ✅ **Real-time Status**: Always current, no separate workflow tracking
- ✅ **Display Names**: Uses `display_name_en` for user-friendly status labels

### External Lecturer Plugin (`externallecturer_courses`)

**Table Structure**:
```sql
CREATE TABLE externallecturer_courses (
    id int(10) PRIMARY KEY,
    lecturerid int(10),
    courseid int(10),
    cost varchar(10),
    -- No status_id field currently
);
```

**Status Handling**:
- ❌ **No Status Field**: Currently no direct status integration
- 🔄 **Default Status**: Treated as "pending" in reports
- 🎯 **Future Enhancement**: Could add `status_id` field for workflow integration

## SQL Queries Used

### Summary Totals (Dashboard)

```sql
-- Approved amounts
SELECT COALESCE(SUM(fs.price_requested), 0)
FROM {local_financeservices} fs
INNER JOIN {local_status} s ON s.id = fs.status_id
WHERE s.name LIKE '%approved%'

-- Pending amounts  
SELECT COALESCE(SUM(fs.price_requested), 0)
FROM {local_financeservices} fs
INNER JOIN {local_status} s ON s.id = fs.status_id
WHERE s.name LIKE '%pending%'

-- Rejected amounts
SELECT COALESCE(SUM(fs.price_requested), 0)
FROM {local_financeservices} fs
INNER JOIN {local_status} s ON s.id = fs.status_id
WHERE s.name LIKE '%reject%'
```

### Detailed Data (Data View)

```sql
-- Combined data from all sources
SELECT 
    fs.course_id as courseid,
    fs.price_requested as amount,
    COALESCE(s.display_name_en, s.name, 'unknown') as status,
    fs.date_time_requested as timecreated,
    'financeservices' as source
FROM {local_financeservices} fs
LEFT JOIN {local_status} s ON s.id = fs.status_id

UNION ALL

-- External lecturer (no status field)
SELECT 
    ec.courseid,
    CAST(ec.cost AS DECIMAL(10,2)) as amount,
    'pending' as status,  -- Default for external lecturer
    -- timecreated, source...
FROM {externallecturer_courses} ec
```

## Status Options for Filtering

```sql
-- Get only statuses that are actually used
SELECT DISTINCT s.name, s.display_name_en, s.seq
FROM {local_status} s
INNER JOIN {local_financeservices} fs ON fs.status_id = s.id
ORDER BY s.seq, s.display_name_en
```

## Benefits of Direct Status Integration

### ✅ **Advantages**

1. **Simplicity**: Direct foreign key relationship, no complex workflow tables
2. **Performance**: Single JOIN instead of multiple table lookups
3. **Real-time**: Status is always current in the request table
4. **Flexibility**: Each plugin can implement its own status workflow
5. **Data Integrity**: Foreign key constraints ensure valid statuses

### 🎯 **Compared to Workflow Instance System**

**Old Complex Approach** (Not Used):
```sql
-- Multiple table joins for status lookup
local_financeservices → local_status_instance → local_status_type → local_status
```

**Current Simple Approach**:
```sql  
-- Direct relationship
local_financeservices.status_id → local_status.id
```

## Adding Status to Other Plugins

If you want to add status tracking to other finance plugins:

### 1. Add Status Field to Table
```sql
ALTER TABLE your_plugin_table 
ADD COLUMN status_id int(10) NOT NULL,
ADD FOREIGN KEY (status_id) REFERENCES local_status(id);
```

### 2. Update Finance Costs Integration
Add the plugin to the UNION query in `manager.php`:

```php
// Your plugin data
SELECT 
    yp.course_field as courseid,
    yp.amount_field as amount,
    COALESCE(s.display_name_en, s.name, 'unknown') as status,
    yp.date_field as timecreated,
    'yourplugin' as source
FROM {your_plugin_table} yp
LEFT JOIN {local_status} s ON s.id = yp.status_id
```

### 3. Update Summary Calculations
Include your plugin in the totals:

```php
// Add to approved/pending/rejected calculations
$approved += (float)$DB->get_field_sql("
    SELECT COALESCE(SUM(yp.amount_field), 0)
    FROM {your_plugin_table} yp
    INNER JOIN {local_status} s ON s.id = yp.status_id
    WHERE s.name LIKE '%approved%'
");
```

## Status Name Conventions

The system looks for status names containing these keywords:

- **Approved**: `approved`, `approve`, `accept`
- **Pending**: `pending`, `waiting`, `review`
- **Rejected**: `reject`, `denied`, `decline`

Example status names:
- `pending_review`
- `approved_final`
- `rejected_incomplete`

## Error Handling

```php
// Graceful handling of missing status
COALESCE(s.display_name_en, s.name, 'unknown') as status

// Default for plugins without status fields
'pending' as status
```

This ensures the system continues to work even if:
- Status records are missing
- Display names are not set
- Plugins don't have status integration yet

---

This direct status integration provides a clean, efficient way to track cost request statuses while maintaining flexibility for different plugin implementations.

# Cost Calculation Logic

## Simple Total Calculation

**Important:** Clauses are components within finance service requests, not separate cost entries. Only count actual cost records:

```sql
-- CORRECT: Only count actual cost records
SELECT SUM(fs.price_requested) + SUM(ec.cost)
FROM finance_services + external_lecturer_courses
```

## Data Relationships

- **Finance Services**: `price_requested` is the total cost for that service request
- **Clauses**: Internal components/line items within finance requests (not counted separately)
- **External Lecturer**: Separate cost tracking with `cost` field

## Status Integration with Finance Services Plugin

// ... existing code ... 