<?php
// English language pack for local_financecosts.

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Finance Costs';
$string['financecosts:view'] = 'View finance costs';
$string['financecosts:manage'] = 'Manage finance costs';

// Navigation.
$string['dashboard'] = 'Dashboard';
$string['data'] = 'Data';
$string['dataview'] = 'Data View';
$string['management'] = 'Management';

// Dashboard.
$string['total_costs'] = 'Total Costs';
$string['approved_costs'] = 'Approved Costs';
$string['pending_costs'] = 'Pending Costs';
$string['rejected_costs'] = 'Rejected Costs';

// Data view.
$string['course'] = 'Course';
$string['amount'] = 'Amount';
$string['status'] = 'Status';
$string['date'] = 'Date';
$string['source'] = 'Source';
$string['all'] = 'All';
$string['pending'] = 'Pending';
$string['show_entries'] = 'Show entries';
$string['search'] = 'Search';

// Management interface.
$string['manage_title'] = 'Finance Costs Management';
$string['manage_heading'] = 'Manage Finance Costs';
$string['categories'] = 'Categories';
$string['sync_logs'] = 'Sync Logs';

// Category management.
$string['add_category'] = 'Add Category';
$string['addcategory'] = 'Add New Category';
$string['editcategory'] = 'Edit Category';
$string['category_name'] = 'Category Name';
$string['category_description'] = 'Description';
$string['category_active'] = 'Active';
$string['category_added'] = 'Category added successfully';
$string['category_updated'] = 'Category updated successfully';
$string['category_deleted'] = 'Category deleted successfully';
$string['update_category'] = 'Update Category';
$string['category_name_exists'] = 'A category with this name already exists';
$string['confirm_delete_category'] = 'Are you sure you want to delete the category "{$a}"?';
$string['no_categories'] = 'No categories found. Add your first category to get started.';
$string['name'] = 'Name';
$string['description'] = 'Description';
$string['active'] = 'Active';
$string['created'] = 'Created';
$string['actions'] = 'Actions';

// Help strings.
$string['category_name_help'] = 'Enter a unique name for this finance cost category.';
$string['category_description_help'] = 'Provide a detailed description of what this category covers.';
$string['category_active_help'] = 'Inactive categories will not appear in reports and filters.';

// Sync and logs.
$string['manual_sync'] = 'Manual Sync';
$string['confirm_sync'] = 'Are you sure you want to run a manual sync? This will aggregate data from all finance plugins.';
$string['sync_completed'] = 'Sync completed successfully. External lecturer: {$a->externallecturer_count}, Finance services: {$a->financeservices_count}, Clauses: {$a->clause_count}';
$string['sync_failed'] = 'Sync failed: {$a}';
$string['no_logs'] = 'No sync logs found.';
$string['details'] = 'Details';
$string['count'] = 'Count';
$string['sync_summary_30days'] = 'Sync Summary (Last 30 Days)';

// Cron tasks.
$string['task_sync_financial_data'] = 'Sync financial data from external plugins';
$string['task_aggregate_reports'] = 'Aggregate financial reports and data';

// Settings.
$string['settings_heading'] = 'Finance Costs Settings';
$string['sync_frequency'] = 'Sync Frequency';
$string['sync_frequency_desc'] = 'How often should financial data be synchronized (in hours)';
$string['log_retention'] = 'Log Retention Days';
$string['log_retention_desc'] = 'Number of days to keep sync logs before automatic cleanup';

// Privacy.
$string['privacy:metadata'] = 'The Finance Costs plugin does not store any personal user data. It only aggregates financial data from other plugins.';

// Filter and interface strings.
$string['filter'] = 'Filter';
$string['no_data'] = 'No data available';
$string['additional_info'] = 'Additional Information';

// Enhanced status strings
$string['status_approved'] = 'Approved';
$string['status_pending'] = 'Pending';
$string['status_rejected'] = 'Rejected';
$string['status_completed'] = 'Completed';
$string['status_submitted'] = 'Submitted';
$string['status_draft'] = 'Draft';
$string['status_cancelled'] = 'Cancelled';

// Enhanced statistics strings
$string['enhanced_statistics'] = 'Enhanced Statistics';
$string['external_lecturers_total'] = 'Total External Lecturers';
$string['external_lecturers_active'] = 'Active External Lecturers';
$string['external_visitors'] = 'External Visitors';
$string['residents'] = 'Residents';
$string['finance_requests_total'] = 'Total Finance Requests';
$string['finance_requests_active'] = 'Active Finance Requests';
$string['requests_with_notes'] = 'Requests with Notes';
$string['recent_activity_30_days'] = 'Recent Activity (30 Days)';

// Sync analysis strings
$string['sync_analysis'] = 'Sync Analysis';
$string['sync_performance'] = 'Sync Performance';
$string['recent_errors'] = 'Recent Errors';
$string['volume_trends'] = 'Volume Trends';
$string['avg_sync_time'] = 'Average Sync Time';
$string['last_run'] = 'Last Run';
$string['sync_count'] = 'Sync Count';

// Additional action strings for manage.php
$string['approved'] = 'Approved';
$string['rejected'] = 'Rejected';
