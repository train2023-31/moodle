<?php
// Admin-level configuration (Site administration ► Plugins ► Local plugins ► Finance costs).

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // Create a category for finance costs.
    $category = new admin_category('local_financecosts_cat', get_string('pluginname', 'local_financecosts'));
    $ADMIN->add('localplugins', $category);

    // Add main dashboard page.
    $ADMIN->add('local_financecosts_cat',
        new admin_externalpage(
            'local_financecosts',
            get_string('dashboard', 'local_financecosts'),
            new moodle_url('/local/financecosts/index.php'),
            'local/financecosts:view'
        )
    );

    // Add management page.
    $ADMIN->add('local_financecosts_cat',
        new admin_externalpage(
            'local_financecosts_manage',
            get_string('management', 'local_financecosts'),
            new moodle_url('/local/financecosts/manage.php'),
            'local/financecosts:manage'
        )
    );

    // Add settings page.
    $settings = new admin_settingpage('local_financecosts_settings', get_string('settings_heading', 'local_financecosts'));

    $settings->add(new admin_setting_configtext(
        'local_financecosts/sync_frequency',
        get_string('sync_frequency', 'local_financecosts'),
        get_string('sync_frequency_desc', 'local_financecosts'),
        24,
        PARAM_INT
    ));

    $settings->add(new admin_setting_configtext(
        'local_financecosts/log_retention',
        get_string('log_retention', 'local_financecosts'),
        get_string('log_retention_desc', 'local_financecosts'),
        90,
        PARAM_INT
    ));

    $ADMIN->add('local_financecosts_cat', $settings);
}
