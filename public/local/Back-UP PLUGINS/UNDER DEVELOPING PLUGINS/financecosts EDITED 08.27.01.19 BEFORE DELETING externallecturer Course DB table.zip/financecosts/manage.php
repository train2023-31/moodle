<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/tablelib.php');

use local_financecosts\sync_manager;
use local_financecosts\form\category_form;

// Security checks.
require_login();
admin_externalpage_setup('local_financecosts_manage');

$action = optional_param('action', 'categories', PARAM_ALPHA);
$id = optional_param('id', 0, PARAM_INT);

$PAGE->set_url('/local/financecosts/manage.php', ['action' => $action, 'id' => $id]);
$PAGE->set_title(get_string('manage_title', 'local_financecosts'));
$PAGE->set_heading(get_string('manage_heading', 'local_financecosts'));

// Handle actions.
switch ($action) {
    case 'addcategory':
        $mform = new category_form();
        if ($mform->is_cancelled()) {
            redirect(new moodle_url('/local/financecosts/manage.php'));
        } else if ($data = $mform->get_data()) {
            $record = new stdClass();
            $record->name = $data->name;
            $record->description = $data->description;
            $record->isactive = $data->isactive;
            $record->timecreated = time();
            
            $DB->insert_record('local_financecosts_cat', $record);
            
            \core\notification::success(get_string('category_added', 'local_financecosts'));
            redirect(new moodle_url('/local/financecosts/manage.php'));
        }
        break;
        
    case 'editcategory':
        if (!$id) {
            throw new moodle_exception('invalidid');
        }
        
        $category = $DB->get_record('local_financecosts_cat', ['id' => $id], '*', MUST_EXIST);
        $mform = new category_form(null, ['category' => $category]);
        
        if ($mform->is_cancelled()) {
            redirect(new moodle_url('/local/financecosts/manage.php'));
        } else if ($data = $mform->get_data()) {
            $record = new stdClass();
            $record->id = $id;
            $record->name = $data->name;
            $record->description = $data->description;
            $record->isactive = $data->isactive;
            $record->timemodified = time();
            
            $DB->update_record('local_financecosts_cat', $record);
            
            \core\notification::success(get_string('category_updated', 'local_financecosts'));
            redirect(new moodle_url('/local/financecosts/manage.php'));
        }
        break;
        
    case 'deletecategory':
        if (!$id) {
            throw new moodle_exception('invalidid');
        }
        
        if (optional_param('confirm', 0, PARAM_INT)) {
            $DB->delete_records('local_financecosts_cat', ['id' => $id]);
            \core\notification::success(get_string('category_deleted', 'local_financecosts'));
            redirect(new moodle_url('/local/financecosts/manage.php'));
        }
        break;
        
    case 'sync':
        if (optional_param('confirm', 0, PARAM_INT)) {
            $sync_manager = new sync_manager();
            try {
                $result = $sync_manager->sync_all_data();
                \core\notification::success(get_string('sync_completed', 'local_financecosts', $result));
            } catch (Exception $e) {
                \core\notification::error(get_string('sync_failed', 'local_financecosts', $e->getMessage()));
            }
            redirect(new moodle_url('/local/financecosts/manage.php', ['action' => 'logs']));
        }
        break;
}

echo $OUTPUT->header();

// Navigation tabs.
$tabs = [
    new tabobject('categories', new moodle_url('/local/financecosts/manage.php'), get_string('categories', 'local_financecosts')),
    new tabobject('logs', new moodle_url('/local/financecosts/manage.php', ['action' => 'logs']), get_string('sync_logs', 'local_financecosts')),
];

echo $OUTPUT->tabtree($tabs, $action);

// Display content based on action.
switch ($action) {
    case 'addcategory':
    case 'editcategory':
        echo $OUTPUT->heading(get_string($action, 'local_financecosts'));
        $mform->display();
        break;
        
    case 'deletecategory':
        if (!optional_param('confirm', 0, PARAM_INT)) {
            $category = $DB->get_record('local_financecosts_cat', ['id' => $id], '*', MUST_EXIST);
            echo $OUTPUT->confirm(
                get_string('confirm_delete_category', 'local_financecosts', $category->name),
                new moodle_url('/local/financecosts/manage.php', ['action' => 'deletecategory', 'id' => $id, 'confirm' => 1]),
                new moodle_url('/local/financecosts/manage.php')
            );
        }
        break;
        
    case 'sync':
        if (!optional_param('confirm', 0, PARAM_INT)) {
            echo $OUTPUT->confirm(
                get_string('confirm_sync', 'local_financecosts'),
                new moodle_url('/local/financecosts/manage.php', ['action' => 'sync', 'confirm' => 1]),
                new moodle_url('/local/financecosts/manage.php', ['action' => 'logs'])
            );
        }
        break;
        
    case 'logs':
        echo $OUTPUT->heading(get_string('sync_logs', 'local_financecosts'));
        
        // Manual sync button.
        echo $OUTPUT->single_button(
            new moodle_url('/local/financecosts/manage.php', ['action' => 'sync']),
            get_string('manual_sync', 'local_financecosts'),
            'get',
            ['class' => 'btn btn-primary mb-3']
        );
        
        // Display logs table.
        $sync_manager = new sync_manager();
        $logs = $sync_manager->get_recent_logs(100);
        
        if (empty($logs)) {
            echo $OUTPUT->notification(get_string('no_logs', 'local_financecosts'), 'info');
        } else {
            $table = new html_table();
            $table->head = [
                get_string('date', 'local_financecosts'),
                get_string('status', 'local_financecosts'),
                get_string('details', 'local_financecosts'),
            ];
            
            foreach ($logs as $log) {
                $status_class = '';
                switch ($log->status) {
                    case 'success':
                        $status_class = 'badge badge-success';
                        break;
                    case 'error':
                        $status_class = 'badge badge-danger';
                        break;
                    case 'running':
                        $status_class = 'badge badge-warning';
                        break;
                    default:
                        $status_class = 'badge badge-info';
                }
                
                $details = $log->details;
                if (is_string($log->details) && json_decode($log->details)) {
                    $details = '<pre>' . json_encode(json_decode($log->details), JSON_PRETTY_PRINT) . '</pre>';
                }
                
                $table->data[] = [
                    userdate($log->runat),
                    html_writer::span($log->status, $status_class),
                    $details,
                ];
            }
            
            echo html_writer::table($table);
        }
        
        // Sync summary.
        $summary = $sync_manager->get_sync_summary(30);
        echo $OUTPUT->heading(get_string('sync_summary_30days', 'local_financecosts'), 4);
        
        $summary_table = new html_table();
        $summary_table->head = [get_string('status', 'local_financecosts'), get_string('count', 'local_financecosts')];
        
        foreach ($summary as $status => $count) {
            $summary_table->data[] = [ucfirst($status), $count];
        }
        
        echo html_writer::table($summary_table);
        break;
        
    default: // categories
        echo $OUTPUT->heading(get_string('categories', 'local_financecosts'));
        
        // Add category button.
        echo $OUTPUT->single_button(
            new moodle_url('/local/financecosts/manage.php', ['action' => 'addcategory']),
            get_string('add_category', 'local_financecosts'),
            'get',
            ['class' => 'btn btn-primary mb-3']
        );
        
        // Categories table.
        $categories = $DB->get_records('local_financecosts_cat', null, 'name ASC');
        
        if (empty($categories)) {
            echo $OUTPUT->notification(get_string('no_categories', 'local_financecosts'), 'info');
        } else {
            $table = new html_table();
            $table->head = [
                get_string('name', 'local_financecosts'),
                get_string('description', 'local_financecosts'),
                get_string('active', 'local_financecosts'),
                get_string('created', 'local_financecosts'),
                get_string('actions', 'local_financecosts'),
            ];
            
            foreach ($categories as $category) {
                $actions = [];
                $actions[] = html_writer::link(
                    new moodle_url('/local/financecosts/manage.php', ['action' => 'editcategory', 'id' => $category->id]),
                    get_string('edit'),
                    ['class' => 'btn btn-sm btn-secondary']
                );
                $actions[] = html_writer::link(
                    new moodle_url('/local/financecosts/manage.php', ['action' => 'deletecategory', 'id' => $category->id]),
                    get_string('delete'),
                    ['class' => 'btn btn-sm btn-danger']
                );
                
                $table->data[] = [
                    $category->name,
                    $category->description ?: '-',
                    $category->isactive ? get_string('yes') : get_string('no'),
                    userdate($category->timecreated),
                    implode(' ', $actions),
                ];
            }
            
            echo html_writer::table($table);
        }
        break;
}

echo $OUTPUT->footer(); 