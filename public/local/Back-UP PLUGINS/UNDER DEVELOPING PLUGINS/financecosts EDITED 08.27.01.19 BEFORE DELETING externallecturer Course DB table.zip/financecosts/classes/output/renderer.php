<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\output;

use plugin_renderer_base;
use moodle_url;
use html_writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Renderer for local_financecosts output.
 */
class renderer extends plugin_renderer_base {

    /**
     * Render the complete dashboard view.
     *
     * @return string HTML output
     */
    public function dashboard(): string {
        // Get summary data from manager
        $summary = \local_financecosts\manager::get_summary_totals();
        
        // Render the dashboard
        $html = '';
        $html .= $this->output->heading(get_string('dashboard', 'local_financecosts'), 2);
        $html .= $this->render_dashboard_summary($summary);
        
        return $html;
    }

    /**
     * Render the dashboard summary cards.
     *
     * @param array $summary Summary data
     * @return string HTML output
     */
    public function render_dashboard_summary(array $summary): string {
        $html = '';
        
        $html .= html_writer::start_div('row');
        
        // Total costs card
        $html .= $this->render_summary_card(
            get_string('total_costs', 'local_financecosts'),
            number_format($summary['total'], 2),
            'fa-calculator',
            'primary'
        );
        
        // Approved costs card
        $html .= $this->render_summary_card(
            get_string('approved_costs', 'local_financecosts'),
            number_format($summary['approved'], 2),
            'fa-check-circle',
            'success'
        );
        
        // Pending costs card
        $html .= $this->render_summary_card(
            get_string('pending_costs', 'local_financecosts'),
            number_format($summary['pending'], 2),
            'fa-clock',
            'warning'
        );
        
        // Rejected costs card
        $html .= $this->render_summary_card(
            get_string('rejected_costs', 'local_financecosts'),
            number_format($summary['rejected'], 2),
            'fa-times-circle',
            'danger'
        );
        
        $html .= html_writer::end_div();
        
        return $html;
    }

    /**
     * Render a single summary card.
     *
     * @param string $title Card title
     * @param string $value Card value
     * @param string $icon Font Awesome icon class
     * @param string $color Bootstrap color class
     * @return string HTML output
     */
    private function render_summary_card(string $title, string $value, string $icon, string $color): string {
        $html = html_writer::start_div('col-md-3 mb-4');
        
        $html .= html_writer::start_div("card border-{$color}");
        $html .= html_writer::start_div('card-body text-center');
        
        $html .= html_writer::tag('i', '', ['class' => "fa {$icon} fa-3x text-{$color} mb-3"]);
        $html .= html_writer::tag('h4', $value, ['class' => "text-{$color}"]);
        $html .= html_writer::tag('p', $title, ['class' => 'card-text']);
        
        $html .= html_writer::end_div();
        $html .= html_writer::end_div();
        $html .= html_writer::end_div();
        
        return $html;
    }

    /**
     * Render the data table view (called from index.php).
     *
     * @param array $rows Data rows
     * @param int $total Total count
     * @param int $page Current page
     * @param int $perpage Records per page
     * @return string HTML output
     */
    public function datatable(array $rows, int $total, int $page, int $perpage): string {
        $headers = [
            get_string('course', 'local_financecosts'),
            get_string('amount', 'local_financecosts'),
            get_string('status', 'local_financecosts'),
            get_string('date', 'local_financecosts'),
            get_string('source', 'local_financecosts'),
        ];
        
        $base_url = new moodle_url('/local/financecosts/index.php', ['view' => 'dataview']);
        
        return $this->render_data_table($rows, $headers, $base_url, $total, $page, $perpage);
    }

    /**
     * Render a data table with pagination and filtering.
     *
     * @param array $data Table data
     * @param array $headers Table headers
     * @param moodle_url $base_url Base URL for pagination
     * @param int $total_count Total number of records
     * @param int $page Current page
     * @param int $perpage Records per page
     * @return string HTML output
     */
    public function render_data_table(array $data, array $headers, moodle_url $base_url, 
                                     int $total_count, int $page, int $perpage): string {
        $html = '';
        
        // Table (filters are handled by the main form, not here)
        $html .= html_writer::start_div('table-responsive');
        $html .= html_writer::start_tag('table', ['class' => 'table table-striped table-hover']);
        
        // Headers
        $html .= html_writer::start_tag('thead', ['class' => 'thead-dark']);
        $html .= html_writer::start_tag('tr');
        foreach ($headers as $header) {
            $html .= html_writer::tag('th', $header);
        }
        $html .= html_writer::end_tag('tr');
        $html .= html_writer::end_tag('thead');
        
        // Data rows
        $html .= html_writer::start_tag('tbody');
        if (empty($data)) {
            $html .= html_writer::start_tag('tr');
            $html .= html_writer::tag('td', get_string('no_data', 'local_financecosts'), 
                                    ['colspan' => count($headers), 'class' => 'text-center']);
            $html .= html_writer::end_tag('tr');
        } else {
            foreach ($data as $row) {
                $html .= html_writer::start_tag('tr');
                
                // Course name (get from courseid)
                $course_name = '';
                if (isset($row->courseid)) {
                    global $DB;
                    $course = $DB->get_record('course', ['id' => $row->courseid], 'fullname');
                    $course_name = $course ? $course->fullname : 'Unknown Course';
                }
                $html .= html_writer::tag('td', $course_name);
                
                // Amount
                $amount = isset($row->amount) ? number_format((float)$row->amount, 2) : '0.00';
                $html .= html_writer::tag('td', $amount);
                
                // Status
                $status = isset($row->status) ? $this->render_status_badge($row->status) : 'N/A';
                $html .= html_writer::tag('td', $status);
                
                // Date
                $date = isset($row->timecreated) ? userdate($row->timecreated) : 'N/A';
                $html .= html_writer::tag('td', $date);
                
                // Source
                $source = isset($row->source) ? ucfirst($row->source) : 'N/A';
                $html .= html_writer::tag('td', $source);
                
                $html .= html_writer::end_tag('tr');
            }
        }
        $html .= html_writer::end_tag('tbody');
        
        $html .= html_writer::end_tag('table');
        $html .= html_writer::end_div();
        
        // Pagination
        $html .= $this->render_pagination($base_url, $total_count, $page, $perpage);
        
        return $html;
    }



    /**
     * Render pagination controls.
     *
     * @param moodle_url $base_url Base URL
     * @param int $total_count Total records
     * @param int $page Current page
     * @param int $perpage Records per page
     * @return string HTML output
     */
    private function render_pagination(moodle_url $base_url, int $total_count, int $page, int $perpage): string {
        $total_pages = ceil($total_count / $perpage);
        
        if ($total_pages <= 1) {
            return '';
        }
        
        $html = '';
        $html .= html_writer::start_div('d-flex justify-content-between align-items-center mt-3');
        
        // Results info
        $start = ($page * $perpage) + 1;
        $end = min(($page + 1) * $perpage, $total_count);
        $html .= html_writer::tag('div', "Showing {$start} to {$end} of {$total_count} entries");
        
        // Pagination links
        $html .= html_writer::start_tag('nav');
        $html .= html_writer::start_tag('ul', ['class' => 'pagination mb-0']);
        
        // Previous
        if ($page > 0) {
            $prev_url = new moodle_url($base_url, ['page' => $page - 1]);
            $html .= html_writer::tag('li', 
                html_writer::link($prev_url, 'Previous', ['class' => 'page-link']), 
                ['class' => 'page-item']
            );
        }
        
        // Page numbers
        $start_page = max(0, $page - 2);
        $end_page = min($total_pages - 1, $page + 2);
        
        for ($i = $start_page; $i <= $end_page; $i++) {
            $page_url = new moodle_url($base_url, ['page' => $i]);
            $active_class = ($i === $page) ? ' active' : '';
            $html .= html_writer::tag('li', 
                html_writer::link($page_url, $i + 1, ['class' => 'page-link']), 
                ['class' => "page-item{$active_class}"]
            );
        }
        
        // Next
        if ($page < $total_pages - 1) {
            $next_url = new moodle_url($base_url, ['page' => $page + 1]);
            $html .= html_writer::tag('li', 
                html_writer::link($next_url, 'Next', ['class' => 'page-link']), 
                ['class' => 'page-item']
            );
        }
        
        $html .= html_writer::end_tag('ul');
        $html .= html_writer::end_tag('nav');
        
        $html .= html_writer::end_div();
        
        return $html;
    }

    /**
     * Render a status badge.
     *
     * @param string $status Status text
     * @return string HTML output
     */
    private function render_status_badge(string $status): string {
        $class = 'badge ';
        
        switch (strtolower($status)) {
            case 'approved':
            case 'approved by finance':
            case 'final approval':
            case 'completed':
                $class .= 'badge-success';
                break;
            case 'pending':
            case 'pending review':
            case 'waiting approval':
            case 'submitted':
            case 'draft':
                $class .= 'badge-warning';
                break;
            case 'rejected':
            case 'rejected - incomplete':
            case 'denied':
            case 'cancelled':
                $class .= 'badge-danger';
                break;
            default:
                $class .= 'badge-secondary';
        }
        
        return html_writer::span(ucfirst($status), $class);
    }

    /**
     * Render additional information for data rows.
     *
     * @param string $info Additional information text
     * @return string HTML output
     */
    private function render_additional_info(string $info): string {
        // Truncate long text to prevent table overflow
        if (strlen($info) > 100) {
            $info = substr($info, 0, 97) . '...';
        }
        
        return html_writer::span($info, 'text-muted small');
    }
}
