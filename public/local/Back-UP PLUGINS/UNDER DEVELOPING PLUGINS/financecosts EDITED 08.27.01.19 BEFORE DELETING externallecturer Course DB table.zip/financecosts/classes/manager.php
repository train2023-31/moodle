<?php
// Data-access / business-logic layer for local_financecosts.
//
// All heavy queries or calculations go here – never in renderers or UI files.

namespace local_financecosts;

defined('MOODLE_INTERNAL') || die();

use moodle_database;
use core_date;

class manager {

    /**
     * Return summary totals for the dashboard cards.
     *
     * @return array{total:float, approved:float, pending:float, rejected:float}
     */
    public static function get_summary_totals(): array {
        global $DB;

        // Get totals from External Lecturer costs (enhanced with better data validation)
        $externallecturer_total = 0;
        if ($DB->get_manager()->table_exists('externallecturer_courses')) {
            $externallecturer_total = (float)$DB->get_field_sql("
                SELECT COALESCE(SUM(CAST(ec.cost AS DECIMAL(10,2))), 0)
                FROM {externallecturer_courses} ec
                INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
                WHERE ec.cost IS NOT NULL AND ec.cost != '' AND ec.cost != '0'
            ");
        }

        // Get totals from Finance Services requests (enhanced with new fields)
        $financeservices_total = 0;
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $financeservices_total = (float)$DB->get_field_sql("
                SELECT COALESCE(SUM(fs.price_requested), 0)
                FROM {local_financeservices} fs
                WHERE fs.price_requested > 0
            ");
        }

        $total = $externallecturer_total + $financeservices_total;

        // Get approved amounts from Finance Services (enhanced status integration)
        $approved = 0;
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $approved = (float)$DB->get_field_sql("
                SELECT COALESCE(SUM(fs.price_requested), 0)
                FROM {local_financeservices} fs
                INNER JOIN {local_status} s ON s.id = fs.status_id
                WHERE (s.name LIKE '%approved%' OR s.name LIKE '%accept%' OR s.name LIKE '%completed%' OR s.name LIKE '%final%')
                AND fs.price_requested > 0
            ");
        }

        // Get pending amounts from Finance Services (enhanced status integration)
        $pending = 0;
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $pending = (float)$DB->get_field_sql("
                SELECT COALESCE(SUM(fs.price_requested), 0)
                FROM {local_financeservices} fs
                INNER JOIN {local_status} s ON s.id = fs.status_id
                WHERE (s.name LIKE '%pending%' OR s.name LIKE '%waiting%' OR s.name LIKE '%review%' OR s.name LIKE '%submitted%' OR s.name LIKE '%draft%')
                AND fs.price_requested > 0
            ");
        }

        // Get rejected amounts from Finance Services (enhanced status integration)
        $rejected = 0;
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $rejected = (float)$DB->get_field_sql("
                SELECT COALESCE(SUM(fs.price_requested), 0)
                FROM {local_financeservices} fs
                INNER JOIN {local_status} s ON s.id = fs.status_id
                WHERE (s.name LIKE '%reject%' OR s.name LIKE '%denied%' OR s.name LIKE '%decline%' OR s.name LIKE '%cancelled%')
                AND fs.price_requested > 0
            ");
        }

        // Add external lecturer costs to pending (assuming no status workflow for them yet)
        $pending += $externallecturer_total;

        return [
            'total'    => $total,
            'approved' => $approved,
            'pending'  => $pending,
            'rejected' => $rejected,
        ];
    }

    /**
     * Return paginated, filtered rows for the Data-view table.
     *
     * @param int      $page   zero-based page number for LIMIT/OFFSET
     * @param int      $perpage records per page
     * @param ?int     $course optional course id filter
     * @param ?string  $status optional status filter
     * @return array [rows, totalcount]
     */
    public static function get_detailed_rows(int $page, int $perpage,
                                             ?int $course, ?string $status): array {
        global $DB;

        $params = [];
        $where  = [];

        if ($course) {
            $where[] = '(fs.course_id = :courseid OR ec.courseid = :courseid2)';
            $params['courseid'] = $course;
            $params['courseid2'] = $course;
        }
        if ($status) {
            if ($status === 'pending') {
                $where[] = "(s.name LIKE '%pending%' OR s.name LIKE '%waiting%' OR s.name LIKE '%review%' OR s.name LIKE '%submitted%' OR s.name LIKE '%draft%' OR ec.courseid IS NOT NULL)";
            } else if ($status === 'approved') {
                $where[] = "(s.name LIKE '%approved%' OR s.name LIKE '%accept%' OR s.name LIKE '%completed%' OR s.name LIKE '%final%')";
            } else if ($status === 'rejected') {
                $where[] = "(s.name LIKE '%reject%' OR s.name LIKE '%denied%' OR s.name LIKE '%decline%' OR s.name LIKE '%cancelled%')";
            } else {
                $where[] = '(s.name LIKE :status OR s.display_name_en LIKE :status2 OR s.display_name_ar LIKE :status3)';
                $params['status'] = '%' . $status . '%';
                $params['status2'] = '%' . $status . '%';
                $params['status3'] = '%' . $status . '%';
            }
        }

        $wheresql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        // Enhanced Union query to get data from all finance sources
        $sql = "
        SELECT 
            ROW_NUMBER() OVER (ORDER BY timecreated DESC) as id,
            courseid,
            amount,
            status,
            timecreated,
            source,
            additional_info
        FROM (
            -- Finance Services data (enhanced with new fields)
            SELECT 
                fs.course_id as courseid,
                fs.price_requested as amount,
                COALESCE(s.display_name_en, s.name, 'unknown') as status,
                COALESCE(fs.date_time_submitted, fs.date_time_requested) as timecreated,
                'financeservices' as source,
                CASE 
                    WHEN fs.rejection_note IS NOT NULL AND fs.rejection_note != '' THEN CONCAT('Rejected: ', fs.rejection_note)
                    WHEN fs.approval_note IS NOT NULL AND fs.approval_note != '' THEN CONCAT('Approved: ', fs.approval_note)
                    WHEN fs.cause IS NOT NULL AND fs.cause != '' THEN CONCAT('Cause: ', fs.cause)
                    ELSE NULL
                END as additional_info
            FROM {local_financeservices} fs
            LEFT JOIN {local_status} s ON s.id = fs.status_id
            WHERE fs.price_requested > 0
            
            UNION ALL
            
            -- External Lecturer data (enhanced with better timestamp and lecturer info)
            SELECT 
                ec.courseid,
                CAST(ec.cost AS DECIMAL(10,2)) as amount,
                'pending' as status,
                COALESCE(el.timecreated, " . time() . ") as timecreated,
                'externallecturer' as source,
                CONCAT('Lecturer: ', el.name, ' (', el.lecturer_type, ')') as additional_info
            FROM {externallecturer_courses} ec
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
            WHERE ec.cost IS NOT NULL AND ec.cost != '' AND ec.cost != '0'
        ) combined_data
        $wheresql
        ORDER BY timecreated DESC
        ";

        // Enhanced count query
        $countsql = "
        SELECT COUNT(*) FROM (
            SELECT 1
            FROM {local_financeservices} fs
            LEFT JOIN {local_status} s ON s.id = fs.status_id
            WHERE fs.price_requested > 0
            
            UNION ALL
            
            SELECT 1
            FROM {externallecturer_courses} ec
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid
            WHERE ec.cost IS NOT NULL AND ec.cost != '' AND ec.cost != '0'
        ) combined_data
        $wheresql
        ";

        $total = $DB->count_records_sql($countsql, $params);
        $rows = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);

        return [$rows, $total];
    }

    /**
     * Get all courses that have finance-related data for filtering.
     *
     * @return array Course options for select dropdowns
     */
    public static function get_course_options(): array {
        global $DB;

        $sql = "
        SELECT DISTINCT c.id, c.fullname
        FROM {course} c
        WHERE c.id IN (
            SELECT DISTINCT course_id FROM {local_financeservices} WHERE price_requested > 0
            UNION
            SELECT DISTINCT courseid FROM {externallecturer_courses} ec 
            INNER JOIN {externallecturer} el ON el.id = ec.lecturerid 
            WHERE ec.cost IS NOT NULL AND ec.cost != '' AND ec.cost != '0'
        )
        ORDER BY c.fullname
        ";

        $courses = $DB->get_records_sql($sql);
        $options = [0 => get_string('all')];
        
        foreach ($courses as $course) {
            $options[$course->id] = $course->fullname;
        }

        return $options;
    }

    /**
     * Get available status options for filtering (enhanced with better status categorization).
     *
     * @return array Status options for select dropdowns
     */
    public static function get_status_options(): array {
        global $DB;

        $options = ['' => get_string('all')];
        
        // Add predefined status categories
        $options['pending'] = get_string('pending', 'local_financecosts');
        $options['approved'] = get_string('approved', 'local_financecosts');
        $options['rejected'] = get_string('rejected', 'local_financecosts');

        // Get all statuses that are actually used in finance requests (enhanced query)
        if ($DB->get_manager()->table_exists('local_financeservices') && $DB->get_manager()->table_exists('local_status')) {
            $statuses = $DB->get_records_sql("
                SELECT DISTINCT s.name, s.display_name_en, s.display_name_ar, s.seq, s.color
                FROM {local_status} s
                INNER JOIN {local_financeservices} fs ON fs.status_id = s.id
                WHERE s.is_active = 1
                ORDER BY s.seq, s.display_name_en
            ");

            foreach ($statuses as $status) {
                // Use Arabic display name if current language is Arabic, otherwise English
                $display_name = '';
                if (current_language() === 'ar' && !empty($status->display_name_ar)) {
                    $display_name = $status->display_name_ar;
                } else if (!empty($status->display_name_en)) {
                    $display_name = $status->display_name_en;
                } else {
                    $display_name = ucfirst($status->name);
                }
                
                $options[$status->name] = $display_name;
            }
        }

        return $options;
    }

    /**
     * Get enhanced statistics for the dashboard (new method).
     *
     * @return array Enhanced statistics
     */
    public static function get_enhanced_statistics(): array {
        global $DB;

        $stats = [];

        // Get count of external lecturers
        if ($DB->get_manager()->table_exists('externallecturer')) {
            $stats['external_lecturers_count'] = $DB->count_records('externallecturer');
            $stats['external_lecturer_courses_count'] = $DB->count_records('externallecturer_courses');
        }

        // Get count of finance service requests
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $stats['finance_requests_count'] = $DB->count_records('local_financeservices');
            
            // Get requests by status
            $stats['finance_requests_by_status'] = $DB->get_records_sql("
                SELECT s.display_name_en as status_name, COUNT(*) as count
                FROM {local_financeservices} fs
                INNER JOIN {local_status} s ON s.id = fs.status_id
                GROUP BY s.id, s.display_name_en
                ORDER BY s.seq
            ");
        }

        // Get recent activity (last 30 days)
        $thirty_days_ago = time() - (30 * 24 * 60 * 60);
        
        if ($DB->get_manager()->table_exists('local_financeservices')) {
            $stats['recent_finance_requests'] = $DB->count_records_select('local_financeservices', 
                'date_time_requested > ?', [$thirty_days_ago]);
        }

        if ($DB->get_manager()->table_exists('externallecturer')) {
            $stats['recent_external_lecturers'] = $DB->count_records_select('externallecturer', 
                'timecreated > ?', [$thirty_days_ago]);
        }

        return $stats;
    }
}
