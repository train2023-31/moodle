<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\task;

use local_financecosts\sync_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to aggregate financial data for reporting.
 */
class aggregate_reports extends \core\task\scheduled_task {

    /**
     * Get a descriptive name for this task (shown to admins).
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_aggregate_reports', 'local_financecosts');
    }

    /**
     * Run the task.
     */
    public function execute() {
        $sync_manager = new sync_manager();
        
        mtrace('Starting enhanced financial data aggregation...');
        
        try {
            $result = $sync_manager->aggregate_data();
            
            mtrace('Enhanced aggregation completed successfully.');
            mtrace("- Total amount aggregated: " . number_format($result['total'], 2));
            mtrace("- Approved amount: " . number_format($result['approved'], 2));
            mtrace("- Pending amount: " . number_format($result['pending'], 2));
            mtrace("- Rejected amount: " . number_format($result['rejected'], 2));
            mtrace("- Records processed: {$result['record_count']}");
            
            // Enhanced statistics output
            if (!empty($result['enhanced_stats'])) {
                mtrace('Enhanced Statistics:');
                
                if (isset($result['enhanced_stats']['external_lecturers_count'])) {
                    mtrace("  - External lecturers: {$result['enhanced_stats']['external_lecturers_count']}");
                    mtrace("  - External lecturer courses: {$result['enhanced_stats']['external_lecturer_courses_count']}");
                }
                
                if (isset($result['enhanced_stats']['finance_requests_count'])) {
                    mtrace("  - Finance requests: {$result['enhanced_stats']['finance_requests_count']}");
                }
                
                if (isset($result['enhanced_stats']['recent_finance_requests'])) {
                    mtrace("  - Recent finance requests (30 days): {$result['enhanced_stats']['recent_finance_requests']}");
                }
                
                if (isset($result['enhanced_stats']['recent_external_lecturers'])) {
                    mtrace("  - Recent external lecturers (30 days): {$result['enhanced_stats']['recent_external_lecturers']}");
                }
                
                // Status breakdown
                if (isset($result['enhanced_stats']['finance_requests_by_status'])) {
                    mtrace("  - Finance requests by status:");
                    foreach ($result['enhanced_stats']['finance_requests_by_status'] as $status) {
                        mtrace("    * {$status->status_name}: {$status->count}");
                    }
                }
            }
            
        } catch (\Exception $e) {
            mtrace('Error during enhanced aggregation: ' . $e->getMessage());
            throw $e;
        }
    }
} 