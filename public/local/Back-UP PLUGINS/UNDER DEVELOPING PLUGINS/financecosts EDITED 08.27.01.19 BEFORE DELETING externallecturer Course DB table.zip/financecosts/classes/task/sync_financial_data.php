<?php
// This file is part of Moodle - http://moodle.org/

namespace local_financecosts\task;

use local_financecosts\sync_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to sync financial data from various plugins.
 */
class sync_financial_data extends \core\task\scheduled_task {

    /**
     * Get a descriptive name for this task (shown to admins).
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_sync_financial_data', 'local_financecosts');
    }

    /**
     * Run the task.
     */
    public function execute() {
        $sync_manager = new sync_manager();
        
        mtrace('Starting enhanced financial data synchronization...');
        
        try {
            $result = $sync_manager->sync_all_data();
            
            mtrace('Enhanced synchronization completed successfully.');
            mtrace("- External lecturer costs processed: {$result['externallecturer_count']}");
            mtrace("- Finance services processed: {$result['financeservices_count']}");
            mtrace("- Clauses processed: {$result['clause_count']}");
            
            // Enhanced statistics output
            if (!empty($result['enhanced_stats'])) {
                mtrace('Enhanced Statistics:');
                
                if (isset($result['enhanced_stats']['external_lecturer_stats'])) {
                    $el_stats = $result['enhanced_stats']['external_lecturer_stats'];
                    mtrace("  - Total external lecturers: {$el_stats['total_lecturers']}");
                    mtrace("  - Active lecturers: {$el_stats['active_lecturers']}");
                    mtrace("  - External visitors: {$el_stats['external_visitors']}");
                    mtrace("  - Residents: {$el_stats['residents']}");
                }
                
                if (isset($result['enhanced_stats']['finance_services_stats'])) {
                    $fs_stats = $result['enhanced_stats']['finance_services_stats'];
                    mtrace("  - Total finance requests: {$fs_stats['total_requests']}");
                    mtrace("  - Active requests: {$fs_stats['active_requests']}");
                    mtrace("  - Requests with notes: {$fs_stats['requests_with_notes']}");
                }
                
                if (isset($result['enhanced_stats']['status_integration_stats'])) {
                    $status_stats = $result['enhanced_stats']['status_integration_stats'];
                    mtrace("  - Total statuses: {$status_stats['total_statuses']}");
                    mtrace("  - Active statuses: {$status_stats['active_statuses']}");
                    mtrace("  - Approval statuses: {$status_stats['statuses_with_approval']}");
                }
            }
            
        } catch (\Exception $e) {
            mtrace('Error during enhanced synchronization: ' . $e->getMessage());
            throw $e;
        }
    }
} 