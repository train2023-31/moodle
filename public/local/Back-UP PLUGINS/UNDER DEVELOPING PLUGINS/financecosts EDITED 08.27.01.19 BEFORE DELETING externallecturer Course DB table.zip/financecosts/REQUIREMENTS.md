# Finance Costs Plugin - Requirements Document

## Document Information
- **Project**: Finance Costs Plugin (`local_financecosts`)
- **Version**: 2.2
- **Date**: 2025
- **Scope**: Centralized financial cost management system for Moodle

## 1. Overview

### 1.1 Purpose
Develop a centralized financial cost management system that aggregates and reports on costs from various finance-related plugins within a Moodle installation.

### 1.2 Objectives
- Aggregate financial data from multiple source plugins and database tables.
- Provide real-time dashboard with cost summaries
- Enable detailed data analysis with filtering capabilities
- Implement automated data synchronization
- Provide comprehensive management interface for administrators

## 2. Functional Requirements

### 2.1 Data Aggregation (FR-001)
**Priority**: High
**Description**: The system must aggregate financial data from multiple source plugins.

**Acceptance Criteria**:
- ✅ Replace placeholder SQL queries with real aggregation queries
- ✅ Support External Lecturer Plugin (`externallecturer_courses` table)
- ✅ Support Finance Services Plugin (`local_financeservices` table)
- ✅ Integrate with status workflow system (`local_status`)

**Source Data Mapping**:
| Plugin | Table | Amount Field | Status Source |
|--------|-------|--------------|---------------|
| External Lecturer | `externallecturer_courses` | `cost` | Default: "pending" |
| Finance Services | `local_financeservices` | `price_requested` | `local_status` workflow |

### 2.2 Dashboard Interface (FR-002)
**Priority**: High
**Description**: Provide a real-time dashboard showing financial summaries.

**Acceptance Criteria**:
- ✅ Display total costs across all sources
- ✅ Show approved costs (workflow-based)
- ✅ Show pending costs (workflow-based + external lecturer)
- ✅ Show rejected costs (workflow-based)
- ✅ Use responsive card-based design
- ✅ Auto-format currency values
- ✅ Real-time data (no caching delays)

### 2.3 Data Management Interface (FR-003)
**Priority**: High
**Description**: Provide detailed view of all financial records with filtering capabilities.

**Acceptance Criteria**:
- ✅ Unified table view of all cost records
- ✅ Filter by course
- ✅ Filter by status
- ✅ Pagination with configurable page size
- ✅ Search functionality
- ✅ Source identification (plugin origin)
- ✅ Date formatting and sorting

### 2.4 Category Management (FR-004)
**Priority**: Medium
**Description**: Allow administrators to create and manage cost categories.

**Acceptance Criteria**:
- ✅ CRUD operations for categories
- ✅ Category name uniqueness validation
- ✅ Active/inactive status management
- ✅ Description field support
- ✅ Timestamp tracking (created/modified)
- ✅ Moodle form integration with validation

### 2.5 Automated Synchronization (FR-005)
**Priority**: High
**Description**: Implement automated data synchronization via cron tasks.

**Acceptance Criteria**:
- ✅ Daily data sync task (2:00 AM)
- ✅ Bi-daily aggregation task (6:30 AM, 6:30 PM)
- ✅ Comprehensive logging system
- ✅ Error handling and recovery
- ✅ Performance metrics tracking
- ✅ Configurable sync frequency

### 2.6 Management Interface (FR-006)
**Priority**: High
**Description**: Provide comprehensive administrative management interface.

**Acceptance Criteria**:
- ✅ Category CRUD operations
- ✅ Sync log viewer with detailed history
- ✅ Manual sync trigger capability
- ✅ Statistics and summary reports
- ✅ 30-day operational summary
- ✅ Error log analysis tools

## 3. Technical Requirements

### 3.1 Database Schema (TR-001)
**Priority**: High

**Required Tables**:
```sql
-- Categories
local_financecosts_cat:
- id (int, primary key, auto-increment)
- name (varchar(100), unique, not null)
- description (text, nullable)
- isactive (tinyint(1), not null, default 1)
- timecreated (int(10), not null)
- timemodified (int(10), nullable)

-- Sync Logs  
local_financecosts_log:
- id (int, primary key, auto-increment)
- runat (int(10), not null)
- status (varchar(20), not null) -- running/success/error/aggregated
- details (text, nullable) -- JSON-encoded details
```

### 3.2 Cron Tasks (TR-002)
**Priority**: High

**Required Tasks**:
```php
// Task 1: Data Synchronization
Class: \local_financecosts\task\sync_financial_data
Schedule: Daily at 2:00 AM (0 2 * * *)
Purpose: Sync data from external plugins

// Task 2: Report Aggregation  
Class: \local_financecosts\task\aggregate_reports
Schedule: Twice daily at 6:30 AM and 6:30 PM (30 6,18 * * *)
Purpose: Generate aggregated reports
```

### 3.3 API Classes (TR-003)
**Priority**: High

**Required Classes**:
- ✅ `\local_financecosts\manager` - Core business logic
- ✅ `\local_financecosts\sync_manager` - Synchronization operations
- ✅ `\local_financecosts\form\category_form` - Category management forms
- ✅ `\local_financecosts\output\renderer` - UI rendering components

### 3.4 Security & Permissions (TR-004)
**Priority**: High

**Required Capabilities**:
```php
'local/financecosts:view' => [
    'captype' => 'read',
    'contextlevel' => CONTEXT_SYSTEM,
    'archetypes' => ['manager' => CAP_ALLOW]
]

'local/financecosts:manage' => [
    'captype' => 'write', 
    'contextlevel' => CONTEXT_SYSTEM,
    'archetypes' => ['manager' => CAP_ALLOW],
    'riskbitmask' => RISK_DATALOSS
]
```

### 3.5 Integration Requirements (TR-005)
**Priority**: High

**Plugin Dependencies**:
- ✅ Must gracefully handle missing source plugins
- ✅ Table existence validation before queries
- ✅ Backward compatibility with existing data
- ✅ No hard dependencies (soft integration)

## 4. User Interface Requirements

### 4.1 Navigation Structure (UI-001)
**Priority**: High

**Admin Menu Structure**:
```
Site Administration → Plugins → Local plugins → Finance Costs
├── Dashboard (main view)
├── Management (admin tools)
└── Settings (configuration)
```

### 4.2 Design Standards (UI-002)
**Priority**: Medium

**Requirements**:
- ✅ Moodle UI/UX standards compliance
- ✅ Accessibility standards (WCAG 2.1)
- ✅ Icon usage (Font Awesome integration)

### 4.3 User Experience (UI-003)
**Priority**: High

**Requirements**:
- ✅ Intuitive tabbed navigation
- ✅ Clear form validation messaging
- ✅ Confirmation dialogs for destructive actions
- ✅ Loading indicators for long operations
- ✅ Success/error notification system

## 5. Performance Requirements

### 5.1 Query Optimization (PF-001)
**Priority**: High

**Requirements**:
- ✅ Efficient SQL queries with proper JOINs
- ✅ Pagination to limit result sets
- ✅ Database index utilization
- ✅ UNION queries for multi-source aggregation

### 5.2 Caching Strategy (PF-002)
**Priority**: Medium

**Requirements**:
- Dashboard data refresh on each page load (real-time)
- Log data pagination for large datasets
- Configurable sync frequency to balance load

## 6. Configuration Requirements

### 6.1 Administrative Settings (CF-001)
**Priority**: Medium

**Required Settings**:
```php
// Sync frequency (hours)
'local_financecosts/sync_frequency' => 24

// Log retention (days)  
'local_financecosts/log_retention' => 90
```

### 6.2 Language Support (CF-002)
**Priority**: High

**Requirements**:
- ✅ Complete English language pack
- ✅ Help text for all form fields
- ✅ Error message internationalization
- ✅ Placeholder for future language packs

## 7. Data Requirements

### 7.1 Data Sources (DR-001)
**Priority**: High

**Source Plugin Requirements**:

**External Lecturer Plugin**:
- Table: `externallecturer_courses`
- Fields: `id`, `lecturerid`, `courseid`, `cost`
- Relationship: Join with `externallecturer` table
- Status: Default to "pending" (no direct status field)

**Finance Services Plugin**:
- Table: `local_financeservices`  
- Fields: `id`, `course_id`, `price_requested`, `status_id`
- Status Integration: Direct link via `status_id` → `local_status.id`
- Workflow: Each request has its own status from the status plugin

**Finance Services Clauses**:
- Table: `local_financeservices_clause`
- Fields: `id`, `amount`, `deleted`
- Filter: Only include non-deleted records

### 7.2 Data Validation (DR-002)
**Priority**: High

**Requirements**:
- ✅ Numeric validation for cost fields
- ✅ NULL value handling with COALESCE
- ✅ Currency formatting consistency
- ✅ Date/timestamp standardization

## 8. Logging & Monitoring Requirements

### 8.1 Sync Logging (LM-001)
**Priority**: High

**Requirements**:
- ✅ Log all sync operations with timestamps
- ✅ JSON-encoded details for structured data
- ✅ Error logging with stack traces
- ✅ Performance metrics (record counts, execution time)
- ✅ Status tracking (running/success/error/aggregated)

### 8.2 Log Management (LM-002)
**Priority**: Medium

**Requirements**:
- ✅ Automatic log cleanup based on retention policy
- ✅ Log viewer with pagination
- ✅ Search and filter capabilities
- ✅ Export functionality for troubleshooting

## 9. Documentation Requirements

### 9.1 Technical Documentation (DC-001)
**Priority**: High

**Required Documentation**:
- ✅ API documentation for all public methods
- ✅ Database schema documentation
- ✅ Installation and configuration guide
- ✅ Developer extension guide

### 9.2 User Documentation (DC-002)
**Priority**: High

**Required Documentation**:
- ✅ User manual with screenshots
- ✅ Administrative procedures
- ✅ Troubleshooting guide
- ✅ FAQ section

## 10. Deployment Requirements

### 10.1 Installation Process (DP-001)
**Priority**: High

**Requirements**:
- Standard Moodle plugin installation process
- Database schema creation via install.xml
- Default category creation (optional)
- Capability assignment guidance

### 10.2 Upgrade Process (DP-002)
**Priority**: Medium

**Requirements**:
- Backward compatibility with existing data
- Migration scripts for schema changes
- Data preservation during upgrades

## 11. Success Criteria

### 11.1 Functional Success (SC-001)
- ✅ All source plugins successfully integrated
- ✅ Real-time dashboard operational
- ✅ Automated sync running without errors
- ✅ Management interface fully functional
- ✅ Data accuracy verified across all sources

### 11.2 Performance Success (SC-002)
- Dashboard loads within 2 seconds
- Data synchronization completes within scheduled timeframe
- UI remains responsive under normal load

### 11.3 User Acceptance (SC-003)
- Finance staff can access required data efficiently
- Administrators can manage system without technical assistance
- Error rates below 1% for normal operations

## 12. Risk Assessment

### 12.1 Technical Risks (RK-001)
- **Risk**: Source plugin schema changes
- **Mitigation**: Table existence validation, graceful degradation

- **Risk**: Large dataset performance issues  
- **Mitigation**: Pagination, query optimization, caching strategy

### 12.2 Operational Risks (RK-002)
- **Risk**: Cron task failures disrupting data sync
- **Mitigation**: Comprehensive logging, manual sync capability, error notifications

- **Risk**: User permission misconfiguration
- **Mitigation**: Clear capability documentation, default safe permissions

## 13. Implementation Status

### 13.1 Completed Features ✅
- [x] Real aggregation queries replacing placeholders
- [x] Cron task configuration (db/tasks.php)
- [x] Sync manager implementation (classes/sync_manager.php)  
- [x] Complete management UI (manage.php)
- [x] Category CRUD operations (classes/form/category_form.php)
- [x] Output renderer (classes/output/renderer.php)
- [x] Language strings (lang/en/local_financecosts.php)
- [x] Settings configuration (settings.php)
- [x] Comprehensive documentation (README.md)

### 13.2 Future Enhancements (Optional)
- [ ] Additional data source plugins
- [ ] Export functionality (CSV, Excel)
- [ ] Advanced reporting with charts
- [ ] Email notifications for sync failures
- [ ] Multi-currency support
- [ ] API endpoints for external integrations

---

**Document Control**
- Created: 2025
- Last Updated: 2025
- Next Review: After first production deployment
- Document Owner: Development Team
- Stakeholders: Finance Department, IT Administration 